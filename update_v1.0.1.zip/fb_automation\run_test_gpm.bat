@echo off
chcp 65001 >nul
title DMT Browser - Test Tương Tác FB Profile GPM
cd /d "%~dp0"

if exist "..\runtime\python\python.exe" (
    "..\runtime\python\python.exe" test_gpm_interaction.py
) else (
    python test_gpm_interaction.py
)

pause
