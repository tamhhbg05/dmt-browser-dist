"""
Script Kiểm Tra Trực Tiếp: Tương tác (Thả Tim/Like) và Bình luận bài viết thứ 5 trên Facebook
Profile GPM ID: 1e516cb4-e482-459a-9278-1be14766a259
"""

import sys
import time
import random
from pathlib import Path

# Thêm đường dẫn thư mục hiện tại
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from gpm_controller import GPMController
from fb_bot import FacebookBot
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains

TEST_PROFILE_ID = "1e516cb4-e482-459a-9278-1be14766a259"
GPM_API_BASE = "http://127.0.0.1:9495/api/v1"

def main():
    print("=" * 75)
    print("   CHẠY TRỰC TIẾP PROFILE GPM: KIỂM TRA TƯƠNG TÁC & CMT BÀI VIẾT THỨ 5")
    print(f"   Profile ID: {TEST_PROFILE_ID}")
    print("=" * 75)

    # 1. Kiểm tra kết nối tới GPM API
    print(f"\n[*] Đang kiểm tra kết nối tới GPMLogin API tại {GPM_API_BASE}...")
    conn = GPMController.check_connection(api_base=GPM_API_BASE)
    if not conn.get("online"):
        print("[!] Không thể kết nối tới GPMLogin API. Vui lòng bật ứng dụng GPMLogin!")
        return

    print(f"[OK] Đã kết nối thành công tới GPM! (Đang quản lý {conn.get('profiles_count')} profiles)")

    print(f"\n[*] Đang khởi động Profile GPM [{TEST_PROFILE_ID}] lên màn hình...")
    driver = None
    try:
        driver = GPMController.create_driver(
            profile_id=TEST_PROFILE_ID,
            api_base=GPM_API_BASE,
            window_size="1280,900",
            window_scale=0.75,
            skip_proxy_check=False
        )
        print("[OK] Đã mở cửa sổ trình duyệt Chrome của Profile GPM thành công!")

        bot = FacebookBot(
            driver=driver,
            profile_id=TEST_PROFILE_ID,
            target_users=[],
            profile_label="GPM-TEST",
        )

        print("\n[*] Đang điều hướng vào Facebook...")
        driver.get("https://www.facebook.com/")
        time.sleep(4.0)

        bot.dismiss_alerts()

        print("\n[*] Bắt đầu lướt Feed và đếm từng bài viết để chọn đúng bài thứ 5...")

        seen_post_keys = set()
        total_posts_counted = 0
        target_post_item = None

        for scroll_round in range(1, 20):
            # Quét các bài viết đang hiển thị trên màn hình
            posts = bot._scan_posts_with_poster_names()
            for p in posts:
                key = p.get("postKey") or ""
                if not key or key in seen_post_keys:
                    continue

                seen_post_keys.add(key)
                total_posts_counted += 1

                author = p.get("primaryAuthor") or "Người dùng Facebook"
                snippet = (p.get("snippet") or "").strip()[:50]
                print(f"   [{total_posts_counted}] Bài viết của [{author}]: {snippet}...")

                if total_posts_counted == 5:
                    target_post_item = p
                    break

            if target_post_item or total_posts_counted >= 5:
                break

            # Cuộn tiếp xuống
            bot.smooth_scroll(random.randint(450, 600))
            time.sleep(random.uniform(1.8, 2.5))

        if not target_post_item:
            print("[!] Không tìm đủ 5 bài viết trên Feed để tương tác.")
            return

        print("\n" + "=" * 75)
        author_5 = target_post_item.get("primaryAuthor") or "Người dùng Facebook"
        print(f"🎯 [ĐÃ ĐẾN BÀI VIẾT THỨ 5] Của tác giả: [{author_5}]")
        print("   Bắt đầu thực hiện Thả Cảm Xúc -> Bình Luận -> Đóng bài -> Tiếp tục lướt!")
        print("=" * 75)

        like_btn = target_post_item.get("likeBtn")
        if not like_btn:
            print("[!] Không tìm thấy nút Like của bài thứ 5.")
            return

        # 1. Cuộn bài thứ 5 vào giữa màn hình
        driver.execute_script("arguments[0].scrollIntoView({block: 'center', inline: 'nearest', behavior: 'smooth'});", like_btn)
        time.sleep(1.5)

        # 2. Thao tác Tương tác (Thả Tim hoặc Thả Like)
        print("\n[*] 1/4. Đang thả cảm xúc (Thả Tim ❤️)...")
        ok_react = bot._react_love(like_btn)
        if not ok_react:
            ok_react = bot._react_like(like_btn)
        print(f"   -> Kết quả thả cảm xúc: {'Thành công 👍/❤️' if ok_react else 'Thất bại'}")
        time.sleep(2.0)

        # 3. Thao tác Bình luận bằng các XPath chuẩn:
        #    //div[@aria-label="Viết bình luận"] -> //div[@role="textbox"] -> //div[@aria-label="Đăng bình luận"]
        print("\n[*] 2/4. Đang bấm vào 'Viết bình luận' của bài thứ 5...")
        cmt_text = "Bài viết rất hay và ý nghĩa bạn ơi 👍"
        ok_comment = bot._comment_on_post(like_btn, author_5)
        print(f"   -> Kết quả bình luận: {'Thành công 💬' if ok_comment else 'Thất bại'}")
        time.sleep(2.5)

        # 4. Tiếp tục cuộn lướt qua bài thứ 6, bài thứ 7 để chứng minh bot tiếp tục lướt mượt mà sau khi đóng bài
        print("\n[*] 3/4. Tiếp tục lướt Feed qua bài viết thứ 6, 7...")
        for _ in range(3):
            bot.smooth_scroll(random.randint(500, 700))
            time.sleep(random.uniform(2.0, 3.0))

        print("\n" + "=" * 75)
        print("   [HOÀN THÀNH 100%] ĐÃ TƯƠNG TÁC & CMT THÀNH CÔNG VÀO ĐÚNG BÀI VIẾT THỨ 5!")
        print("   Trình duyệt đang được giữ mở trên màn hình để bạn quan sát.")
        print("=" * 75)

    except Exception as e:
        print(f"\n[X] Lỗi trong quá trình chạy test: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
