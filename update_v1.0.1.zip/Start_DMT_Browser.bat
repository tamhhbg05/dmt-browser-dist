@echo off
chcp 65001 >nul
title DMT Browser - Antidetect Browser Manager (Camoufox C++ Core)
cd /d "%~dp0"

set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "PYTHONUNBUFFERED=1"
set "CAMOUFOX_PORTABLE_DIR=%~dp0runtime\camoufox_cache"

echo ==============================================================
echo       DMT BROWSER - ANTIDETECT BROWSER MANAGER (PRO)
echo         100%% Portable Edition (Camoufox C++ Core)
echo ==============================================================
echo.

if exist "%~dp0runtime\python\python.exe" (
    echo [*] Su dung Python Portable tich hop san trong thu muc...
    "%~dp0runtime\python\python.exe" "%~dp0main.py"
) else (
    echo [*] Su dung Python he thong...
    python "%~dp0main.py"
)

if %errorlevel% neq 0 (
    echo.
    echo [!] Co loi xay ra khi khoi dong DMT Browser.
    pause
)
