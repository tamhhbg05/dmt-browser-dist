import base64
import json
import os
import requests
from plugin import (
    CONFIG_FILE,
    OUTPUT_DIR,
    build_auth_headers,
    extract_images_from_response,
    join_endpoint,
    load_config,
)


def get_active_api_settings(profile_name_or_id: str = None):
    cfg = load_config()
    profiles = cfg.get("profiles", [])
    if profile_name_or_id and profiles:
        for p in profiles:
            if p.get("id") == profile_name_or_id or p.get("name") == profile_name_or_id:
                return p
    active_id = cfg.get("active_profile_id")
    for p in profiles:
        if p.get("id") == active_id:
            return p
    return {
        "name": cfg.get("profile_name", "modelapi.vn"),
        "base_url": cfg.get("base_url", "https://modelapi.vn/v1"),
        "api_key": cfg.get("api_key", ""),
        "image_path": cfg.get("image_path", "/images/generations"),
        "auth_type": cfg.get("auth_type", "Bearer"),
        "custom_headers": cfg.get("custom_headers", ""),
        "image_model": cfg.get("image_model", "gpt-image-2"),
    }


def generate_image(
    prompt: str,
    model: str = None,
    output_path: str = None,
    size: str = "1024x1024",
    quality: str = "standard",
    style: str = "vivid",
    base_url: str = None,
    api_key: str = None,
    image_path: str = None,
    profile: str = None,
):
    prof = get_active_api_settings(profile)
    use_base_url = base_url or prof.get("base_url", "https://modelapi.vn/v1")
    use_api_key = api_key or prof.get("api_key", "")
    use_img_path = image_path or prof.get("image_path", "/images/generations")
    use_model = model or prof.get("image_model", "gpt-image-2")
    auth_type = prof.get("auth_type", "Bearer")
    custom_headers = prof.get("custom_headers", "")

    if not output_path:
        output_path = str(OUTPUT_DIR / "output_image.png")

    endpoint = join_endpoint(use_base_url, use_img_path)
    headers = build_auth_headers(use_api_key, auth_type, custom_headers, include_json_ct=True)

    payload = {"model": use_model, "prompt": prompt, "n": 1}
    if size and size.lower() != "auto":
        payload["size"] = size
    if quality and quality.lower() != "auto":
        payload["quality"] = quality
    if style and style.lower() != "auto":
        payload["style"] = style

    r = requests.post(endpoint, headers=headers, json=payload, timeout=120)
    if r.status_code in (400, 422) and ("quality" in payload or "style" in payload):
        minimal_payload = {"model": use_model, "prompt": prompt}
        if size and size.lower() != "auto":
            minimal_payload["size"] = size
        r_retry = requests.post(endpoint, headers=headers, json=minimal_payload, timeout=120)
        if r_retry.status_code == 200:
            r = r_retry

    if r.status_code != 200:
        raise Exception(f"HTTP {r.status_code}: {r.text}")

    res = r.json()
    items, _ = extract_images_from_response(res)
    if not items:
        raise Exception("Không nhận được dữ liệu ảnh từ API.")

    first = items[0]
    if first["type"] == "b64":
        b64_data = first["data"]
        if "," in b64_data and b64_data.startswith("data:"):
            b64_data = b64_data.split(",", 1)[1]
        with open(output_path, "wb") as f:
            f.write(base64.b64decode(b64_data))
    else:
        url = first["data"]
        if url.startswith("data:image") and "," in url:
            b64_data = url.split(",", 1)[1]
            with open(output_path, "wb") as f:
                f.write(base64.b64decode(b64_data))
        else:
            full_url = url if url.startswith("http") else join_endpoint(use_base_url, url)
            img_data = requests.get(full_url, timeout=45).content
            with open(output_path, "wb") as f:
                f.write(img_data)

    return output_path
