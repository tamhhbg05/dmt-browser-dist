import os
import random
from typing import Tuple, Optional


class ContentGenerator:
    """
    Tự động sáng tạo các bài viết chia sẻ theo chủ đề liên quan đến tuyển dụng,
    việc làm và đời sống người lao động dành riêng cho Trang Cá Nhân (Personal Branding).
    """

    # KHO CÁC CHỦ ĐỀ CHIA SẺ VỀ NGHỀ TUYỂN DỤNG & ĐỜI SỐNG VIỆC LÀM
    TOPICS = [
        # Chủ đề 1: Tâm sự nghề tuyển dụng & Niềm vui khi hỗ trợ người tìm việc
        [
            "Nhiều lúc làm nghề tuyển dụng cũng có những niềm vui giản dị lắm cả nhà ạ. 😊\n\n"
            "Sáng nay đón một nhóm các bạn trẻ từ vùng cao xuống nhận việc. Nhìn ánh mắt vừa bỡ ngỡ vừa đầy quyết tâm của các bạn mà mình thấy ấm lòng. "
            "Nhớ ngày đầu mình đi làm cũng y như vậy, cái gì cũng bỡ ngỡ, cái gì cũng phải học.\n\n"
            "Chỉ mong các bạn luôn giữ được sự chăm chỉ, chịu khó để sớm ổn định cuộc sống và có một nguồn thu nhập vững vàng gửi về cho bố mẹ ở quê.\n\n"
            "Anh chị em nào đang cần tìm một công việc ổn định, môi trường tốt thì cứ nhắn tin cho mình nhé, mình luôn sẵn lòng đồng hành cùng mọi người! ❤️",
            "#chuyendi_lam #tam_su_nghe #vieclamonldinh #tuyen_dung_co_tam"
        ],
        [
            "Có bạn nhắn tin hỏi mình: 'Chị ơi, em chưa từng đi làm công ty bao giờ, vào đấy có khó lắm không chị?'\n\n"
            "Mình trả lời luôn: 'Ai trong đời cũng phải có lần đầu tiên em ạ! Ở môi trường nào cũng vậy, không biết thì mình học, vụng về thì mình rèn. "
            "Quan trọng nhất vẫn là thái độ chịu khó và tinh thần cầu tiến.'\n\n"
            "Các công ty bây giờ đều đào tạo cầm tay chỉ việc từ A đến Z, đồng nghiệp đi trước hỗ trợ nhiệt tình nên các bạn cứ tự tin lên nhé! 💪✨\n\n"
            "Đừng ngại bước ra khỏi vùng an toàn, cơ hội luôn dành cho những ai dám bắt đầu!",
            "#kinhnghiemdilam #tuduytichcuc #dongluctre #timvieclam"
        ],

        # Chủ đề 2: Góc nhìn về sự nỗ lực và giá trị của lao động
        [
            "Đồng tiền kiếm được từ mồ hôi, công sức của chính mình lúc nào cũng đáng trân quý nhất. 🌾\n\n"
            "Nhìn các anh chị em công nhân tan ca, dù mồ hôi ướt áo nhưng nụ cười vẫn rạng rỡ khi nghĩ về ngày nhận lương, nghĩ về gia đình nhỏ ở quê... "
            "thực sự rất khâm phục sự bền bỉ của mọi người.\n\n"
            "Đi làm xa nhà có vất vả, có nhớ quê, nhưng đó là sự đánh đổi xứng đáng cho một tương lai tốt đẹp hơn. Chúc cho toàn thể anh chị em lao động luôn thật nhiều sức khỏe, ca kíp thuận lợi và thu nhập ngày một nâng cao nhé! 🍀",
            "#laodonglavingquang #nguoilaodong #congnhan #yeudoi"
        ],
        [
            "Người ta hay bảo làm công nhân thì gò bó, nhưng với mình, mỗi công việc lương thiện đều mang một giá trị rất riêng. 🏭✨\n\n"
            "Môi trường công xưởng dạy cho chúng ta tính kỷ luật, giờ giấc chuẩn chỉ, làm việc nhóm và tác phong nhanh nhẹn. "
            "Rất nhiều bạn sau vài năm chăm chỉ đi làm nhà máy đã tích lũy được một số vốn kha khá để lo cho tương lai, xây nhà cho bố mẹ.\n\n"
            "Chỉ cần mình không ngừng cố gắng, thì ở bất cứ vị trí nào mình cũng có thể tỏa sáng theo cách riêng!",
            "#congnhanvietnam #no_luc_moi_ngay #giatricuocsong"
        ],

        # Chủ đề 3: Chia sẻ kinh nghiệm phỏng vấn & chuẩn bị hồ sơ
        [
            "Góc chia sẻ kinh nghiệm cho các bạn chuẩn bị đi phỏng vấn xin việc nè! 📝\n\n"
            "Thực ra nhà tuyển dụng không đòi hỏi gì quá cao siêu ở các vị trí lao động phổ thông đâu, họ chỉ quan sát 3 điều rất cơ bản:\n"
            "1. Tác phong đúng giờ: Đi sớm 10-15 phút để chuẩn bị tinh thần thoải mái.\n"
            "2. Trang phục gọn gàng, lịch sự: Thể hiện sự tôn trọng với công việc.\n"
            "3. Thái độ trung thực và cầu thị: Cái gì chưa biết cứ mạnh dạn nhận và hứa sẽ cố gắng học hỏi.\n\n"
            "Chỉ cần làm tốt 3 điều này là 90% bạn đã ghi điểm trong mắt quản lý rồi đó. Chúc các bạn luôn tự tin và tìm được công việc ưng ý nhé! 🌟",
            "#meophongvan #kinhnghiemxinviec #tuyendungnhansu"
        ],

        # Chủ đề 4: Đời sống công xưởng, bữa ăn ca và ký túc xá
        [
            "Hôm nay có dịp ghé qua căng tin và khu ký túc xá của công ty thăm các bạn mới vào làm. 🍱🏢\n\n"
            "Nhìn khay cơm đầy đặn thịt cá, canh rau nóng hổi và phòng ốc điều hòa sạch sẽ mát mẻ, mình cũng thấy an tâm phần nào. "
            "Đi làm xa nhà, cái quan trọng nhất là chỗ ăn chỗ ở phải đảm bảo thì mới có sức khỏe và tinh thần làm việc lâu dài được.\n\n"
            "Thời buổi này tìm được một nơi làm việc đãi ngộ tốt, chăm lo chu đáo cho công nhân viên từ bữa ăn giấc ngủ là điều cực kỳ đáng quý. "
            "Bạn nào đang muốn đổi sang môi trường mới sạch sẽ, văn minh thì cứ ới mình một câu nhé! 🤗",
            "#moitruonglamviec #ky_tuc_xa #chamlocongnhan #vieclamkcn"
        ],

        # Chủ đề 5: Lời chúc & Hỏi thăm tương tác bạn bè đầu tuần / cuối tuần
        [
            "Đầu tuần chúc cả nhà một tuần mới làm việc tràn đầy năng lượng và thật nhiều may mắn nhé! ☀️🔥\n\n"
            "Tuần này ai có kế hoạch bắt đầu một công việc mới, thử thách bản thân ở một môi trường mới thì chúc mọi người vạn sự hanh thông!\n\n"
            "Các bạn công nhân tuần này có nhiều lịch tăng ca không nhỉ? Tăng ca kiếm thêm thu nhập nhưng nhớ giữ gìn sức khỏe, ăn uống đầy đủ nha cả nhà ơi! 💪❤️",
            "#chao_tuan_moi #nangluongtichcuc #chucmung #vieclam"
        ],
        [
            "Cuối tuần rồi, chúc cho toàn thể anh chị em đồng nghiệp và các bạn công nhân viên có những ngày nghỉ thật thư thái bên gia đình và người thương nhé! 🌿☕\n\n"
            "Sau một tuần miệt mài với máy móc, dây chuyền thì cuối tuần là lúc nạp lại năng lượng cho bản thân.\n\n"
            "Sang tuần mới, bạn nào muốn tìm hiểu thêm về các cơ hội việc làm tốt ở các khu công nghiệp Bắc Ninh, Bắc Giang, Hà Nội... thì cứ thoải mái inbox mình tư vấn nhiệt tình nha! 🥰",
            "#cuoituanthugian #chill #chucnghingoi #tuyendungbacninh"
        ],

        # Chủ đề 6: Bàn luận về chọn việc & ổn định cuộc sống
        [
            "Nhiều bạn trẻ hay phân vân: 'Nên chọn công việc nhàn hạ hay chọn công việc có thu nhập tốt hơn nhưng bận rộn hơn?' 🤔\n\n"
            "Quan điểm của mình là: Khi mình còn trẻ, còn sức khỏe thì hãy ưu tiên những nơi cho mình thu nhập xứng đáng với công sức và rèn luyện được tính kiên trì. "
            "Cực một chút ở hiện tại nhưng sau này nhìn lại sẽ không phải hối tiếc vì đã sống hết mình.\n\n"
            "Mỗi giai đoạn cuộc đời sẽ có một ưu tiên khác nhau, quan trọng là mình biết mình cần gì. Còn bạn, ưu tiên hàng đầu khi chọn việc làm lúc này là gì?",
            "#quan_diem_song #dinhhuongnghenghiep #tuoitre #vieclam2026"
        ],
    ]

    CALL_TO_ACTIONS = [
        "👉 Bạn nào đang muốn tìm hiểu thêm về công việc hay môi trường làm việc ở các KCN cứ nhắn tin cho mình nhé, mình hỗ trợ hoàn toàn miễn phí!",
        "💬 Ai có người quen, bạn bè đang cần tìm việc làm ổn định thì kết nối với mình nha, hỗ trợ nhận việc nhanh gọn trong ngày!",
        "✨ Inbox trực tiếp Facebook mình để được giải đáp mọi thắc mắc về chế độ, ký túc xá và tuyến xe đưa đón nha cả nhà!",
        "📩 Luôn sẵn sàng lắng nghe và tư vấn tận tâm cho anh chị em cần tìm bến đỗ công việc vững chắc!",
    ]

    @classmethod
    def generate_personal_post(cls) -> str:
        chosen_topic = random.choice(cls.TOPICS)
        main_content = chosen_topic[0]
        base_tags = chosen_topic[1]

        if random.random() < 0.4:
            extra_cta = random.choice(cls.CALL_TO_ACTIONS)
            post_content = f"{main_content}\n\n{extra_cta}\n\n{base_tags}"
        else:
            post_content = f"{main_content}\n\n{base_tags}"

        return post_content

    @classmethod
    def get_group_content(cls, output_dir: str) -> Tuple[Optional[str], Optional[str]]:
        """
        Lấy nội dung bài viết và ảnh poster để đăng nhóm:
        1. Ưu tiên tìm trong thư mục con output_dir/baidang và output_dir/poster
        2. Fallback: Nếu không có thư mục baidang/poster, quét các folder con 0001, 0002... chứa baidang.txt và poster.jpg
        """
        if not output_dir or not os.path.exists(output_dir):
            return None, None

        baidang_dir = os.path.join(output_dir, "baidang")
        poster_dir = os.path.join(output_dir, "poster")

        if os.path.isdir(baidang_dir) and os.path.isdir(poster_dir):
            txt_files = [f for f in os.listdir(baidang_dir) if f.lower().endswith(".txt")]
            img_files = [f for f in os.listdir(poster_dir) if f.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))]

            if txt_files:
                chosen_txt = random.choice(txt_files)
                txt_path = os.path.join(baidang_dir, chosen_txt)

                prefix = chosen_txt.split("_")[0] if "_" in chosen_txt else os.path.splitext(chosen_txt)[0]
                matched_img = None
                for img in img_files:
                    if img.startswith(prefix):
                        matched_img = img
                        break

                if not matched_img and img_files:
                    matched_img = random.choice(img_files)

                img_path = os.path.join(poster_dir, matched_img) if matched_img else None

                content = None
                for enc in ["utf-8", "utf-8-sig", "latin1"]:
                    try:
                        with open(txt_path, "r", encoding=enc) as f:
                            content = f.read().strip()
                        if content:
                            break
                    except Exception:
                        continue

                if content:
                    abs_img = os.path.abspath(img_path) if (img_path and os.path.exists(img_path)) else None
                    return content, abs_img

        # Fallback cấu trúc thư mục con cũ (0001/baidang.txt...)
        valid_folders = []
        try:
            for item in os.listdir(output_dir):
                folder_path = os.path.join(output_dir, item)
                if os.path.isdir(folder_path):
                    txt_path = os.path.join(folder_path, "baidang.txt")
                    img_path = os.path.join(folder_path, "poster.jpg")
                    if os.path.isfile(txt_path) and os.path.isfile(img_path):
                        valid_folders.append(folder_path)
        except Exception:
            return None, None

        if not valid_folders:
            return None, None

        chosen_folder = random.choice(valid_folders)
        txt_path = os.path.join(chosen_folder, "baidang.txt")
        img_path = os.path.join(chosen_folder, "poster.jpg")

        for enc in ["utf-8", "utf-8-sig", "latin1"]:
            try:
                with open(txt_path, "r", encoding=enc) as f:
                    content = f.read().strip()
                if content:
                    return content, os.path.abspath(img_path)
            except Exception:
                continue

        return None, None

    @classmethod
    def inspect_content_dir(cls, output_dir: str) -> dict:
        """Kiểm tra số lượng bài đăng và ảnh poster trong thư mục"""
        if not output_dir or not os.path.exists(output_dir):
            return {"valid": False, "txt_count": 0, "img_count": 0, "mode": "none"}

        baidang_dir = os.path.join(output_dir, "baidang")
        poster_dir = os.path.join(output_dir, "poster")
        if os.path.isdir(baidang_dir) and os.path.isdir(poster_dir):
            txt_files = [f for f in os.listdir(baidang_dir) if f.lower().endswith(".txt")]
            img_files = [f for f in os.listdir(poster_dir) if f.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))]
            return {
                "valid": len(txt_files) > 0,
                "txt_count": len(txt_files),
                "img_count": len(img_files),
                "mode": "baidang_poster",
            }

        valid_folders = 0
        try:
            for item in os.listdir(output_dir):
                folder_path = os.path.join(output_dir, item)
                if os.path.isdir(folder_path):
                    if os.path.isfile(os.path.join(folder_path, "baidang.txt")):
                        valid_folders += 1
        except Exception:
            pass
        return {
            "valid": valid_folders > 0,
            "txt_count": valid_folders,
            "img_count": valid_folders,
            "mode": "subfolders" if valid_folders > 0 else "empty",
        }
