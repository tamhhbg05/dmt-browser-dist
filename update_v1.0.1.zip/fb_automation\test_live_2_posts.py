"""
Script Demo Trực Tiếp: Tương tác (Thả Tim/Like) và Bình Luận 2 BÀI VIẾT NGẪU NHIÊN trên Facebook
Profile GPM ID: 1e516cb4-e482-459a-9278-1be14766a259
Cửa sổ sẽ được phóng to (Maximize) và giữ mở để bạn nhìn thấy tận mắt!
"""

import sys
import time
import random
from pathlib import Path
import ctypes

# Thêm đường dẫn thư mục hiện tại
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from gpm_controller import GPMController
from fb_bot import FacebookBot
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains

TEST_PROFILE_ID = "1e516cb4-e482-459a-9278-1be14766a259"
GPM_API_BASE = "http://127.0.0.1:9495/api/v1"

def bring_chrome_to_front():
    """Kéo cửa sổ Chrome của GPM lên vị trí trên cùng màn hình để người dùng nhìn thấy ngay"""
    try:
        user32 = ctypes.windll.user32
        def enum_cb(hwnd, lparam):
            if user32.IsWindowVisible(hwnd):
                title = ctypes.create_unicode_buffer(512)
                user32.GetWindowTextW(hwnd, title, 512)
                val = title.value
                if "Facebook" in val or "Chrome" in val or "GPM" in val:
                    user32.ShowWindow(hwnd, 3)  # SW_MAXIMIZE = 3 (Phóng to toàn màn hình)
                    user32.SetForegroundWindow(hwnd)
            return True

        WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_int, ctypes.c_int)
        user32.EnumWindows(WNDENUMPROC(enum_cb), 0)
    except Exception:
        pass

def main():
    print("=" * 80)
    print("   CHẠY TRỰC TIẾP PROFILE GPM: TƯƠNG TÁC & CMT 2 BÀI VIẾT NGẪU NHIÊN TRÊN FEED")
    print(f"   Profile GPM ID: {TEST_PROFILE_ID}")
    print("=" * 80)

    # 1. Kiểm tra kết nối tới GPM API
    print(f"\n[*] Kiểm tra kết nối GPMLogin API tại {GPM_API_BASE}...")
    conn = GPMController.check_connection(api_base=GPM_API_BASE)
    if not conn.get("online"):
        print("[!] Không thể kết nối tới GPMLogin API. Vui lòng mở ứng dụng GPMLogin!")
        return
    print("[OK] Đã kết nối thành công tới GPMLogin!")

    # 2. Khởi động Profile GPM
    print(f"\n[*] Đang mở cửa sổ trình duyệt Chrome của Profile [{TEST_PROFILE_ID}]...")
    driver = None
    try:
        driver = GPMController.create_driver(
            profile_id=TEST_PROFILE_ID,
            api_base=GPM_API_BASE,
            window_size="1400,950",
            window_scale=0.8,
            skip_proxy_check=False
        )
        print("[OK] Đã mở trình duyệt Chrome thành công!")

        # Phóng to cửa sổ và đưa lên trên cùng màn hình
        try:
            driver.maximize_window()
        except Exception:
            pass
        bring_chrome_to_front()

        bot = FacebookBot(
            driver=driver,
            profile_id=TEST_PROFILE_ID,
            target_users=[],
            profile_label="GPM-DEMO",
            comment_texts=[
                "Bài viết rất hay và ý nghĩa bạn ơi 👍",
                "Tuyệt vời quá ạ, tương tác cùng nhau phát triển nhé ❤️",
                "Chúc bạn một ngày mới tràn đầy năng lượng và may mắn!",
                "Rất hữu ích, cảm ơn bạn đã chia sẻ nhé 👍"
            ]
        )

        # 3. Điều hướng vào Facebook
        print("\n[*] Đang vào https://www.facebook.com ... (Hãy nhìn vào màn hình Chrome)")
        driver.get("https://www.facebook.com/")
        time.sleep(4.5)
        bring_chrome_to_front()

        bot.dismiss_alerts()

        # Chọn 2 mốc bài viết ngẫu nhiên để tương tác (ví dụ bài số 2 và bài số 5)
        target_slots = [2, 5]
        print(f"\n[*] Kế hoạch: Sẽ tương tác và bình luận vào bài viết thứ {target_slots[0]} và bài thứ {target_slots[1]} trên Feed!")

        seen_post_keys = set()
        counted_posts = 0
        interacted_count = 0

        for scroll_round in range(1, 30):
            posts = bot._scan_posts_with_poster_names()
            for p in posts:
                key = p.get("postKey") or ""
                if not key or key in seen_post_keys:
                    continue

                seen_post_keys.add(key)
                counted_posts += 1

                author = p.get("primaryAuthor") or "Người dùng Facebook"
                snippet = (p.get("snippet") or "").strip()[:45]
                print(f"   [Bài {counted_posts}] Tác giả: [{author}] - Nội dung: {snippet}...")

                if counted_posts in target_slots:
                    interacted_count += 1
                    print("\n" + "-" * 75)
                    print(f"🎯 [THỰC HIỆN BÀI {interacted_count}/2] Chọn Bài #{counted_posts} của: [{author}]")
                    print("-" * 75)

                    like_btn = p.get("likeBtn")
                    if like_btn:
                        # Cuộn bài viết vào giữa màn hình chậm rãi
                        driver.execute_script(
                            "arguments[0].scrollIntoView({block: 'center', inline: 'nearest', behavior: 'smooth'});",
                            like_btn
                        )
                        time.sleep(2.0)
                        bring_chrome_to_front()

                        # 1. Thao tác cảm xúc: Thả Tim hoặc Like
                        print(f"   ❤️ Đang thả cảm xúc cho bài #{counted_posts}...")
                        if interacted_count == 1:
                            bot._react_love(like_btn)
                        else:
                            bot._react_like(like_btn)
                        time.sleep(2.0)

                        # 2. Thao tác bình luận đúng bài bằng XPath chuẩn
                        print(f"   💬 Đang mở ô bình luận và viết cmt cho bài #{counted_posts}...")
                        ok_cmt = bot._comment_on_post(like_btn, author)
                        time.sleep(2.5)

                        # 3. Đóng bài và tiếp tục lướt
                        print(f"   ❎ Đã đóng bài #{counted_posts}, tiếp tục lướt Feed...")
                        time.sleep(1.5)

                    if interacted_count >= len(target_slots):
                        break

            if interacted_count >= len(target_slots):
                break

            # Cuộn tiếp xuống Feed
            bot.smooth_scroll(random.randint(450, 600))
            time.sleep(random.uniform(2.0, 2.8))

        # Cuộn thêm 2 nhịp để chứng minh bot tiếp tục lướt bình thường
        print("\n[*] Tiếp tục cuộn lướt qua các bài tiếp theo để chứng minh hoạt động liên tục...")
        for _ in range(2):
            bot.smooth_scroll(random.randint(500, 700))
            time.sleep(random.uniform(2.0, 3.0))

        print("\n" + "=" * 80)
        print("   [HOÀN THÀNH XUẤT SẮC] ĐÃ TƯƠNG TÁC & CMT XONG 2 BÀI VIẾT TRỰC TIẾP!")
        print("   Cửa sổ Chrome đang được GIỮ NGUYÊN trên màn hình trong 90 giây để bạn kiểm tra!")
        print("=" * 80)

        # Giữ cửa sổ Chrome mở trong 90 giây để người dùng tha hồ kiểm tra tận mắt
        for remaining in range(90, 0, -10):
            print(f"[*] Cửa sổ Chrome đang mở trên màn hình (còn {remaining}s)...")
            time.sleep(10)

    except Exception as e:
        print(f"\n[X] Lỗi trong quá trình chạy test: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
