import base64
import io
import json
import os
import re
import shutil
import struct
import subprocess
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

import requests
from fastapi import APIRouter, FastAPI, HTTPException
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel

PLUGIN_DIR = Path(__file__).resolve().parent
CONFIG_FILE = PLUGIN_DIR / "config.json"
OUTPUT_DIR = PLUGIN_DIR / "generated_images"
HISTORY_FILE = OUTPUT_DIR / "history_meta.json"
CLIENT_JS_PATH = PLUGIN_DIR / "client.js"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

API_PRESETS = {
    "Tùy chỉnh (Custom API)": {
        "name": "Custom API",
        "base_url": "https://api.example.com/v1",
        "image_path": "/images/generations",
        "edit_path": "/images/edits",
        "video_path": "/videos/generations",
        "models_path": "/models",
        "auth_type": "Bearer",
        "image_model": "gpt-image-1",
        "video_model": "sora-2",
        "available_models": ["gpt-image-1", "dall-e-3", "flux-dev"],
    },
    "cheapkeyai.shop": {
        "name": "cheapkeyai.shop",
        "base_url": "https://cheapkeyai.shop/v1",
        "image_path": "/images/generations",
        "edit_path": "/images/edits",
        "video_path": "/videos/generations",
        "models_path": "/models",
        "auth_type": "Bearer",
        "image_model": "gpt-image-2-c",
        "video_model": "sora-2",
        "available_models": [
            "gpt-image-2-c",
            "gpt-image-2.5-flare-c",
            "gpt-image-2.5-sunburst-c",
            "gpt-image-1",
        ],
    },
    "modelapi.vn (Mặc định)": {
        "name": "modelapi.vn",
        "base_url": "https://modelapi.vn/v1",
        "image_path": "/images/generations",
        "edit_path": "/images/edits",
        "video_path": "/videos/generations",
        "models_path": "/models",
        "auth_type": "Bearer",
        "image_model": "gpt-image-2",
        "video_model": "sora-2",
        "available_models": ["gpt-image-2", "gpt-image-2.5"],
    },
    "ModelGate (intl.modelgate.top)": {
        "name": "ModelGate",
        "base_url": "https://intl.modelgate.top/v1",
        "image_path": "/images/generations",
        "edit_path": "/images/edits",
        "video_path": "/videos/generations",
        "models_path": "/models",
        "auth_type": "Bearer",
        "image_model": "gpt-image-2",
        "video_model": "sora-2",
        "available_models": ["gpt-image-2", "gpt-image-1", "sora-2"],
    },
    "OpenAI Official": {
        "name": "OpenAI Official",
        "base_url": "https://api.openai.com/v1",
        "image_path": "/images/generations",
        "edit_path": "/images/edits",
        "video_path": "/videos/generations",
        "models_path": "/models",
        "auth_type": "Bearer",
        "image_model": "gpt-image-1",
        "video_model": "sora-2",
        "available_models": ["gpt-image-1", "dall-e-3", "dall-e-2"],
    },
    "OpenRouter (openrouter.ai)": {
        "name": "OpenRouter",
        "base_url": "https://openrouter.ai/api/v1",
        "image_path": "/images/generations",
        "edit_path": "/images/edits",
        "video_path": "/videos/generations",
        "models_path": "/models",
        "auth_type": "Bearer",
        "image_model": "openai/gpt-image-1",
        "video_model": "openai/sora-2",
        "available_models": [
            "openai/gpt-image-1",
            "black-forest-labs/flux-1.1-pro",
            "google/gemini-2.5-flash-image-preview",
        ],
    },
    "Together AI (together.xyz)": {
        "name": "Together AI",
        "base_url": "https://api.together.xyz/v1",
        "image_path": "/images/generations",
        "edit_path": "/images/edits",
        "video_path": "/videos/generations",
        "models_path": "/models",
        "auth_type": "Bearer",
        "image_model": "black-forest-labs/FLUX.1-schnell-Free",
        "video_model": "sora-2",
        "available_models": [
            "black-forest-labs/FLUX.1-schnell-Free",
            "black-forest-labs/FLUX.1-dev",
            "black-forest-labs/FLUX.1.1-pro",
        ],
    },
    "SiliconFlow (siliconflow.cn / .com)": {
        "name": "SiliconFlow",
        "base_url": "https://api.siliconflow.cn/v1",
        "image_path": "/images/generations",
        "edit_path": "/images/edits",
        "video_path": "/video/submit",
        "models_path": "/models",
        "auth_type": "Bearer",
        "image_model": "black-forest-labs/FLUX.1-schnell",
        "video_model": "Wan-AI/Wan2.1-T2V-14B",
        "available_models": [
            "black-forest-labs/FLUX.1-schnell",
            "black-forest-labs/FLUX.1-dev",
            "Kwai-Kolors/Kolors",
        ],
    },
    "Google Gemini (OpenAI Compatible)": {
        "name": "Google Gemini",
        "base_url": "https://generativelanguage.googleapis.com/v1beta/openai",
        "image_path": "/images/generations",
        "edit_path": "/images/edits",
        "video_path": "/videos/generations",
        "models_path": "/models",
        "auth_type": "Bearer",
        "image_model": "imagen-3.0-generate-002",
        "video_model": "veo-2.0-generate-001",
        "available_models": ["imagen-3.0-generate-002", "gemini-2.0-flash-exp"],
    },
    "Local / Self-Hosted (SD WebUI / Comfy / LiteLLM)": {
        "name": "Local API",
        "base_url": "http://127.0.0.1:8000/v1",
        "image_path": "/images/generations",
        "edit_path": "/images/edits",
        "video_path": "/videos/generations",
        "models_path": "/models",
        "auth_type": "Bearer",
        "image_model": "sdxl-turbo",
        "video_model": "svd",
        "available_models": ["sdxl-turbo", "flux-schnell"],
    },
}

DEFAULT_PROFILE = {
    "id": "default_modelapi",
    "name": "modelapi.vn",
    "base_url": "https://modelapi.vn/v1",
    "api_key": "",
    "image_path": "/images/generations",
    "edit_path": "/images/edits",
    "video_path": "/videos/generations",
    "models_path": "/models",
    "auth_type": "Bearer",
    "custom_headers": "",
    "timeout": 120,
    "image_model": "gpt-image-2",
    "video_model": "sora-2",
    "available_models": ["gpt-image-2", "gpt-image-2.5"],
}

DEFAULT_CONFIG = {
    "active_profile_id": "default_modelapi",
    "profiles": [DEFAULT_PROFILE.copy()],
    "profile_name": "modelapi.vn",
    "base_url": "https://modelapi.vn/v1",
    "api_key": "",
    "image_path": "/images/generations",
    "video_path": "/videos/generations",
    "image_model": "gpt-image-2",
    "video_model": "sora-2",
    "available_models": ["gpt-image-2", "gpt-image-2.5"],
    "size": "1024x1024",
    "quality": "standard",
    "style": "vivid",
    "n": 1,
}


def join_endpoint(base_url: str, path: str) -> str:
    path = (path or "").strip()
    if path.startswith("http://") or path.startswith("https://"):
        return path
    base = (base_url or "").strip().rstrip("/")
    if not path.startswith("/"):
        path = "/" + path
    if base.endswith("/v1") and path.startswith("/v1/"):
        path = path[3:]
    return f"{base}{path}"


def build_auth_headers(
    api_key: str,
    auth_type: str = "Bearer",
    custom_headers_str: str = "",
    include_json_ct: bool = True,
) -> dict:
    headers = {}
    if include_json_ct:
        headers["Content-Type"] = "application/json"

    api_key = (api_key or "").strip()
    auth_type = (auth_type or "Bearer").strip()

    if api_key and auth_type != "None (Không dùng)":
        if auth_type == "X-API-Key":
            headers["x-api-key"] = api_key
        elif auth_type == "Api-Key":
            headers["api-key"] = api_key
        elif auth_type == "Authorization (Raw)":
            headers["Authorization"] = api_key
        else:
            if api_key.lower().startswith("bearer "):
                headers["Authorization"] = api_key
            else:
                headers["Authorization"] = f"Bearer {api_key}"

    if custom_headers_str and custom_headers_str.strip():
        try:
            extra = json.loads(custom_headers_str.strip())
            if isinstance(extra, dict):
                for k, v in extra.items():
                    headers[str(k)] = str(v)
        except Exception:
            for line in custom_headers_str.strip().splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    headers[k.strip()] = v.strip()

    return headers


def extract_images_from_response(res_data: Any):
    items = []
    revised_prompt = ""

    if not isinstance(res_data, dict):
        return items, revised_prompt

    # 1. OpenAI standard: data: [...]
    if isinstance(res_data.get("data"), list):
        for entry in res_data["data"]:
            if isinstance(entry, dict):
                rp = entry.get("revised_prompt")
                if rp:
                    revised_prompt = rp
                if entry.get("b64_json"):
                    items.append({"type": "b64", "data": entry["b64_json"]})
                elif entry.get("base64"):
                    items.append({"type": "b64", "data": entry["base64"]})
                elif entry.get("url"):
                    items.append({"type": "url", "data": entry["url"]})
                elif entry.get("image_url"):
                    u = entry["image_url"]
                    if isinstance(u, dict) and u.get("url"):
                        items.append({"type": "url", "data": u["url"]})
                    elif isinstance(u, str):
                        items.append({"type": "url", "data": u})
            elif isinstance(entry, str):
                if entry.startswith("http") or entry.startswith("data:image"):
                    items.append({"type": "url", "data": entry})
                else:
                    items.append({"type": "b64", "data": entry})

    # 2. Common arrays: images, output, results, urls, artifacts
    if not items:
        for key in ("images", "output", "results", "urls", "artifacts"):
            arr = res_data.get(key)
            if isinstance(arr, list):
                for entry in arr:
                    if isinstance(entry, str):
                        if entry.startswith(("http://", "https://", "data:image")):
                            items.append({"type": "url", "data": entry})
                        else:
                            items.append({"type": "b64", "data": entry})
                    elif isinstance(entry, dict):
                        if entry.get("b64_json"):
                            items.append({"type": "b64", "data": entry["b64_json"]})
                        elif entry.get("base64"):
                            items.append({"type": "b64", "data": entry["base64"]})
                        elif entry.get("url"):
                            items.append({"type": "url", "data": entry["url"]})
                        elif entry.get("image"):
                            items.append({"type": "url", "data": entry["image"]})
                if items:
                    break

    # 3. Single root fields: url, image, b64_json
    if not items:
        if isinstance(res_data.get("b64_json"), str):
            items.append({"type": "b64", "data": res_data["b64_json"]})
        elif isinstance(res_data.get("url"), str):
            items.append({"type": "url", "data": res_data["url"]})
        elif isinstance(res_data.get("image"), str):
            val = res_data["image"]
            if val.startswith("http") or val.startswith("data:image"):
                items.append({"type": "url", "data": val})
            else:
                items.append({"type": "b64", "data": val})

    # 4. Chat Completions (OpenRouter / Multimodal LLMs)
    if not items and isinstance(res_data.get("choices"), list):
        for ch in res_data["choices"]:
            msg = ch.get("message", {}) if isinstance(ch, dict) else {}
            if isinstance(msg.get("images"), list):
                for im in msg["images"]:
                    if isinstance(im, dict):
                        u = im.get("image_url", {}).get("url") or im.get("url")
                        if u:
                            items.append({"type": "url", "data": u})
                    elif isinstance(im, str):
                        items.append({"type": "url", "data": im})
            content = msg.get("content", "")
            if isinstance(content, str) and content:
                for m in re.finditer(
                    r"(data:image/[a-zA-Z0-9.+-]+;base64,[A-Za-z0-9+/=]+)", content
                ):
                    items.append({"type": "url", "data": m.group(1)})
                if not items:
                    for m in re.finditer(r"https?://[^\s\)\"\'\<\>]+", content):
                        items.append({"type": "url", "data": m.group(0)})

    return items, revised_prompt


def get_image_dimensions(img_bytes: bytes) -> str:
    """Đọc kích thước ảnh WxH (hỗ trợ cả PIL nếu có và parser thuần Python cho PNG/JPEG/WEBP)."""
    try:
        from PIL import Image

        with Image.open(io.BytesIO(img_bytes)) as im:
            return f"{im.width}x{im.height}"
    except Exception:
        pass

    try:
        # PNG
        if len(img_bytes) >= 24 and img_bytes.startswith(b"\x89PNG\r\n\x1a\n"):
            w, h = struct.unpack(">II", img_bytes[16:24])
            return f"{w}x{h}"
        # JPEG
        if len(img_bytes) > 2 and img_bytes.startswith(b"\xff\xd8"):
            idx = 2
            while idx < len(img_bytes) - 8:
                while idx < len(img_bytes) and img_bytes[idx] != 0xFF:
                    idx += 1
                while idx < len(img_bytes) and img_bytes[idx] == 0xFF:
                    idx += 1
                if idx >= len(img_bytes):
                    break
                marker = img_bytes[idx]
                idx += 1
                if marker in (0xD8, 0xD9) or (0xD0 <= marker <= 0xD7):
                    continue
                length = struct.unpack(">H", img_bytes[idx : idx + 2])[0]
                if marker in (0xC0, 0xC1, 0xC2, 0xC3):
                    h, w = struct.unpack(">HH", img_bytes[idx + 3 : idx + 7])
                    return f"{w}x{h}"
                idx += length
    except Exception:
        pass
    return "1024x1024"


def sync_top_level_config(cfg: dict) -> dict:
    profiles = cfg.get("profiles", [])
    active_id = cfg.get("active_profile_id")
    active = None
    for p in profiles:
        if p.get("id") == active_id:
            active = p
            break
    if not active and profiles:
        active = profiles[0]
        cfg["active_profile_id"] = active["id"]
    if not active:
        active = DEFAULT_PROFILE.copy()
        cfg["profiles"] = [active]
        cfg["active_profile_id"] = active["id"]

    cfg["profile_name"] = active.get("name", "modelapi.vn")
    cfg["base_url"] = active.get("base_url", "https://modelapi.vn/v1")
    cfg["api_key"] = active.get("api_key", "")
    cfg["image_path"] = active.get("image_path", "/images/generations")
    cfg["video_path"] = active.get("video_path", "/videos/generations")
    cfg["image_model"] = active.get("image_model", "gpt-image-2")
    cfg["video_model"] = active.get("video_model", "sora-2")
    cfg["available_models"] = active.get("available_models", ["gpt-image-2", "gpt-image-2.5"])
    return cfg


def load_config() -> dict:
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            cfg.update(data)
            if not isinstance(cfg.get("profiles"), list) or len(cfg["profiles"]) == 0:
                migrated = DEFAULT_PROFILE.copy()
                migrated["id"] = "profile_1"
                migrated["name"] = data.get("profile_name", "modelapi.vn")
                migrated["base_url"] = data.get("base_url", "https://modelapi.vn/v1")
                migrated["api_key"] = data.get("api_key", "")
                migrated["image_path"] = data.get("image_path", "/images/generations")
                migrated["video_path"] = data.get("video_path", "/videos/generations")
                migrated["image_model"] = data.get("image_model", "gpt-image-2")
                migrated["video_model"] = data.get("video_model", "sora-2")
                migrated["available_models"] = data.get(
                    "available_models", ["gpt-image-2", "gpt-image-2.5"]
                )
                cfg["profiles"] = [migrated]
                cfg["active_profile_id"] = "profile_1"
            else:
                norm_list = []
                for p in cfg["profiles"]:
                    np = DEFAULT_PROFILE.copy()
                    np.update(p)
                    if not np.get("id"):
                        np["id"] = f"prof_{uuid.uuid4().hex[:6]}"
                    norm_list.append(np)
                cfg["profiles"] = norm_list
        except Exception as e:
            print(f"[ImageStudio] Lỗi đọc config.json: {e}")

    sync_top_level_config(cfg)
    return cfg


def save_config(cfg: dict) -> dict:
    sync_top_level_config(cfg)
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    return cfg


def load_history_meta() -> dict:
    if HISTORY_FILE.exists():
        try:
            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def save_history_meta(meta: dict):
    try:
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def list_generated_images(limit: int = 30) -> list[dict]:
    meta_map = load_history_meta()
    files = []
    for p in OUTPUT_DIR.iterdir():
        if p.is_file() and p.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp"):
            files.append(p)
    files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
    result = []
    for f in files[:limit]:
        m = meta_map.get(f.name, {})
        result.append(
            {
                "filename": f.name,
                "url": f"/api/image-studio/images/{f.name}",
                "path": str(f.resolve()),
                "model": m.get("model", "AI Image"),
                "provider": m.get("provider", "API"),
                "size": m.get("size", "1024x1024"),
                "prompt": m.get("prompt", f.name),
                "revised_prompt": m.get("revised_prompt", ""),
                "time": m.get(
                    "time",
                    datetime.fromtimestamp(f.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                ),
            }
        )
    return result


# ==================== PYDANTIC MODELS ====================

class SaveConfigRequest(BaseModel):
    active_profile_id: Optional[str] = None
    profiles: Optional[list[dict[str, Any]]] = None
    profile_update: Optional[dict[str, Any]] = None


class TestConnectionRequest(BaseModel):
    base_url: str
    api_key: str = ""
    models_path: str = "/models"
    image_path: str = "/images/generations"
    auth_type: str = "Bearer"
    custom_headers: str = ""


class ReferenceImageItem(BaseModel):
    name: str = "reference.png"
    data_url: str


class GenerateImageRequest(BaseModel):
    profile_id: Optional[str] = None
    model: str = "gpt-image-2"
    prompt: str = ""
    size: str = "1024x1024"
    quality: str = "standard"
    style: str = "vivid"
    n: int = 1
    negative_prompt: str = ""
    custom_json: Optional[dict[str, Any]] = None
    reference_images: list[ReferenceImageItem] = []


class GenerateVideoRequest(BaseModel):
    profile_id: Optional[str] = None
    model: str = "sora-2"
    prompt: str = ""
    duration: int = 5
    aspect_ratio: str = "16:9"
    resolution: str = "720p"


class FileActionRequest(BaseModel):
    filename: Optional[str] = None


# ==================== ROUTER ====================

router = APIRouter(prefix="/api/image-studio", tags=["AI Image Studio"])


@router.get("/client.js")
def serve_client_js():
    if not CLIENT_JS_PATH.exists():
        raise HTTPException(status_code=404, detail="Không tìm thấy client.js")
    return FileResponse(
        str(CLIENT_JS_PATH),
        media_type="application/javascript",
        headers={"Cache-Control": "no-store, no-cache, must-revalidate, max-age=0"},
    )


@router.get("/state")
def api_get_state():
    cfg = load_config()
    return {
        "success": True,
        "config": cfg,
        "presets": API_PRESETS,
        "history": list_generated_images(30),
        "plugin_dir": str(PLUGIN_DIR),
        "output_dir": str(OUTPUT_DIR),
    }


@router.post("/config")
def api_save_config(req: SaveConfigRequest):
    cfg = load_config()
    if req.profiles is not None:
        cfg["profiles"] = req.profiles
    if req.active_profile_id:
        cfg["active_profile_id"] = req.active_profile_id
    if req.profile_update:
        target_id = req.profile_update.get("id") or cfg.get("active_profile_id")
        updated = False
        for idx, p in enumerate(cfg.get("profiles", [])):
            if p.get("id") == target_id:
                merged = DEFAULT_PROFILE.copy()
                merged.update(p)
                merged.update(req.profile_update)
                cfg["profiles"][idx] = merged
                updated = True
                break
        if not updated:
            merged = DEFAULT_PROFILE.copy()
            merged.update(req.profile_update)
            if not merged.get("id"):
                merged["id"] = f"prof_{uuid.uuid4().hex[:6]}"
            cfg.setdefault("profiles", []).append(merged)
            cfg["active_profile_id"] = merged["id"]

    saved = save_config(cfg)
    return {"success": True, "config": saved}


@router.post("/test-connection")
def api_test_connection(req: TestConnectionRequest):
    base_url = (req.base_url or "https://modelapi.vn/v1").strip()
    api_key = (req.api_key or "").strip()
    models_path = (req.models_path or "/models").strip() or "/models"
    image_path = (req.image_path or "/images/generations").strip() or "/images/generations"
    auth_type = req.auth_type or "Bearer"
    custom_headers = req.custom_headers or ""

    headers = build_auth_headers(api_key, auth_type, custom_headers, include_json_ct=False)

    candidate_urls = list(
        dict.fromkeys(
            [
                join_endpoint(base_url, models_path),
                join_endpoint(base_url, "/v1/models"),
            ]
        )
    )

    last_err = ""
    for url in candidate_urls:
        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200:
                data = r.json()
                models_list = []
                raw_list = []
                if isinstance(data, dict):
                    raw_list = data.get("data") or data.get("models") or []
                elif isinstance(data, list):
                    raw_list = data

                for item in raw_list:
                    if isinstance(item, dict):
                        m_id = item.get("id") or item.get("name") or item.get("model")
                        if m_id:
                            models_list.append(str(m_id))
                    elif isinstance(item, str):
                        models_list.append(item)

                if models_list:
                    return {
                        "success": True,
                        "partial": False,
                        "tested_url": url,
                        "models": models_list,
                        "message": f"Kết nối thành công ({url})! Tìm thấy {len(models_list)} model.",
                    }
            else:
                last_err = f"HTTP {r.status_code} tại {url}: {r.text[:200]}"
        except Exception as e:
            last_err = f"{url} -> {str(e)}"

    # Fallback: thử POST rỗng tới image_path
    img_url = join_endpoint(base_url, image_path)
    try:
        headers_post = build_auth_headers(api_key, auth_type, custom_headers, include_json_ct=True)
        r = requests.post(img_url, headers=headers_post, json={}, timeout=12)
        if r.status_code in (200, 400, 422):
            return {
                "success": True,
                "partial": True,
                "tested_url": img_url,
                "models": [],
                "message": (
                    f"Máy chủ API phản hồi tại {img_url} (HTTP {r.status_code}). "
                    f"API này không cung cấp danh sách /models tự động — bạn có thể tự gõ tên Model vào ô Model để sử dụng!"
                ),
            }
        else:
            last_err = f"HTTP {r.status_code} tại {img_url}: {r.text[:250]}"
    except Exception as e:
        if not last_err:
            last_err = str(e)

    return {
        "success": False,
        "error": f"Lỗi kết nối API: {last_err}",
    }


@router.post("/generate")
def api_generate_image(req: GenerateImageRequest):
    cfg = load_config()
    profiles = cfg.get("profiles", [])
    target_id = req.profile_id or cfg.get("active_profile_id")
    prof = None
    for p in profiles:
        if p.get("id") == target_id:
            prof = p
            break
    if not prof:
        prof = profiles[0] if profiles else DEFAULT_PROFILE.copy()

    base_url = prof.get("base_url", "https://modelapi.vn/v1")
    img_path = prof.get("image_path", "/images/generations")
    edit_path = prof.get("edit_path", "/images/edits")
    api_key = prof.get("api_key", "").strip()
    auth_type = prof.get("auth_type", "Bearer")
    custom_headers = prof.get("custom_headers", "")
    timeout_sec = max(10, int(prof.get("timeout", 120) or 120))

    if not api_key and auth_type != "None (Không dùng)":
        return {
            "success": False,
            "error": "Vui lòng nhập API Key cho nguồn API này ở phần Cài đặt API!",
        }

    model = (req.model or prof.get("image_model") or "gpt-image-2").strip()
    prompt = (req.prompt or "").strip()

    if not prompt and not req.custom_json:
        return {"success": False, "error": "Vui lòng nhập mô tả ảnh (Prompt)!"}

    # Lưu lại model vừa chọn vào profile
    prof["image_model"] = model
    if model not in prof.get("available_models", []):
        prof.setdefault("available_models", []).insert(0, model)
    save_config(cfg)

    size_raw = (req.size or "").strip()
    size = None if (not size_raw or size_raw.lower().startswith("auto")) else size_raw.split()[0]

    quality_raw = (req.quality or "").strip()
    quality = (
        None if (not quality_raw or quality_raw.lower().startswith("auto")) else quality_raw
    )

    style_raw = (req.style or "").strip()
    style = None if (not style_raw or style_raw.lower().startswith("auto")) else style_raw

    neg_prompt = (req.negative_prompt or "").strip()
    n = max(1, min(4, int(req.n or 1)))

    try:
        # Trường hợp 1: Có ảnh tham chiếu -> gửi multipart/form-data tới Image Edit Path
        if req.reference_images and req.custom_json is None:
            endpoint = join_endpoint(base_url, edit_path)
            headers = build_auth_headers(api_key, auth_type, custom_headers, include_json_ct=False)
            form_data = {"model": model, "prompt": prompt}
            if size:
                form_data["size"] = size

            field_name = "image" if len(req.reference_images) == 1 else "image[]"
            files_payload = []
            for idx, ref_item in enumerate(req.reference_images):
                durl = ref_item.data_url or ""
                if "," in durl:
                    durl = durl.split(",", 1)[1]
                raw_bytes = base64.b64decode(durl)
                fname = ref_item.name or f"ref_{idx+1}.png"
                files_payload.append((field_name, (fname, raw_bytes, "image/png")))

            r = requests.post(
                endpoint,
                headers=headers,
                data=form_data,
                files=files_payload,
                timeout=timeout_sec,
            )

        # Trường hợp 2: Gửi JSON tới Image Generation Path
        else:
            endpoint = join_endpoint(base_url, img_path)
            headers = build_auth_headers(api_key, auth_type, custom_headers, include_json_ct=True)

            if req.custom_json is not None:
                payload = req.custom_json
            elif "/chat/completions" in endpoint:
                payload = {
                    "model": model,
                    "messages": [{"role": "user", "content": prompt}],
                }
            else:
                payload = {
                    "model": model,
                    "prompt": prompt,
                    "n": n,
                }
                if size:
                    payload["size"] = size
                if quality:
                    payload["quality"] = quality
                if style:
                    payload["style"] = style
                if neg_prompt:
                    payload["negative_prompt"] = neg_prompt

            r = requests.post(endpoint, headers=headers, json=payload, timeout=timeout_sec)

            # Tự động fallback nếu API bên thứ 3 không hỗ trợ tham số phụ (quality / style)
            if (
                r.status_code in (400, 422)
                and req.custom_json is None
                and ("quality" in payload or "style" in payload)
            ):
                err_lower = r.text.lower()
                if any(
                    k in err_lower
                    for k in (
                        "quality",
                        "style",
                        "extra_forbidden",
                        "unknown",
                        "unrecognized",
                        "invalid",
                        "parameter",
                    )
                ):
                    minimal_payload = {"model": model, "prompt": prompt}
                    if size:
                        minimal_payload["size"] = size
                    if n > 1:
                        minimal_payload["n"] = n
                    r_retry = requests.post(
                        endpoint, headers=headers, json=minimal_payload, timeout=timeout_sec
                    )
                    if r_retry.status_code == 200:
                        r = r_retry

        try:
            res_json = r.json()
        except Exception:
            res_json = None

        raw_response_data = res_json if res_json is not None else r.text

        if r.status_code != 200:
            err_text = r.text[:400]
            if isinstance(res_json, dict) and "error" in res_json:
                err_text = json.dumps(res_json["error"], ensure_ascii=False)
            return {
                "success": False,
                "error": f"HTTP {r.status_code} ({endpoint}): {err_text}",
                "raw_response": raw_response_data,
            }

        if not isinstance(res_json, dict):
            return {
                "success": False,
                "error": f"Phản hồi từ API không phải JSON hợp lệ: {r.text[:300]}",
                "raw_response": raw_response_data,
            }

        extracted_items, revised_prompt_text = extract_images_from_response(res_json)
        if not extracted_items:
            return {
                "success": False,
                "error": "API trả về thành công nhưng không tìm thấy dữ liệu ảnh. Bấm '{ } Xem JSON API' để kiểm tra cấu trúc trả về.",
                "raw_response": raw_response_data,
            }

        meta_map = load_history_meta()
        saved_items = []

        for idx, item in enumerate(extracted_items):
            img_bytes = None
            itype = item.get("type")
            idata = item.get("data", "")

            if itype == "b64":
                if "," in idata and idata.startswith("data:"):
                    idata = idata.split(",", 1)[1]
                img_bytes = base64.b64decode(idata)
            elif itype == "url":
                if idata.startswith("data:image") and "," in idata:
                    b64_part = idata.split(",", 1)[1]
                    img_bytes = base64.b64decode(b64_part)
                else:
                    img_url = idata if idata.startswith("http") else join_endpoint(base_url, idata)
                    resp_img = requests.get(img_url, timeout=45)
                    img_bytes = resp_img.content

            if img_bytes:
                safe_model = re.sub(r"[^a-zA-Z0-9_.-]+", "_", model)[:35]
                timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
                file_name = f"{safe_model}_{timestamp_str}_{idx+1}.png"
                save_path = OUTPUT_DIR / file_name
                with open(save_path, "wb") as f:
                    f.write(img_bytes)

                dim_str = get_image_dimensions(img_bytes)
                now_display = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                item_meta = {
                    "filename": file_name,
                    "url": f"/api/image-studio/images/{file_name}",
                    "path": str(save_path.resolve()),
                    "model": model,
                    "provider": prof.get("name", "API"),
                    "size": dim_str,
                    "prompt": prompt,
                    "revised_prompt": revised_prompt_text,
                    "time": now_display,
                }
                meta_map[file_name] = item_meta
                saved_items.append(item_meta)

        save_history_meta(meta_map)

        if not saved_items:
            return {
                "success": False,
                "error": "Không thể giải mã dữ liệu ảnh thành công!",
                "raw_response": raw_response_data,
            }

        return {
            "success": True,
            "items": saved_items,
            "revised_prompt": revised_prompt_text,
            "raw_response": raw_response_data,
        }

    except Exception as e:
        return {
            "success": False,
            "error": str(e),
        }


@router.post("/generate-video")
def api_generate_video(req: GenerateVideoRequest):
    cfg = load_config()
    profiles = cfg.get("profiles", [])
    target_id = req.profile_id or cfg.get("active_profile_id")
    prof = None
    for p in profiles:
        if p.get("id") == target_id:
            prof = p
            break
    if not prof:
        prof = profiles[0] if profiles else DEFAULT_PROFILE.copy()

    api_key = prof.get("api_key", "").strip()
    auth_type = prof.get("auth_type", "Bearer")
    if not api_key and auth_type != "None (Không dùng)":
        return {
            "success": False,
            "error": "Vui lòng nhập API Key ở tab Cài đặt API!",
        }

    prompt = (req.prompt or "").strip()
    if not prompt:
        return {"success": False, "error": "Vui lòng nhập mô tả video (Prompt)!"}

    endpoint = join_endpoint(
        prof.get("base_url", ""), prof.get("video_path", "/videos/generations")
    )
    headers = build_auth_headers(
        api_key, auth_type, prof.get("custom_headers", ""), include_json_ct=True
    )
    payload = {
        "model": (req.model or "sora-2").strip(),
        "prompt": prompt,
        "duration": req.duration,
        "aspect_ratio": req.aspect_ratio,
        "resolution": req.resolution,
    }
    try:
        r = requests.post(
            endpoint,
            headers=headers,
            json=payload,
            timeout=max(10, int(prof.get("timeout", 120) or 120)),
        )
        try:
            body_data = r.json()
        except Exception:
            body_data = r.text
        ok = 200 <= r.status_code < 300
        return {
            "success": ok,
            "status_code": r.status_code,
            "endpoint": endpoint,
            "response": body_data,
        }
    except Exception as e:
        return {
            "success": False,
            "status_code": 0,
            "endpoint": endpoint,
            "error": str(e),
        }


@router.get("/images/{filename}")
def serve_generated_image(filename: str):
    safe_name = os.path.basename(filename)
    fpath = OUTPUT_DIR / safe_name
    if not fpath.exists():
        raise HTTPException(status_code=404, detail="Không tìm thấy ảnh")
    return FileResponse(str(fpath))


@router.delete("/images/{filename}")
def delete_generated_image(filename: str):
    safe_name = os.path.basename(filename)
    fpath = OUTPUT_DIR / safe_name
    if fpath.exists():
        try:
            fpath.unlink()
        except Exception:
            pass
    meta_map = load_history_meta()
    if safe_name in meta_map:
        meta_map.pop(safe_name, None)
        save_history_meta(meta_map)
    return {"success": True}


@router.post("/open-image")
def api_open_image(req: FileActionRequest):
    if not req.filename:
        return {"success": False, "error": "Thiếu tên file"}
    fpath = OUTPUT_DIR / os.path.basename(req.filename)
    if not fpath.exists():
        return {"success": False, "error": "File không tồn tại"}
    if os.name == "nt":
        os.startfile(str(fpath.resolve()))
    return {"success": True}


@router.post("/open-folder")
def api_open_folder(req: Optional[FileActionRequest] = None):
    try:
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        folder_str = str(OUTPUT_DIR.resolve())
        if os.name == "nt":
            if req and req.filename:
                fpath = OUTPUT_DIR / os.path.basename(req.filename)
                if fpath.exists():
                    try:
                        # Windows Explorer yêu cầu chuỗi dạng explorer.exe /select,"C:\Path"
                        # Truyền dạng string để Python không bao ngoặc kép quanh switch /select,
                        subprocess.Popen(f'explorer.exe /select,"{str(fpath.resolve())}"')
                        return {"success": True, "path": str(fpath.resolve())}
                    except Exception:
                        pass
            # Mở trực tiếp thư mục lưu ảnh
            os.startfile(folder_str)
            return {"success": True, "path": folder_str}
        elif os.name == "posix":
            opener = "open" if sys.platform == "darwin" else "xdg-open"
            subprocess.Popen([opener, folder_str])
            return {"success": True, "path": folder_str}
    except Exception as e:
        return {"success": False, "error": str(e)}
    return {"success": True}


@router.post("/save-as")
def api_save_image_as(req: FileActionRequest):
    if not req.filename:
        return {"success": False, "error": "Thiếu tên file"}
    src_path = OUTPUT_DIR / os.path.basename(req.filename)
    if not src_path.exists():
        return {"success": False, "error": "Ảnh không tồn tại"}

    try:
        import webview

        if webview.windows:
            win = webview.windows[0]
            target = win.create_file_dialog(
                webview.SAVE_DIALOG,
                directory=str(Path.home() / "Desktop"),
                save_filename=src_path.name,
                file_types=("PNG Image (*.png)", "All files (*.*)"),
            )
            if target:
                dst = target[0] if isinstance(target, (list, tuple)) else str(target)
                if dst:
                    shutil.copy2(str(src_path), dst)
                    return {"success": True, "saved_to": dst}
            return {"success": False, "cancelled": True}
    except Exception:
        pass

    return {"success": False, "fallback_download": True}


def register_image_studio(app: FastAPI, base_dir: Optional[Path] = None):
    """Đăng ký router tạo ảnh vào FastAPI app của DMT Browser."""
    app.include_router(router)
