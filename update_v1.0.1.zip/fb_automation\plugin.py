import json
import os
import queue
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel

if os.name == "nt":
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

from .content_generator import ContentGenerator
from .dmt_controller import DMTController
from .fb_bot import FacebookBot
from .gpm_controller import DEFAULT_GPM_API_BASE, GPMController

PLUGIN_DIR = Path(__file__).resolve().parent
BASE_DIR = PLUGIN_DIR.parent
CONFIG_FILE = PLUGIN_DIR / "config.json"
USER_PERSIST_CONFIG_FILE = BASE_DIR / "profiles_data" / "fb_automation_config.json"
CLIENT_JS_PATH = PLUGIN_DIR / "client.js"
ID_PROFILE_FILE = PLUGIN_DIR / "id_profile.txt"
ID_PROFILE_DMT_FILE = PLUGIN_DIR / "id_profile_dmt.txt"
USER_FILE = PLUGIN_DIR / "user.txt"


def _default_content_dir() -> str:
    candidates = [
        PLUGIN_DIR / "baidang",
        BASE_DIR.parent / "Auto_Create_Contents" / "output",
        Path.home() / "Desktop" / "Auto_Create_Contents" / "output",
    ]
    for c in candidates:
        if c.exists():
            return str(c)
    return str(candidates[-1])


def _read_lines_file(fpath: Path) -> List[str]:
    if not fpath.exists():
        return []
    try:
        raw = fpath.read_text(encoding="utf-8", errors="ignore")
        return [l.strip() for l in raw.splitlines() if l.strip() and not l.strip().startswith("#")]
    except Exception:
        return []


def _get_initial_gpm_profiles() -> List[str]:
    return _read_lines_file(ID_PROFILE_FILE)


def _get_initial_target_users() -> List[str]:
    return _read_lines_file(USER_FILE)


DEFAULT_CONFIG: Dict[str, Any] = {
    "engine": "dmt",  # "dmt" | "gpm"
    "dmt_profile_ids": [],
    "gpm_profile_ids": [],
    "gpm_all_profile_ids": [],
    "target_users": [],
    "content_output_dir": _default_content_dir(),
    "campaigns": [],
    "gpm_api_base": DEFAULT_GPM_API_BASE,
    "skip_proxy_check": True,
    "max_threads": 5,
    "max_groups_to_post": 5,
    "reels_to_watch": 6,
    "feed_scroll_count": 10,
    "max_groups_to_visit": 2,
    "enable_step1": True,
    "enable_step2": True,
    "enable_step3": True,
    "enable_nick_page_two_way": False,
    "enable_auto_repeat": False,
    "repeat_delay_minutes": 30,
    "enable_window_layout": True,
    "auto_fit_screen": True,
    "window_width": 1100,
    "window_height": 900,
    "window_scale": 0.70,
}


def _dedup_list(items: List[Any]) -> List[str]:
    seen = set()
    out: List[str] = []
    for x in items or []:
        s = str(x).strip()
        if s and s not in seen:
            seen.add(s)
            out.append(s)
    return out


def _normalize_campaigns(raw_campaigns: Any, fallback_dir: str = "") -> List[Dict[str, Any]]:
    if not isinstance(raw_campaigns, list):
        return []
    normalized: List[Dict[str, Any]] = []
    seen_ids = set()
    for idx, item in enumerate(raw_campaigns):
        if not isinstance(item, dict):
            continue
        cid = str(item.get("id") or f"camp_{idx + 1}").strip()
        if not cid or cid in seen_ids:
            cid = f"camp_{idx + 1}_{int(time.time() * 1000) % 100000}"
        seen_ids.add(cid)
        name = str(item.get("name") or f"Chiến dịch {idx + 1}").strip() or f"Chiến dịch {idx + 1}"
        enabled = bool(item.get("enabled", True))
        content_dir = str(item.get("content_dir") if item.get("content_dir") is not None else fallback_dir).strip()
        pids = _dedup_list(item.get("profile_ids") or [])
        normalized.append({
            "id": cid,
            "name": name,
            "enabled": enabled,
            "content_dir": content_dir,
            "profile_ids": pids,
        })
    return normalized


def _resolve_profile_campaign_map(cfg: Dict[str, Any]) -> Dict[str, Dict[str, str]]:
    """Ánh xạ mỗi profile_id sang Chiến dịch đang bật (hoặc Chiến dịch đã gán) để lấy thư mục bài đăng riêng"""
    mapping: Dict[str, Dict[str, str]] = {}
    fallback_dir = str(cfg.get("content_output_dir") or "").strip()
    campaigns = cfg.get("campaigns") or []

    # Ưu tiên các chiến dịch đang bật (enabled=True) trước, sau đó đến chiến dịch đã gán
    for pass_enabled in (True, False):
        for c in campaigns:
            if not isinstance(c, dict):
                continue
            if bool(c.get("enabled", True)) != pass_enabled:
                continue
            c_id = str(c.get("id") or "").strip()
            c_name = str(c.get("name") or "Chiến dịch").strip()
            c_dir = str(c.get("content_dir") or "").strip() or fallback_dir
            for pid in c.get("profile_ids") or []:
                clean_pid = str(pid).strip()
                if clean_pid and clean_pid not in mapping:
                    mapping[clean_pid] = {
                        "campaign_id": c_id,
                        "campaign_name": c_name,
                        "content_dir": c_dir,
                        "enabled": "1" if pass_enabled else "0",
                    }
    return mapping


def _inspect_campaigns_info(campaigns: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    info: Dict[str, Dict[str, Any]] = {}
    for c in campaigns or []:
        if not isinstance(c, dict):
            continue
        cid = str(c.get("id") or "").strip()
        cdir = str(c.get("content_dir") or "").strip()
        if cid:
            info[cid] = ContentGenerator.inspect_content_dir(cdir)
    return info


def load_config() -> Dict[str, Any]:
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    if CONFIG_FILE.exists():
        try:
            data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                cfg.update(data)
        except Exception as e:
            print(f"[FBAutomation] Lỗi đọc config.json: {e}")

    # Ưu tiên nạp cấu hình riêng của người dùng trong profiles_data (giúp khi chép đè folder fb_automation không mất cấu hình cũ của khách)
    if USER_PERSIST_CONFIG_FILE.exists():
        try:
            user_data = json.loads(USER_PERSIST_CONFIG_FILE.read_text(encoding="utf-8"))
            if isinstance(user_data, dict):
                cfg.update(user_data)
        except Exception:
            pass

    try:
        dmt_rows = DMTController.list_dmt_profiles()
        dmt_ids = {str(r["id"]).strip() for r in dmt_rows}
    except Exception:
        dmt_ids = set()

    file_gpm_ids = [x for x in _get_initial_gpm_profiles() if x not in dmt_ids]
    combined_gpm_all = _dedup_list(
        [x for x in (cfg.get("gpm_all_profile_ids") or []) if x not in dmt_ids]
        + file_gpm_ids
        + [x for x in (cfg.get("gpm_profile_ids") or []) if x not in dmt_ids]
    )
    cfg["gpm_all_profile_ids"] = combined_gpm_all

    if not cfg.get("gpm_profile_ids") and combined_gpm_all and "gpm_profile_ids" not in cfg:
        cfg["gpm_profile_ids"] = list(combined_gpm_all)
    else:
        cfg["gpm_profile_ids"] = _dedup_list([x for x in (cfg.get("gpm_profile_ids") or []) if x not in dmt_ids])

    if dmt_ids and isinstance(cfg.get("dmt_profile_ids"), list):
        cfg["dmt_profile_ids"] = [x for x in cfg["dmt_profile_ids"] if str(x).strip() in dmt_ids]

    if not cfg.get("target_users"):
        cfg["target_users"] = _get_initial_target_users()

    # Nếu danh sách dmt_profile_ids chưa được chọn lần nào, mặc định chọn toàn bộ DMT profiles hiện có
    if "dmt_profile_ids" not in cfg or (not CONFIG_FILE.exists() and not USER_PERSIST_CONFIG_FILE.exists() and not cfg["dmt_profile_ids"]):
        dmt_rows = DMTController.list_dmt_profiles()
        cfg["dmt_profile_ids"] = [r["id"] for r in dmt_rows]

    cfg["campaigns"] = _normalize_campaigns(cfg.get("campaigns"), str(cfg.get("content_output_dir") or ""))

    return cfg


def save_config(cfg: Dict[str, Any]) -> Dict[str, Any]:
    merged = load_config()
    explicit_all_gpm = "gpm_all_profile_ids" in cfg
    merged.update(cfg)

    try:
        dmt_rows = DMTController.list_dmt_profiles()
        dmt_ids = {str(r["id"]).strip() for r in dmt_rows}
    except Exception:
        dmt_ids = set()

    # Chuẩn hóa list & ngăn chặn triệt để lây chéo ID giữa DMT và GPM
    if isinstance(merged.get("dmt_profile_ids"), list):
        merged["dmt_profile_ids"] = _dedup_list(merged["dmt_profile_ids"])
        if dmt_ids:
            merged["dmt_profile_ids"] = [x for x in merged["dmt_profile_ids"] if str(x).strip() in dmt_ids]
    if isinstance(merged.get("gpm_profile_ids"), list):
        merged["gpm_profile_ids"] = _dedup_list([x for x in merged["gpm_profile_ids"] if str(x).strip() not in dmt_ids])
    if isinstance(merged.get("gpm_all_profile_ids"), list):
        merged["gpm_all_profile_ids"] = _dedup_list([x for x in merged["gpm_all_profile_ids"] if str(x).strip() not in dmt_ids])
    if isinstance(merged.get("target_users"), list):
        merged["target_users"] = _dedup_list(merged["target_users"])
    merged["campaigns"] = _normalize_campaigns(merged.get("campaigns"), str(merged.get("content_output_dir") or ""))

    if explicit_all_gpm:
        # Khi người dùng chủ động sửa danh sách gốc GPM (thêm/xóa ID), giữ các ID đang chọn nằm trong danh sách gốc
        valid_gpm = set(merged["gpm_all_profile_ids"])
        if "gpm_profile_ids" not in cfg:
            merged["gpm_profile_ids"] = [x for x in merged["gpm_profile_ids"] if x in valid_gpm]
    else:
        # Khi chỉ tích chọn / bỏ chọn profile để chạy, tuyệt đối KHÔNG xóa các profile chưa chọn khỏi danh sách gốc
        merged["gpm_all_profile_ids"] = _dedup_list(
            [x for x in list(merged.get("gpm_all_profile_ids") or []) if str(x).strip() not in dmt_ids]
            + [x for x in list(merged.get("gpm_profile_ids") or []) if str(x).strip() not in dmt_ids]
        )

    json_txt = json.dumps(merged, ensure_ascii=False, indent=2)
    CONFIG_FILE.write_text(json_txt, encoding="utf-8")

    try:
        if USER_PERSIST_CONFIG_FILE.parent.exists():
            USER_PERSIST_CONFIG_FILE.write_text(json_txt, encoding="utf-8")
    except Exception:
        pass

    # Đồng bộ danh sách gốc GPM ra id_profile.txt (không ghi đè bằng tập con đang tick chọn)
    try:
        ID_PROFILE_FILE.write_text("\n".join(merged["gpm_all_profile_ids"]) + "\n", encoding="utf-8")
        ID_PROFILE_DMT_FILE.write_text("\n".join(merged["dmt_profile_ids"]) + "\n", encoding="utf-8")
        USER_FILE.write_text("\n".join(merged["target_users"]) + "\n", encoding="utf-8")
    except Exception:
        pass

    return merged


# ==================== RUNTIME STATE MANAGER ====================

class AutomationRuntime:
    def __init__(self):
        self.lock = threading.Lock()
        self.is_running: bool = False
        self.current_engine: str = "dmt"
        self.cycle: int = 1
        self.running_count: int = 0
        self.completed_count: int = 0
        self.total_count: int = 0
        self.status_text: str = "Trạng thái: Sẵn sàng"
        self.countdown_text: str = "⏱️ Đếm ngược: Chưa kích hoạt"
        self.waiting_next: Optional[str] = None
        self.can_skip_wait: bool = False
        self.stop_event = threading.Event()
        self.skip_wait_event = threading.Event()
        self.slot_queue: queue.Queue = queue.Queue()
        self.profile_states: Dict[str, Dict[str, str]] = {}
        self.logs: List[str] = []
        self.max_logs: int = 2500

    def append_log(self, msg: str):
        text = msg.rstrip("\n")
        if not text:
            return
        with self.lock:
            for line in text.splitlines():
                self.logs.append(line)
            if len(self.logs) > self.max_logs:
                self.logs = self.logs[-self.max_logs:]
        print(text, flush=True)

    def clear_logs(self):
        with self.lock:
            self.logs.clear()

    def update_profile_state(self, pid: str, status: str, badge: str, color: str):
        with self.lock:
            self.profile_states[pid] = {
                "status": status,
                "badge": badge,
                "color": color,
            }

    def get_snapshot(self, log_offset: int = 0) -> Dict[str, Any]:
        with self.lock:
            total_logs = len(self.logs)
            if log_offset < 0 or log_offset > total_logs:
                log_offset = 0
            new_logs = self.logs[log_offset:]
            return {
                "is_running": self.is_running,
                "current_engine": self.current_engine,
                "cycle": self.cycle,
                "running_count": self.running_count,
                "completed_count": self.completed_count,
                "total_count": self.total_count,
                "status_text": self.status_text,
                "countdown_text": self.countdown_text,
                "waiting_next": self.waiting_next,
                "can_skip_wait": self.can_skip_wait,
                "profile_states": dict(self.profile_states),
                "new_logs": new_logs,
                "next_log_offset": total_logs,
            }


RUNTIME = AutomationRuntime()


def get_dynamic_scale(num_profiles: int) -> float:
    """
    Tự động điều chỉnh scale theo số lượng profile chạy đồng thời:
    - 1 profile: scale 1.0 (chuẩn)
    - 2 profiles: scale 0.85
    - 3 - 4 profiles: scale 0.75
    - 5 - 6 profiles: scale 0.65
    - 7 - 8 profiles: scale 0.55
    - 9+ profiles: scale 0.50
    """
    if num_profiles <= 1:
        return 1.0
    elif num_profiles == 2:
        return 0.85
    elif num_profiles <= 4:
        return 0.75
    elif num_profiles <= 6:
        return 0.65
    elif num_profiles <= 8:
        return 0.55
    else:
        return 0.50


def _normalize_scale(val: Any) -> float:
    try:
        s = float(val)
        if s > 5.0:  # Người dùng điền 60 hoặc 50 thay vì 0.60 hoặc 0.50
            s = s / 100.0
        if 0.2 <= s <= 2.0:
            return round(s, 2)
    except Exception:
        pass
    return 0.60


def _get_real_screen_work_area():
    """Lấy kích thước thực tế vùng làm việc của màn hình (DPI-Aware, trừ taskbar)"""
    screen_w, screen_h = 1920, 1080
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes
            # Đảm bảo tiến trình DPI-Aware để lấy đúng độ phân giải vật lý (không bị co lại khi Windows scale 125%/150%)
            try:
                ctypes.windll.shcore.SetProcessDpiAwareness(2)
            except Exception:
                try:
                    ctypes.windll.user32.SetProcessDPIAware()
                except Exception:
                    pass

            user32 = ctypes.windll.user32
            rc = wintypes.RECT()
            # SPI_GETWORKAREA = 0x0030
            if user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(rc), 0):
                w_real = rc.right - rc.left
                h_real = rc.bottom - rc.top
                if w_real > 400 and h_real > 300:
                    screen_w, screen_h = w_real, h_real
            else:
                w_real = user32.GetSystemMetrics(0)
                h_real = user32.GetSystemMetrics(1)
                if w_real > 400 and h_real > 300:
                    screen_w, screen_h = w_real, h_real
        except Exception:
            pass
    return screen_w, screen_h


def _get_window_layout(
    slot_id: int,
    cfg: Optional[Dict[str, Any]] = None,
    enable_layout: Optional[bool] = None,
    window_scale: Optional[float] = None,
    num_running: int = 1,
):
    if cfg is None:
        cfg = {}

    enable = bool(cfg.get("enable_window_layout", True) if enable_layout is None else enable_layout)

    # 1. Lấy kích thước thực tế vùng làm việc của màn hình (DPI-Aware)
    screen_w, screen_h = _get_real_screen_work_area()

    # 2. Scale thu phóng (mặc định 70% = 0.70)
    raw_scale = cfg.get("window_scale") if window_scale is None else window_scale
    calc_scale = _normalize_scale(raw_scale) if raw_scale is not None else 0.70

    # 3. Kích thước người dùng cài đặt: Dài (Ngang = width) và Rộng (Dọc = height)
    try:
        base_w = int(cfg.get("window_width") or 1100)
        base_h = int(cfg.get("window_height") or 900)
    except Exception:
        base_w, base_h = 1100, 900

    base_w = max(200, base_w)
    base_h = max(150, base_h)

    # Kích thước cố định đúng chuẩn công thức: Dài * Scale, Rộng * Scale
    w = max(200, int(base_w * calc_scale))
    h = max(150, int(base_h * calc_scale))

    # Tính số cột xếp vừa theo chiều ngang và số hàng xếp vừa theo chiều dọc:
    cols = max(1, screen_w // w)
    rows = max(1, screen_h // h)
    # Nếu chiều cao còn lại chứa được ít nhất 85% chiều cao cửa sổ thì cho phép xếp thêm 1 hàng để tránh dồn hết lên hàng 1
    if screen_h >= int(h * 1.8) and (screen_h - (rows * h)) >= int(h * 0.6):
        rows += 1

    # Tổng số ô có thể chứa trên toàn bộ màn hình
    total_slots = max(1, cols * rows)

    # Hết cả ngang và dọc thì quay vòng lại từ vị trí Profile 1 (0, 0)
    slot_idx = slot_id % total_slots

    col = slot_idx % cols
    row = slot_idx // cols

    x = col * w
    y = min(row * h, max(0, screen_h - h))

    if not enable:
        return None, f"{w},{h}", calc_scale

    return f"{x},{y}", f"{w},{h}", calc_scale





def _automation_worker():
    cycle = 1
    while RUNTIME.is_running and not RUNTIME.stop_event.is_set():
        cfg = load_config()
        engine = (cfg.get("engine") or "dmt").lower()
        RUNTIME.current_engine = engine

        dmt_map = {r["id"]: r for r in DMTController.list_dmt_profiles()}
        campaign_map = _resolve_profile_campaign_map(cfg)

        if engine == "dmt":
            profiles = [pid for pid in cfg.get("dmt_profile_ids", []) if pid in dmt_map]
            if not profiles and campaign_map:
                profiles = [pid for pid, info in campaign_map.items() if info.get("enabled") == "1" and pid in dmt_map]
        else:
            profiles = [pid for pid in cfg.get("gpm_profile_ids", []) if pid and pid not in dmt_map]
            if not profiles and campaign_map:
                profiles = [pid for pid, info in campaign_map.items() if info.get("enabled") == "1" and pid and pid not in dmt_map]

        target_users = cfg.get("target_users") or []
        if USER_FILE.exists():
            disk_users = _get_initial_target_users()
            if disk_users:
                target_users = _dedup_list(list(target_users) + disk_users)
        total_p = len(profiles)

        if not profiles:
            RUNTIME.append_log("⚠️ [HỆ THỐNG] Danh sách Profile đang chọn trống! Dừng tiến trình.")
            break

        max_threads = max(1, min(10, int(cfg.get("max_threads", 5))))
        engine_label = "DMT BROWSER (CAMOUFOX C++)" if engine == "dmt" else "GPMLOGIN (PORT 9495)"
        active_campaigns = [c for c in (cfg.get("campaigns") or []) if c.get("enabled", True) and c.get("profile_ids")]

        RUNTIME.cycle = cycle
        RUNTIME.total_count = total_p
        RUNTIME.running_count = 0
        RUNTIME.completed_count = 0
        RUNTIME.waiting_next = None
        RUNTIME.can_skip_wait = False
        RUNTIME.status_text = f"Đang chạy lượt #{cycle} ({engine.upper()})"
        RUNTIME.countdown_text = f"⏱️ Đang chạy lượt #{cycle}..."

        RUNTIME.append_log("=" * 64)
        RUNTIME.append_log(f"🤖 [LƯỢT #{cycle}] BẮT ĐẦU CHẠY AUTO ĐĂNG BÀI & NUÔI NICK — ENGINE: {engine_label}")
        RUNTIME.append_log(
            f"   Tổng số Profile: {total_p} | Số luồng: {max_threads} | Chiến dịch đang bật: {len(active_campaigns)} | Target Users: {len(target_users)}"
        )
        for c in active_campaigns:
            RUNTIME.append_log(
                f"   🗂️ Chiến dịch [{c.get('name')}]: {len(c.get('profile_ids') or [])} Profile ➔ 📁 {c.get('content_dir') or cfg.get('content_output_dir')}"
            )
        RUNTIME.append_log("=" * 64)

        for pid in profiles:
            c_info = campaign_map.get(pid)
            wait_msg = f"[{c_info['campaign_name']}] Đang xếp hàng chờ luồng..." if c_info else "Đang xếp hàng chờ luồng..."
            RUNTIME.update_profile_state(pid, wait_msg, "⏳ Đang chờ", "#f59e0b")

        while not RUNTIME.slot_queue.empty():
            try:
                RUNTIME.slot_queue.get_nowait()
            except Exception:
                break
        for i in range(max_threads):
            RUNTIME.slot_queue.put(i)

        def process_one(profile_id: str) -> bool:
            if not RUNTIME.is_running or RUNTIME.stop_event.is_set():
                return False

            slot_id = RUNTIME.slot_queue.get()
            num_concurrent = min(total_p, max_threads)
            win_pos, win_size, win_scale = _get_window_layout(
                slot_id,
                cfg=cfg,
                num_running=num_concurrent,
            )

            if engine == "dmt" and profile_id in dmt_map:
                p_name = dmt_map[profile_id].get("name") or profile_id[:8]
                profile_label = f"DMT:{p_name}"
            else:
                profile_label = f"GPM:{profile_id[:8]}"

            camp_info = campaign_map.get(profile_id)
            camp_name = (camp_info.get("campaign_name") if camp_info else "") or "Mặc định"
            profile_content_dir = (
                (camp_info.get("content_dir") if camp_info else "")
                or str(cfg.get("content_output_dir", "")).strip()
            )
            short_folder = os.path.basename(profile_content_dir.rstrip("\\/")) or profile_content_dir

            with RUNTIME.lock:
                RUNTIME.running_count += 1
                RUNTIME.status_text = f"Đang chạy lượt #{cycle} ({RUNTIME.running_count} luồng)"
            driver = None
            MAX_ATTEMPTS = 3
            last_err = None

            try:
                for attempt in range(1, MAX_ATTEMPTS + 1):
                    if not RUNTIME.is_running or RUNTIME.stop_event.is_set():
                        return False

                    attempt_label = f" (Lần {attempt}/3)" if attempt > 1 else ""
                    RUNTIME.update_profile_state(
                        profile_id,
                        f"[{camp_name}] Đang mở trình duyệt{attempt_label} (Ô #{slot_id})...",
                        "🟢 Đang mở",
                        "#10b981",
                    )
                    RUNTIME.append_log(
                        f"▶️ [Lượt #{cycle}] BẮT ĐẦU PROFILE: {profile_label} ({profile_id[:8]}){attempt_label} - Ô #{slot_id} (Cố định: {win_size}, Scale: {win_scale}) | 🗂️ [{camp_name}] ➔ 📁 {profile_content_dir}"
                    )

                    driver = None
                    try:
                        if engine == "dmt":
                            driver = DMTController.create_driver(
                                profile_id,
                                window_pos=win_pos,
                                window_size=win_size,
                                window_scale=win_scale,
                                skip_proxy_check=bool(cfg.get("skip_proxy_check", True)),
                                max_retries=2,
                                log_fn=RUNTIME.append_log,
                            )
                        else:
                            driver = GPMController.create_driver(
                                profile_id,
                                api_base=cfg.get("gpm_api_base", DEFAULT_GPM_API_BASE),
                                skip_proxy_check=bool(cfg.get("skip_proxy_check", True)),
                                window_pos=win_pos,
                                window_size=win_size,
                                window_scale=win_scale,
                                max_retries=2,
                                log_fn=RUNTIME.append_log,
                            )


                        # Mở trình duyệt thành công -> Chuyển sang chạy kịch bản
                        break

                    except Exception as launch_err:
                        last_err = launch_err
                        err_str = str(launch_err)
                        if engine == "dmt":
                            DMTController.safe_close(driver, profile_id)
                        else:
                            GPMController.safe_close(driver, profile_id, api_base=cfg.get("gpm_api_base", DEFAULT_GPM_API_BASE))
                        driver = None

                        if attempt < MAX_ATTEMPTS:
                            retry_msg = f"Gặp lỗi mở Profile/Proxy ({err_str[:45]}...). Chạy lại {attempt + 1}/3 sau 3s..."
                            RUNTIME.append_log(f"⚠️ [{profile_label}] {retry_msg}")
                            RUNTIME.update_profile_state(profile_id, retry_msg, f"🔄 Thử {attempt + 1}/3", "#f59e0b")
                            time.sleep(3.0)
                        else:
                            raise last_err

                if driver is None:
                    raise (last_err or RuntimeError("Không thể khởi động trình duyệt sau 3 lần thử"))

                bot = FacebookBot(
                    driver=driver,
                    profile_id=profile_id,
                    target_users=target_users,
                    profile_label=profile_label,
                    log_fn=RUNTIME.append_log,
                    stop_event=RUNTIME.stop_event,
                    react_rate=float(cfg.get("user_post_react_rate", 0.30)),
                    like_rate=float(cfg.get("user_post_like_rate", 0.70)),
                    comment_rate=float(cfg.get("user_post_comment_rate", 0.05)),
                    comment_texts=cfg.get("user_post_comment_texts", None),
                )


                two_way_nick_page = bool(cfg.get("enable_nick_page_two_way", False))

                # 1. Nếu bật "Tương tác 2 chiều nick-page": Khi mở profile -> Chuyển về Nick chính qua Accounts Center
                if two_way_nick_page and RUNTIME.is_running and not RUNTIME.stop_event.is_set():
                    RUNTIME.update_profile_state(
                        profile_id,
                        f"[{camp_name}] Đang chuyển về Nick chính...",
                        "🔄 Chuyển Nick",
                        "#0ea5e9",
                    )
                    bot.check_accounts_center_on_open()
                    time.sleep(1.5)

                # 2. BƯỚC 1: Lướt Feed, Reels, Story & Tương tác Target Users (Tương tác Nick)
                if (cfg.get("enable_step1", True) or two_way_nick_page) and RUNTIME.is_running and not RUNTIME.stop_event.is_set():
                    b1_status = f"[{camp_name}] B1 (Nick): Lướt Feed & Reels..." if two_way_nick_page else f"[{camp_name}] B1: Lướt Feed, Reels & Story..."
                    b1_badge = "🔵 B1: Nick" if two_way_nick_page else "🔵 B1: Lướt Feed"
                    RUNTIME.update_profile_state(profile_id, b1_status, b1_badge, "#3b82f6")
                    bot.run_step1_interact(
                        feed_scroll_count=int(cfg.get("feed_scroll_count", 10)),
                        stories_count=1,
                        reels_count=int(cfg.get("reels_to_watch", 6)),
                    )
                    time.sleep(2.0)

                # 3 & 4. Nếu bật "Tương tác 2 chiều nick-page": Chuyển sang Page -> Thực hiện lại Bước 1 (Feed & Reels) tương tác Page
                if two_way_nick_page and RUNTIME.is_running and not RUNTIME.stop_event.is_set():
                    RUNTIME.update_profile_state(
                        profile_id,
                        f"[{camp_name}] Đang chuyển từ Nick sang Page (0 -> 3)...",
                        "🔄 Chuyển Page",
                        "#ec4899",
                    )
                    bot.switch_to_page()
                    time.sleep(1.5)

                    if RUNTIME.is_running and not RUNTIME.stop_event.is_set():
                        RUNTIME.update_profile_state(
                            profile_id,
                            f"[{camp_name}] B1 (Page): Lướt Feed & Reels...",
                            "🌸 B1: Page",
                            "#db2777",
                        )
                        bot.run_step1_interact(
                            feed_scroll_count=int(cfg.get("feed_scroll_count", 10)),
                            stories_count=1,
                            reels_count=int(cfg.get("reels_to_watch", 6)),
                        )
                        time.sleep(2.0)

                # 5. BƯỚC 2 (Nhóm) và BƯỚC 3 (Nhóm)
                # BƯỚC 2: Quét nhóm đã tham gia -> Chọn ngẫu nhiên N nhóm -> Đăng bài kèm ảnh từ thư mục của Chiến dịch
                if cfg.get("enable_step2", True) and RUNTIME.is_running and not RUNTIME.stop_event.is_set():
                    RUNTIME.update_profile_state(
                        profile_id,
                        f"[{camp_name}] B2: Đăng nhóm từ 📁 {short_folder}...",
                        "🟣 B2: Đăng nhóm",
                        "#8b5cf6",
                    )
                    bot.log(f"🗂️ [Chiến dịch: {camp_name}] Sử dụng thư mục bài đăng riêng: {profile_content_dir}")
                    bot.run_step2_post_to_selected_groups(
                        output_dir=profile_content_dir,
                        num_groups=int(cfg.get("max_groups_to_post", 5)),
                    )
                    time.sleep(2.0)

                # BƯỚC 3: Vào nhóm tương tác bài của Target Users
                if cfg.get("enable_step3", True) and RUNTIME.is_running and not RUNTIME.stop_event.is_set():
                    RUNTIME.update_profile_state(profile_id, f"[{camp_name}] B3: Tương tác bài nhóm Target...", "🟠 B3: Nhóm", "#f97316")
                    bot.run_step3_group_interact(
                        max_groups=int(cfg.get("max_groups_to_visit", 2)),
                        scroll_per_group=6,
                    )
                    time.sleep(1.5)

                if RUNTIME.stop_event.is_set():
                    RUNTIME.update_profile_state(profile_id, "Đã dừng theo yêu cầu", "⏹️ Đã dừng", "#64748b")
                    return False

                bot.log(f"🏁 ĐÃ HOÀN TẤT KỊCH BẢN CHO PROFILE {profile_label} [{camp_name}] (LƯỢT #{cycle})!")
                RUNTIME.update_profile_state(profile_id, f"[{camp_name}] Đã hoàn thành toàn bộ kịch bản", "✅ Hoàn tất", "#10b981")
                return True

            except Exception as e:
                RUNTIME.append_log(f"❌ [{profile_label}] Gặp lỗi: {e}")
                RUNTIME.update_profile_state(profile_id, f"Lỗi: {str(e)[:45]}", "❌ Lỗi", "#ef4444")
                return False

            finally:
                if engine == "dmt":
                    DMTController.safe_close(driver, profile_id)
                else:
                    GPMController.safe_close(driver, profile_id, api_base=cfg.get("gpm_api_base", DEFAULT_GPM_API_BASE))

                RUNTIME.slot_queue.put(slot_id)
                with RUNTIME.lock:
                    RUNTIME.running_count = max(0, RUNTIME.running_count - 1)
                    RUNTIME.completed_count += 1

        FIXED_LAUNCH_DELAY = 2.5  # Cố định độ trễ 2.5s mở lần lượt từng profile, chống nghẽn Proxy và quá tải CPU
        with ThreadPoolExecutor(max_workers=max_threads) as executor:
            futures = []
            for idx, pid in enumerate(profiles):
                if not RUNTIME.is_running or RUNTIME.stop_event.is_set():
                    break
                if idx > 0:
                    # Đợi profile trước mở xong theo nhịp 2.5s
                    stop_waited = RUNTIME.stop_event.wait(FIXED_LAUNCH_DELAY)
                    if stop_waited or not RUNTIME.is_running:
                        break
                futures.append(executor.submit(process_one, pid))

            for _ in as_completed(futures):
                if not RUNTIME.is_running or RUNTIME.stop_event.is_set():
                    break

        if not RUNTIME.is_running or RUNTIME.stop_event.is_set():
            break

        RUNTIME.append_log(f"🎉 [LƯỢT #{cycle}] ĐÃ HOÀN TẤT TOÀN BỘ {RUNTIME.completed_count}/{total_p} PROFILE!")

        # Kiểm tra hẹn giờ lặp lại
        cfg_latest = load_config()
        if not cfg_latest.get("enable_auto_repeat", False) or not RUNTIME.is_running or RUNTIME.stop_event.is_set():
            break

        try:
            delay_min = float(cfg_latest.get("repeat_delay_minutes", 30))
            if delay_min <= 0:
                delay_min = 1.0
        except Exception:
            delay_min = 30.0

        total_seconds = int(delay_min * 60)
        RUNTIME.append_log(f"⏳ [HẸN GIỜ] Đang hẹn giờ chạy lại lượt #{cycle + 1} sau {delay_min} phút...")
        RUNTIME.can_skip_wait = True
        RUNTIME.skip_wait_event.clear()

        remaining = total_seconds
        while remaining > 0 and RUNTIME.is_running and not RUNTIME.stop_event.is_set():
            if not load_config().get("enable_auto_repeat", False):
                RUNTIME.append_log("ℹ️ [HẸN GIỜ] Người dùng đã tắt Tự động lặp lại. Dừng hẹn giờ.")
                break

            if RUNTIME.skip_wait_event.is_set():
                RUNTIME.append_log(f"⚡ [HẸN GIỜ] Người dùng bấm 'Chạy ngay'! Bắt đầu lượt #{cycle + 1}...")
                break

            mins, secs = divmod(remaining, 60)
            hours, mins = divmod(mins, 60)
            time_str = f"{hours:02d}:{mins:02d}:{secs:02d}" if hours > 0 else f"{mins:02d}:{secs:02d}"

            RUNTIME.waiting_next = time_str
            RUNTIME.countdown_text = f"⏱️ Chạy lại lượt #{cycle + 1} sau: {time_str}"
            RUNTIME.status_text = f"Đang chờ lượt #{cycle + 1} ({time_str})"

            if RUNTIME.stop_event.wait(timeout=1.0):
                break
            remaining -= 1

        RUNTIME.can_skip_wait = False
        RUNTIME.waiting_next = None

        if not RUNTIME.is_running or RUNTIME.stop_event.is_set() or not load_config().get("enable_auto_repeat", False):
            break

        cycle += 1

    with RUNTIME.lock:
        RUNTIME.is_running = False
        RUNTIME.running_count = 0
        RUNTIME.can_skip_wait = False
        RUNTIME.waiting_next = None
        RUNTIME.status_text = "Trạng thái: Sẵn sàng"
        RUNTIME.countdown_text = "⏱️ Đếm ngược: Chưa kích hoạt"

    RUNTIME.append_log("🏁 [HỆ THỐNG] TIẾN TRÌNH TỰ ĐỘNG HÓA ĐÃ KẾT THÚC.")


# ==================== PYDANTIC MODELS ====================

class SaveAutomationConfigRequest(BaseModel):
    config: Dict[str, Any]


class StartAutomationRequest(BaseModel):
    config: Optional[Dict[str, Any]] = None


class PickFolderRequest(BaseModel):
    campaign_id: Optional[str] = None
    initial_dir: Optional[str] = None


class OpenFolderRequest(BaseModel):
    path: Optional[str] = None


# ==================== FASTAPI ROUTER ====================

router = APIRouter(prefix="/api/fb-automation", tags=["FB Recruitment Automation"])


@router.get("/client.js")
def serve_client_js():
    if not CLIENT_JS_PATH.exists():
        raise HTTPException(status_code=404, detail="Không tìm thấy client.js")
    return FileResponse(
        str(CLIENT_JS_PATH),
        media_type="application/javascript",
        headers={"Cache-Control": "no-store, no-cache, must-revalidate, max-age=0"},
    )


@router.get("/state")
def api_get_state(log_offset: int = 0):
    cfg = load_config()
    dmt_profiles = DMTController.list_dmt_profiles()
    content_info = ContentGenerator.inspect_content_dir(cfg.get("content_output_dir", ""))
    campaigns_info = _inspect_campaigns_info(cfg.get("campaigns") or [])
    runtime_snap = RUNTIME.get_snapshot(log_offset=log_offset)
    return {
        "success": True,
        "config": cfg,
        "dmt_profiles": dmt_profiles,
        "content_info": content_info,
        "campaigns_info": campaigns_info,
        "runtime": runtime_snap,
    }


@router.post("/config")
def api_save_config(req: SaveAutomationConfigRequest):
    saved = save_config(req.config)
    content_info = ContentGenerator.inspect_content_dir(saved.get("content_output_dir", ""))
    campaigns_info = _inspect_campaigns_info(saved.get("campaigns") or [])
    return {
        "success": True,
        "config": saved,
        "content_info": content_info,
        "campaigns_info": campaigns_info,
    }


@router.get("/gpm-status")
def api_check_gpm_status(api_base: Optional[str] = None):
    cfg = load_config()
    base = api_base or cfg.get("gpm_api_base", DEFAULT_GPM_API_BASE)
    res = GPMController.check_connection(base)
    return {"success": True, **res}


def _open_native_folder_dialog(init_dir: str) -> Optional[str]:
    if not init_dir or not os.path.exists(init_dir):
        init_dir = str(Path.home() / "Desktop")
    try:
        import webview
        if webview.windows:
            win = webview.windows[0]
            target = win.create_file_dialog(
                webview.FOLDER_DIALOG,
                directory=init_dir,
            )
            if target:
                chosen = target[0] if isinstance(target, (list, tuple)) else str(target)
                if chosen:
                    return os.path.abspath(chosen)
            return None
    except Exception:
        pass

    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        chosen = filedialog.askdirectory(initialdir=init_dir, title="Chọn thư mục chứa bài đăng & ảnh poster")
        root.destroy()
        if chosen:
            return os.path.abspath(chosen)
    except Exception:
        pass
    return None


@router.post("/browse-folder")
def api_browse_folder():
    cfg = load_config()
    init_dir = cfg.get("content_output_dir") or str(Path.home() / "Desktop")
    chosen_abs = _open_native_folder_dialog(init_dir)
    if chosen_abs:
        saved = save_config({"content_output_dir": chosen_abs})
        return {
            "success": True,
            "path": chosen_abs,
            "content_info": ContentGenerator.inspect_content_dir(chosen_abs),
            "campaigns_info": _inspect_campaigns_info(saved.get("campaigns") or []),
            "config": saved,
        }
    return {"success": False, "cancelled": True}


@router.post("/pick-folder")
def api_pick_campaign_folder(req: Optional[PickFolderRequest] = None):
    cfg = load_config()
    init_dir = (req.initial_dir if req and req.initial_dir else None) or cfg.get("content_output_dir") or str(Path.home() / "Desktop")
    chosen_abs = _open_native_folder_dialog(init_dir)
    if not chosen_abs:
        return {"success": False, "cancelled": True}

    campaigns = list(cfg.get("campaigns") or [])
    if req and req.campaign_id:
        for c in campaigns:
            if isinstance(c, dict) and str(c.get("id")) == str(req.campaign_id):
                c["content_dir"] = chosen_abs
                break
        saved = save_config({"campaigns": campaigns})
    else:
        saved = cfg

    return {
        "success": True,
        "path": chosen_abs,
        "content_info": ContentGenerator.inspect_content_dir(chosen_abs),
        "campaigns_info": _inspect_campaigns_info(saved.get("campaigns") or []),
        "config": saved,
    }


@router.post("/open-folder")
def api_open_content_folder(req: Optional[OpenFolderRequest] = None):
    cfg = load_config()
    folder = (req.path if req and req.path else None) or cfg.get("content_output_dir", "")
    if folder and os.path.exists(folder):
        if os.name == "nt":
            os.startfile(os.path.abspath(folder))
        return {"success": True}
    return {"success": False, "error": f"Thư mục không tồn tại: {folder}"}


@router.post("/start")
def api_start_automation(req: StartAutomationRequest):
    if RUNTIME.is_running:
        return {"success": False, "error": "Tiến trình đang chạy!"}

    if req.config:
        cfg = save_config(req.config)
    else:
        cfg = load_config()

    engine = (cfg.get("engine") or "dmt").lower()
    campaign_map = _resolve_profile_campaign_map(cfg)
    if engine == "dmt":
        dmt_ids = {r["id"] for r in DMTController.list_dmt_profiles()}
        selected = [pid for pid in cfg.get("dmt_profile_ids", []) if pid in dmt_ids]
        if not selected and campaign_map:
            selected = [pid for pid, info in campaign_map.items() if info.get("enabled") == "1" and pid in dmt_ids]
        if not selected:
            return {
                "success": False,
                "error": "Vui lòng chọn ít nhất 1 Profile DMT Browser hoặc bật ít nhất 1 Chiến dịch!",
            }
    else:
        dmt_ids = {r["id"] for r in DMTController.list_dmt_profiles()}
        selected = [pid for pid in cfg.get("gpm_profile_ids", []) if pid and pid not in dmt_ids]
        if not selected and campaign_map:
            selected = [pid for pid, info in campaign_map.items() if info.get("enabled") == "1" and pid and pid not in dmt_ids]
        if not selected:
            return {
                "success": False,
                "error": "Vui lòng chọn ít nhất 1 Profile GPMLogin hoặc bật ít nhất 1 Chiến dịch!",
            }

    RUNTIME.is_running = True
    RUNTIME.stop_event.clear()
    RUNTIME.skip_wait_event.clear()

    worker = threading.Thread(target=_automation_worker, daemon=True)
    worker.start()

    return {"success": True, "engine": engine, "profiles_count": len(selected)}


@router.post("/stop")
def api_stop_automation():
    if not RUNTIME.is_running:
        return {"success": True}
    RUNTIME.stop_event.set()
    RUNTIME.skip_wait_event.set()
    RUNTIME.append_log("⚠️ [HỆ THỐNG] ĐÃ GỬI TÍN HIỆU DỪNG TIẾN TRÌNH VÀ HỦY HẸN GIỜ...")
    return {"success": True}


@router.post("/skip-wait")
def api_skip_wait():
    RUNTIME.skip_wait_event.set()
    return {"success": True}


@router.post("/clear-logs")
def api_clear_logs():
    RUNTIME.clear_logs()
    return {"success": True}


def register_fb_automation(app: FastAPI, base_dir: Optional[Path] = None):
    """Đăng ký router Tự động hóa Đăng bài & Nuôi nick FB vào DMT Browser"""
    app.include_router(router)
