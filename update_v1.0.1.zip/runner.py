import argparse
import html
import json
import os
import pickle
import sqlite3
import sys
import time
import traceback
from pathlib import Path
from typing import Optional
import threading
from urllib.parse import urlparse

import psutil

# Ép chuẩn UTF-8 cho stdout/stderr trên Windows để không bao giờ lỗi UnicodeEncodeError hoặc NoneType
if sys.stdout is None or sys.stderr is None:
    _devnull = open(os.devnull, "w", encoding="utf-8", errors="replace")
    if sys.stdout is None:
        sys.stdout = _devnull
    if sys.stderr is None:
        sys.stderr = _devnull
elif hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

BASE_DIR = Path(__file__).resolve().parent
RUNTIME_DIR = BASE_DIR / "runtime"
CAMOUFOX_CACHE_DIR = RUNTIME_DIR / "camoufox_cache"
DB_PATH = BASE_DIR / "profiles.db"
PROFILES_DIR = BASE_DIR / "profiles_data"

# Ép Camoufox sử dụng thư mục cache cục bộ nằm ngay trong thư mục dự án (Portable 100%)
CAMOUFOX_CACHE_DIR.mkdir(parents=True, exist_ok=True)
import platformdirs
platformdirs.user_cache_dir = lambda appname="camoufox", *args, **kwargs: str(CAMOUFOX_CACHE_DIR)

# Cấu hình thanh công cụ chuẩn khớp kVersion=26 của Firefox 156 giúp luôn đặt nút '+' (new-tab-button) ngay cạnh tab đang mở
UI_CUSTOMIZATION_STATE = json.dumps({
    "placements": {
        "widget-overflow-fixed-list": [],
        "unified-extensions-area": [],
        "nav-bar": [
            "back-button",
            "forward-button",
            "stop-reload-button",
            "vertical-spacer",
            "urlbar-container",
            "downloads-button",
            "unified-extensions-button",
            "ublock0_raymondhill_net-browser-action",
        ],
        "toolbar-menubar": ["menubar-items"],
        "TabsToolbar": [
            "tabbrowser-tabs",
            "new-tab-button",
            "spring",
            "alltabs-button",
        ],
        "vertical-tabs": [],
        "PersonalToolbar": ["personal-bookmarks"],
    },
    "seen": [
        "developer-button",
        "ublock0_raymondhill_net-browser-action",
        "reset-pbm-toolbar-button",
        "smartwindow-group-tabs-button",
        "ai-window-toggle",
    ],
    "dirtyAreaCache": [
        "nav-bar",
        "TabsToolbar",
        "vertical-tabs",
        "PersonalToolbar",
        "toolbar-menubar",
    ],
    "currentVersion": 26,
    "newElementCount": 0,
})


def ensure_newtab_button_visible(user_data_dir: Path):
    """
    Đảm bảo nút '+' mở tab mới luôn hiển thị trên thanh Tab của trình duyệt Camoufox
    và thanh địa chỉ có thể tìm kiếm Google trên mọi Tab:
    1. Tạo chrome/userChrome.css hiển thị nút #tabs-newtab-button và #new-tab-button.
    2. Xóa cấu hình browser.uiCustomization.state lỗi trong prefs.js (nếu có).
    3. Xóa cache search.json.mozlz4 cũ (nếu có) để nhận Google Search mặc định từ policies.json.
    """
    try:
        chrome_dir = user_data_dir / "chrome"
        chrome_dir.mkdir(parents=True, exist_ok=True)
        css_path = chrome_dir / "userChrome.css"
        css_content = """/* DMT Browser: Always show '+' New Tab button right next to open tabs */
#tabbrowser-tabs[orient="horizontal"] > #tabbrowser-arrowscrollbox > #tabbrowser-arrowscrollbox-periphery > #tabs-newtab-button,
#tabs-newtab-button,
#TabsToolbar #new-tab-button {
  display: flex !important;
  visibility: visible !important;
  opacity: 1 !important;
  pointer-events: auto !important;
  align-items: center !important;
}
"""
        css_path.write_text(css_content, encoding="utf-8")

        prefs_file = user_data_dir / "prefs.js"
        if prefs_file.exists():
            lines = prefs_file.read_text(encoding="utf-8", errors="ignore").splitlines()
            filtered = [
                line for line in lines
                if '"browser.uiCustomization.state"' not in line
                and '"browser.newtabpage.enabled"' not in line
            ]
            prefs_file.write_text("\n".join(filtered) + "\n", encoding="utf-8")

        # Xóa cache search engine cũ (127.0.0.1) một lần để nạp Google Search từ policies.json
        search_fixed_flag = user_data_dir / ".dmt_google_search_v1"
        if not search_fixed_flag.exists():
            search_cache = user_data_dir / "search.json.mozlz4"
            if search_cache.exists():
                try:
                    search_cache.unlink()
                except Exception:
                    pass
            try:
                search_fixed_flag.touch()
            except Exception:
                pass
    except Exception as e:
        print(f"[Runner] Lưu ý khi cấu hình thanh Tab: {e}")


def parse_proxy(proxy_str: str):
    if not proxy_str or not proxy_str.strip():
        return None

    raw = proxy_str.strip()
    if raw.lower() in ("none", "local", "direct", "no"):
        return None

    scheme = "http"
    rest = raw
    if "://" in raw:
        parts = raw.split("://", 1)
        scheme = parts[0].lower()
        rest = parts[1]

    if "@" in rest:
        parsed = urlparse(f"{scheme}://{rest}")
        proxy_dict = {
            "server": f"{scheme}://{parsed.hostname}:{parsed.port}"
        }
        if parsed.username:
            proxy_dict["username"] = parsed.username
        if parsed.password:
            proxy_dict["password"] = parsed.password
        return proxy_dict

    def _sanitize_port(p_val: str) -> str:
        p_clean = str(p_val).strip()
        if p_clean.isdigit():
            p_int = int(p_clean)
            if p_int > 65535 and p_clean.startswith("101") and len(p_clean) == 6:
                return "10" + p_clean[3:]
        return p_clean

    segments = rest.split(":")
    if len(segments) == 2:
        host, port = segments[0], _sanitize_port(segments[1])
        return {"server": f"{scheme}://{host}:{port}"}
    elif len(segments) >= 4:
        host = segments[0]
        port = _sanitize_port(segments[1])
        username = segments[2]
        password = ":".join(segments[3:])
        return {
            "server": f"{scheme}://{host}:{port}",
            "username": username,
            "password": password,
        }

    else:
        return {"server": f"{scheme}://{rest}"}


def get_profile_from_db(profile_id: str):
    if not DB_PATH.exists():
        return None
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT * FROM profiles WHERE id = ?", (profile_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def apply_fingerprint_overrides(
    fp: dict,
    custom_gpu: Optional[str] = None,
    custom_cpu: Optional[int] = None,
    custom_ram: Optional[int] = None,
    custom_screen: Optional[str] = None,
) -> dict:
    if not isinstance(fp, dict):
        return fp

    # Đảm bảo ngôn ngữ mặc định luôn là tiếng Anh
    if "navigator" in fp and isinstance(fp["navigator"], dict):
        fp["navigator"]["languages"] = ["en-US", "en"]
        fp["navigator"]["language"] = "en-US"

    # CPU Cores (Hardware Concurrency)
    if custom_cpu and int(custom_cpu) > 0:
        if "navigator" not in fp or not isinstance(fp["navigator"], dict):
            fp["navigator"] = {}
        fp["navigator"]["hardwareConcurrency"] = int(custom_cpu)

    # RAM (Device Memory in GB)
    if custom_ram and int(custom_ram) > 0:
        if "navigator" not in fp or not isinstance(fp["navigator"], dict):
            fp["navigator"] = {}
        fp["navigator"]["deviceMemory"] = int(custom_ram)

    # Screen resolution
    if custom_screen and "x" in str(custom_screen):
        try:
            parts = str(custom_screen).lower().split("x")
            w = int(parts[0].strip())
            h = int(parts[1].strip())
            if "screen" not in fp or not isinstance(fp["screen"], dict):
                fp["screen"] = {}
            fp["screen"]["width"] = w
            fp["screen"]["height"] = h
            fp["screen"]["availWidth"] = w
            fp["screen"]["availHeight"] = max(h - 40, 600)
        except Exception:
            pass

    # GPU / WebGL Renderer
    if custom_gpu and str(custom_gpu).strip() and str(custom_gpu).strip().lower() != "auto":
        gpu_key = str(custom_gpu).strip()
        gpu_map = {
            "rtx4070": ("Google Inc. (NVIDIA)", "ANGLE (NVIDIA, NVIDIA GeForce RTX 4070 Direct3D11 vs_5_0 ps_5_0)"),
            "rtx3060": ("Google Inc. (NVIDIA)", "ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0)"),
            "gtx1660s": ("Google Inc. (NVIDIA)", "ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 SUPER Direct3D11 vs_5_0 ps_5_0)"),
            "rx6700xt": ("Google Inc. (AMD)", "ANGLE (AMD, AMD Radeon RX 6700 XT Direct3D11 vs_5_0 ps_5_0)"),
            "iris_xe": ("Google Inc. (Intel)", "ANGLE (Intel, Intel(R) Iris(R) Xe Graphics Direct3D11 vs_5_0 ps_5_0)"),
            "apple_m2": ("Apple", "Apple M2"),
        }
        if gpu_key in gpu_map:
            vendor, renderer = gpu_map[gpu_key]
        elif "::" in gpu_key:
            parts = gpu_key.split("::", 1)
            vendor, renderer = parts[0], parts[1]
        else:
            vendor = "Google Inc. (NVIDIA)"
            renderer = gpu_key

        for k in ("webgl", "webgl2", "gpu", "videoCard"):
            if k in fp and isinstance(fp[k], dict):
                fp[k]["vendor"] = vendor
                fp[k]["renderer"] = renderer
            elif k in ("webgl", "webgl2"):
                fp[k] = {"vendor": vendor, "renderer": renderer}

    return fp


def extract_fingerprint_summary(fp, os_type: str = "windows"):
    if isinstance(fp, dict):
        nav = fp.get("navigator") or {}
        scr = fp.get("screen") or {}
        gpu = fp.get("webgl") or fp.get("gpu") or fp.get("videoCard") or {}

        ua = nav.get("userAgent", "")
        cpu = nav.get("hardwareConcurrency") or 8
        ram = nav.get("deviceMemory")
        if not isinstance(ram, int) or ram <= 0:
            ram = 8
        platform_str = nav.get("platform", "Win32" if os_type == "windows" else "MacIntel")
        language = nav.get("language", "en-US")

        width = scr.get("width") or 1920
        height = scr.get("height") or 1080

        vendor = gpu.get("vendor") or "Google Inc. (NVIDIA)"
        renderer = gpu.get("renderer") or "ANGLE (NVIDIA GeForce RTX 3060 Direct3D11)"
        fonts_list = fp.get("baseFonts") or fp.get("fonts") or []
    else:
        nav = getattr(fp, "navigator", None)
        scr = getattr(fp, "screen", None)
        vc = getattr(fp, "videoCard", None) or getattr(fp, "webgl", None) or getattr(fp, "gpu", None)

        ua = getattr(nav, "userAgent", "") if nav else ""
        cpu = getattr(nav, "hardwareConcurrency", 8) if nav else 8
        ram = getattr(nav, "deviceMemory", 8) if nav else 8
        platform_str = getattr(nav, "platform", "") if nav else ""
        language = getattr(nav, "language", "en-US") if nav else "en-US"

        width = getattr(scr, "width", 1920) if scr else 1920
        height = getattr(scr, "height", 1080) if scr else 1080

        vendor = getattr(vc, "vendor", "Google Inc. (NVIDIA)") if vc else "Google Inc. (NVIDIA)"
        renderer = getattr(vc, "renderer", "ANGLE (NVIDIA GeForce RTX 3060)") if vc else "ANGLE (NVIDIA GeForce RTX 3060)"
        fonts_list = getattr(fp, "fonts", []) or []

    return {
        "os": os_type,
        "userAgent": ua,
        "cpu": cpu or 8,
        "ram": ram or 8,
        "platform": platform_str,
        "language": language or "en-US",
        "screen": f"{width}x{height}",
        "width": width,
        "height": height,
        "webglVendor": vendor,
        "webglRenderer": renderer,
        "fontsCount": len(fonts_list) if fonts_list else 42,
    }


def load_or_create_fingerprint(profile_dir: Path, os_type: str = "windows"):
    from camoufox.fingerprints import generate_fingerprint

    os_clean = "macos" if str(os_type).lower() in ("macos", "mac", "darwin") else "windows"
    pkl_path = profile_dir / "fingerprint.pkl"
    json_path = profile_dir / "fingerprint.json"

    if pkl_path.exists():
        try:
            with open(pkl_path, "rb") as f:
                fp = pickle.load(f)
            if isinstance(fp, dict) and "navigator" in fp:
                # Đảm bảo ngôn ngữ mặc định luôn là tiếng Anh
                if isinstance(fp.get("navigator"), dict):
                    fp["navigator"]["languages"] = ["en-US", "en"]
                    fp["navigator"]["language"] = "en-US"
                return fp
            print("[Runner] Chuyển đổi fingerprint cũ sang định dạng dict chuẩn của Camoufox...")
        except Exception as e:
            print(f"[Runner] Cảnh báo: Không thể đọc fingerprint.pkl ({e}), tạo mới...")

    fp = generate_fingerprint(os=os_clean)
    if isinstance(fp, dict) and "navigator" in fp and isinstance(fp["navigator"], dict):
        fp["navigator"]["languages"] = ["en-US", "en"]
        fp["navigator"]["language"] = "en-US"

    profile_dir.mkdir(parents=True, exist_ok=True)
    with open(pkl_path, "wb") as f:
        pickle.dump(fp, f)

    try:
        summary = extract_fingerprint_summary(fp, os_clean)
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

    return fp


def generate_dmt_startpage(
    profile: dict,
    fp_summary: dict,
    profile_dir: Path,
    public_ip: str = "",
    proxy_country: str = "",
    proxy_tz: str = "",
) -> Path:
    """
    Tạo trang khởi động / New Tab mang thương hiệu DMT Browser với đầy đủ thông tin
    Hồ sơ, Proxy/IP, Thông số Fingerprint C++ Native, Thanh tìm kiếm Google và Lối tắt nhanh.
    """
    profile_id = html.escape(str(profile.get("id") or ""))
    profile_name = html.escape(str(profile.get("name") or f"Profile {profile_id}"))
    folder_name = html.escape(str(profile.get("folder") or "Mặc định"))
    notes_text = html.escape(str(profile.get("notes") or "Chưa có ghi chú cho hồ sơ này."))
    raw_proxy = str(profile.get("proxy") or "").strip()

    if raw_proxy and raw_proxy.lower() not in ("none", "local", "direct", "no"):
        parsed_p = parse_proxy(raw_proxy)
        proxy_server = html.escape(parsed_p["server"] if parsed_p else raw_proxy)
        is_proxied = True
    else:
        proxy_server = "Mạng Trực Tiếp (Local Network)"
        is_proxied = False

    ip_display = html.escape(public_ip or ("Đang đồng bộ qua Proxy" if is_proxied else "IP Mạng Gốc (Local)"))
    country_display = html.escape(proxy_country or ("Tự động theo Proxy" if is_proxied else "Local Region"))
    tz_display = html.escape(proxy_tz or ("Đồng bộ GeoIP" if is_proxied else "System Timezone"))

    os_type = str(fp_summary.get("os") or profile.get("os") or "windows").lower()
    os_label = "macOS (Apple Silicon / Intel)" if "mac" in os_type else "Windows 10 / 11 (64-bit)"
    cpu_cores = html.escape(str(fp_summary.get("cpu") or 8))
    ram_gb = html.escape(str(fp_summary.get("ram") or 8))
    screen_res = html.escape(str(fp_summary.get("screen") or "1920x1080"))
    lang_str = html.escape(str(fp_summary.get("language") or "en-US"))
    gpu_renderer = html.escape(str(fp_summary.get("webglRenderer") or "ANGLE (NVIDIA GeForce RTX 3060 Direct3D11)"))
    ua_str = html.escape(str(fp_summary.get("userAgent") or "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:156.0) Gecko/20100101 Firefox/156.0"))

    webrtc_mode = str(profile.get("webrtc_mode") or "proxy_only").lower()
    if webrtc_mode == "disabled":
        webrtc_label = "Vô hiệu hóa WebRTC (Disable)"
    elif webrtc_mode == "default":
        webrtc_label = "Mặc định trình duyệt (Standard)"
    else:
        webrtc_label = "Khóa chống rò rỉ IP (Proxy-Only)"

    net_badge_bg = "#ecfdf5" if is_proxied else "#eff6ff"
    net_badge_border = "#a7f3d0" if is_proxied else "#bfdbfe"
    net_badge_color = "#059669" if is_proxied else "#2563eb"
    net_badge_text = "PROXY PROTECTED • GEOIP SYNCED" if is_proxied else "DIRECT CONNECTION • LOCAL NETWORK"
    logo_path = BASE_DIR / "assets" / "profile_logo.png"
    if not logo_path.exists():
        logo_path = BASE_DIR / "assets" / "logo.png"
    logo_uri = logo_path.resolve().as_uri() if logo_path.exists() else ""

    html_content = f"""<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>DMT Browser — {profile_name}</title>
  <link rel="icon" type="image/png" href="{logo_uri}" />
  <style>
    :root {{
      --bg-light: #f8fafc;
      --card-bg: #ffffff;
      --card-border: #e2e8f0;
      --accent: #2563eb;
      --emerald: #059669;
      --text-main: #0f172a;
      --text-muted: #64748b;
    }}
    * {{
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }}
    body {{
      min-height: 100vh;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Inter, sans-serif;
      background-color: var(--bg-light);
      background-image:
        radial-gradient(circle at 15% 10%, rgba(37, 99, 235, 0.06) 0%, transparent 45%),
        radial-gradient(circle at 85% 15%, rgba(16, 185, 129, 0.06) 0%, transparent 40%);
      color: var(--text-main);
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 28px 24px 40px;
      overflow-x: hidden;
    }}
    .container {{
      width: 100%;
      max-width: 1120px;
      display: flex;
      flex-direction: column;
      gap: 22px;
    }}
    /* Top Bar */
    .topbar {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 14px;
      padding: 14px 20px;
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 16px;
      box-shadow: 0 4px 20px -4px rgba(15, 23, 42, 0.05);
    }}
    .brand {{
      display: flex;
      align-items: center;
      gap: 14px;
    }}
    .brand-logo {{
      width: 44px;
      height: 44px;
      border-radius: 50%;
      object-fit: cover;
      display: block;
      box-shadow: 0 4px 12px rgba(37, 99, 235, 0.25);
    }}
    .brand-title {{
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.4px;
      background: linear-gradient(90deg, #1d4ed8, #0284c7);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }}
    .brand-sub {{
      font-size: 11px;
      color: var(--text-muted);
      font-weight: 600;
      letter-spacing: 0.8px;
      text-transform: uppercase;
      margin-top: 2px;
    }}
    .topbar-right {{
      display: flex;
      align-items: center;
      gap: 12px;
      flex-wrap: wrap;
    }}
    .status-pill {{
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 7px 14px;
      border-radius: 999px;
      font-size: 11.5px;
      font-weight: 700;
      letter-spacing: 0.4px;
      background: {net_badge_bg};
      border: 1px solid {net_badge_border};
      color: {net_badge_color};
    }}
    .pulse-dot {{
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: currentColor;
    }}
    .clock-box {{
      padding: 7px 14px;
      border-radius: 10px;
      background: #f1f5f9;
      border: 1px solid #e2e8f0;
      font-size: 12.5px;
      font-weight: 600;
      color: #334155;
      font-variant-numeric: tabular-nums;
    }}
    /* Hero Search Section */
    .hero {{
      text-align: center;
      padding: 14px 10px 6px;
    }}
    .profile-Tagline {{
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 5px 14px;
      border-radius: 999px;
      background: #eff6ff;
      border: 1px solid #bfdbfe;
      color: #1d4ed8;
      font-size: 12px;
      font-weight: 600;
      margin-bottom: 12px;
    }}
    .hero h1 {{
      font-size: 30px;
      font-weight: 800;
      letter-spacing: -0.3px;
      margin-bottom: 6px;
      color: #0f172a;
    }}
    .hero p {{
      font-size: 13.5px;
      color: var(--text-muted);
      margin-bottom: 20px;
    }}
    .search-wrap {{
      max-width: 720px;
      margin: 0 auto;
      position: relative;
    }}
    .search-form {{
      display: flex;
      align-items: center;
      background: #ffffff;
      border: 1.5px solid #cbd5e1;
      border-radius: 16px;
      padding: 6px 8px 6px 18px;
      box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.06);
      transition: all 0.2s ease;
    }}
    .search-form:focus-within {{
      border-color: #2563eb;
      box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.12), 0 10px 25px -5px rgba(15, 23, 42, 0.08);
    }}
    .search-icon {{
      width: 20px;
      height: 20px;
      color: #64748b;
      margin-right: 12px;
      flex-shrink: 0;
    }}
    .search-input {{
      flex: 1;
      background: transparent;
      border: none;
      outline: none;
      color: #0f172a;
      font-size: 15px;
      padding: 10px 0;
    }}
    .search-input::placeholder {{
      color: #94a3b8;
    }}
    .search-btn {{
      background: linear-gradient(135deg, #2563eb, #1d4ed8);
      color: #fff;
      border: none;
      border-radius: 11px;
      padding: 10px 20px;
      font-size: 13.5px;
      font-weight: 700;
      cursor: pointer;
      transition: transform 0.15s, background 0.2s;
    }}
    .search-btn:hover {{
      background: linear-gradient(135deg, #3b82f6, #2563eb);
      transform: translateY(-1px);
    }}
    /* Quick Links */
    .quick-section-title {{
      font-size: 12px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.8px;
      color: #64748b;
      margin-bottom: 10px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }}
    .quick-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(125px, 1fr));
      gap: 10px;
    }}
    .quick-card {{
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 11px 13px;
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 12px;
      color: #1e293b;
      text-decoration: none;
      font-size: 13px;
      font-weight: 600;
      box-shadow: 0 2px 6px rgba(15, 23, 42, 0.03);
      transition: all 0.18s ease;
    }}
    .quick-card:hover {{
      border-color: #93c5fd;
      background: #f8fafc;
      transform: translateY(-2px);
      box-shadow: 0 8px 18px -6px rgba(37, 99, 235, 0.15);
    }}
    .quick-dot {{
      width: 28px;
      height: 28px;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 800;
      font-size: 13px;
      flex-shrink: 0;
    }}
    /* Info Cards Grid */
    .info-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
      gap: 16px;
    }}
    .info-card {{
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 16px;
      padding: 18px 20px;
      box-shadow: 0 4px 16px -4px rgba(15, 23, 42, 0.04);
      display: flex;
      flex-direction: column;
      gap: 12px;
    }}
    .card-header {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 1px solid #f1f5f9;
      padding-bottom: 10px;
    }}
    .card-title {{
      font-size: 13px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.6px;
      color: #1d4ed8;
    }}
    .card-badge {{
      font-size: 11px;
      font-weight: 700;
      padding: 3px 9px;
      border-radius: 6px;
      background: #ecfdf5;
      color: #059669;
      border: 1px solid #a7f3d0;
    }}
    .kv-list {{
      display: flex;
      flex-direction: column;
      gap: 9px;
      font-size: 13px;
    }}
    .kv-row {{
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 12px;
    }}
    .kv-label {{
      color: var(--text-muted);
      font-weight: 500;
      flex-shrink: 0;
    }}
    .kv-val {{
      color: #0f172a;
      font-weight: 600;
      text-align: right;
      word-break: break-all;
      font-family: ui-monospace, SFMono-Regular, Consolas, monospace;
      font-size: 12.5px;
    }}
    .notes-box {{
      background: #f8fafc;
      border: 1px dashed #cbd5e1;
      border-radius: 10px;
      padding: 10px 12px;
      font-size: 12.5px;
      color: #334155;
      line-height: 1.5;
      white-space: pre-wrap;
    }}
    .ua-footer {{
      padding: 12px 16px;
      background: #ffffff;
      border: 1px solid #e2e8f0;
      border-radius: 12px;
      font-size: 11.5px;
      color: #64748b;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 8px;
      font-family: ui-monospace, SFMono-Regular, Consolas, monospace;
    }}
  </style>
</head>
<body>
  <div class="container">
    <!-- Top Header -->
    <div class="topbar">
      <div class="brand">
        <img src="{logo_uri}" alt="DMT Browser" class="brand-logo" />
        <div>
          <div class="brand-title">DMT BROWSER</div>
          <div class="brand-sub">Camoufox C++ Native Antidetect Core</div>
        </div>
      </div>
      <div class="topbar-right">
        <div class="status-pill">
          <span class="pulse-dot"></span>
          <span>{net_badge_text}</span>
        </div>
        <div class="clock-box" id="liveClock">--:--:--</div>
      </div>
    </div>

    <!-- Hero & Search -->
    <div class="hero">
      <div class="profile-Tagline">
        <span>Hồ sơ: <strong>{profile_name}</strong></span>
        <span>•</span>
        <span>Nhóm: {folder_name}</span>
        <span>•</span>
        <span>ID: #{profile_id}</span>
      </div>
      <h1>Chào mừng đến với DMT Browser</h1>
      <p>Môi trường trình duyệt độc lập đã khóa cứng Fingerprint phần cứng C++ & chống rò rỉ WebRTC</p>

      <div class="search-wrap">
        <form class="search-form" id="searchForm">
          <svg class="search-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <circle cx="11" cy="11" r="8"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
          </svg>
          <input
            type="text"
            id="searchInput"
            class="search-input"
            placeholder="Tìm kiếm trên Google hoặc nhập địa chỉ website (VD: facebook.com)..."
            autofocus
            autocomplete="off"
          />
          <button type="submit" class="search-btn">Truy cập</button>
        </form>
      </div>
    </div>

    <!-- Quick Access Links -->
    <div>
      <div class="quick-section-title">
        <span>Lối tắt truy cập nhanh & Kiểm tra độ ẩn danh</span>
        <span>Nhấn dấu <strong>+</strong> trên thanh Tab hoặc <strong>Ctrl + T</strong> để mở thêm Tab mới</span>
      </div>
      <div class="quick-grid">
        <a class="quick-card" href="https://www.google.com">
          <span class="quick-dot" style="background:#eff6ff;color:#2563eb;">G</span>
          <span>Google</span>
        </a>
        <a class="quick-card" href="https://www.facebook.com">
          <span class="quick-dot" style="background:#dbeafe;color:#1d4ed8;">f</span>
          <span>Facebook</span>
        </a>
        <a class="quick-card" href="https://www.tiktok.com">
          <span class="quick-dot" style="background:#fdf2f8;color:#db2777;">T</span>
          <span>TikTok</span>
        </a>
        <a class="quick-card" href="https://www.youtube.com">
          <span class="quick-dot" style="background:#fef2f2;color:#dc2626;">▶</span>
          <span>YouTube</span>
        </a>
        <a class="quick-card" href="https://mail.google.com">
          <span class="quick-dot" style="background:#fffbeb;color:#d97706;">M</span>
          <span>Gmail</span>
        </a>
        <a class="quick-card" href="https://iphey.com">
          <span class="quick-dot" style="background:#ecfdf5;color:#059669;">✓</span>
          <span>IPHey Check</span>
        </a>
        <a class="quick-card" href="https://pixelscan.net">
          <span class="quick-dot" style="background:#f5f3ff;color:#7c3aed;">P</span>
          <span>Pixelscan</span>
        </a>
        <a class="quick-card" href="https://whoer.net">
          <span class="quick-dot" style="background:#ecfeff;color:#0891b2;">W</span>
          <span>Whoer IP</span>
        </a>
      </div>
    </div>

    <!-- 3 Detailed Status Cards -->
    <div class="info-grid">
      <!-- Network Card -->
      <div class="info-card">
        <div class="card-header">
          <span class="card-title">Kết Nối Mạng & Proxy</span>
          <span class="card-badge">WebRTC Safe</span>
        </div>
        <div class="kv-list">
          <div class="kv-row">
            <span class="kv-label">Máy chủ Proxy:</span>
            <span class="kv-val">{proxy_server}</span>
          </div>
          <div class="kv-row">
            <span class="kv-label">Địa chỉ IP Public:</span>
            <span class="kv-val" style="color:#059669;">{ip_display}</span>
          </div>
          <div class="kv-row">
            <span class="kv-label">Quốc gia / Khu vực:</span>
            <span class="kv-val">{country_display}</span>
          </div>
          <div class="kv-row">
            <span class="kv-label">Múi giờ (Timezone):</span>
            <span class="kv-val">{tz_display}</span>
          </div>
        </div>
      </div>

      <!-- Hardware Fingerprint Card -->
      <div class="info-card">
        <div class="card-header">
          <span class="card-title">Thông Số Phần Cứng Fake</span>
          <span class="card-badge">C++ Locked</span>
        </div>
        <div class="kv-list">
          <div class="kv-row">
            <span class="kv-label">Hệ điều hành:</span>
            <span class="kv-val">{os_label}</span>
          </div>
          <div class="kv-row">
            <span class="kv-label">CPU & Bộ nhớ RAM:</span>
            <span class="kv-val">{cpu_cores} Luồng • {ram_gb} GB</span>
          </div>
          <div class="kv-row">
            <span class="kv-label">Độ phân giải & Ngôn ngữ:</span>
            <span class="kv-val">{screen_res} • {lang_str}</span>
          </div>
          <div class="kv-row">
            <span class="kv-label">Card đồ họa (WebGL):</span>
            <span class="kv-val" title="{gpu_renderer}">{gpu_renderer[:42]}</span>
          </div>
          <div class="kv-row">
            <span class="kv-label">Bảo vệ WebRTC:</span>
            <span class="kv-val" style="color:#059669;">{webrtc_label}</span>
          </div>
        </div>
      </div>

      <!-- Profile Notes Card -->
      <div class="info-card">
        <div class="card-header">
          <span class="card-title">Thông Tin & Ghi Chú Hồ Sơ</span>
          <span class="card-badge">Persistent</span>
        </div>
        <div class="kv-list">
          <div class="kv-row">
            <span class="kv-label">Tên Profile:</span>
            <span class="kv-val" style="color:#2563eb;">{profile_name}</span>
          </div>
          <div class="kv-row">
            <span class="kv-label">Lưu trữ dữ liệu:</span>
            <span class="kv-val">Cookie, LocalStorage, Session</span>
          </div>
        </div>
        <div class="notes-box">{notes_text}</div>
      </div>
    </div>

    <!-- Footer UA -->
    <div class="ua-footer">
      <span><strong>User-Agent:</strong> {ua_str}</span>
      <span>DMT Browser Portable Engine v2.0</span>
    </div>
  </div>

  <script>
    function updateClock() {{
      const now = new Date();
      const pad = n => String(n).padStart(2, '0');
      const timeStr = pad(now.getHours()) + ':' + pad(now.getMinutes()) + ':' + pad(now.getSeconds());
      const dateStr = pad(now.getDate()) + '/' + pad(now.getMonth() + 1) + '/' + now.getFullYear();
      const el = document.getElementById('liveClock');
      if (el) el.textContent = timeStr + ' • ' + dateStr;
    }}
    updateClock();
    setInterval(updateClock, 1000);

    document.getElementById('searchForm').addEventListener('submit', function(e) {{
      e.preventDefault();
      const raw = (document.getElementById('searchInput').value || '').trim();
      if (!raw) return;
      if (/^(https?:\\/\\/|file:\\/\\/|about:)/i.test(raw)) {{
        window.location.href = raw;
      }} else if (/^[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)+(\\/.*)?$/.test(raw) && !raw.includes(' ')) {{
        window.location.href = 'https://' + raw;
      }} else {{
        window.location.href = 'https://www.google.com/search?q=' + encodeURIComponent(raw);
      }}
    }});
  </script>
</body>
</html>
"""
    startpage_path = profile_dir / "startpage.html"
    startpage_path.write_text(html_content, encoding="utf-8")
    return startpage_path


def is_camoufox_child_alive() -> bool:
    try:
        me = psutil.Process(os.getpid())
        for child in me.children(recursive=True):
            if "camoufox" in child.name().lower() and child.status() != psutil.STATUS_ZOMBIE:
                return True
        return False
    except Exception:
        return False


def wait_until_browser_closed(context):
    """
    Theo dõi trực tiếp tiến trình camoufox.exe ở tầng hệ điều hành mà không khóa
    hay can thiệp vào luồng mở Tab mới của người dùng.
    Khi người dùng bấm X đóng trình duyệt, thoát ngay lập tức để không bao giờ tự mở lại lần 2.
    """
    closed_state = {"closed": False}

    def _on_close(*_args):
        closed_state["closed"] = True

    try:
        context.on("close", _on_close)
    except Exception:
        pass

    # Chờ tối đa vài giây đầu để tiến trình camoufox.exe ổn định
    time.sleep(0.5)

    while not closed_state["closed"]:
        if not is_camoufox_child_alive():
            break
        time.sleep(0.4)


if os.name == "nt":
    import ctypes
    from ctypes import wintypes
    import uuid

    class GUID(ctypes.Structure):
        _fields_ = [
            ("Data1", wintypes.DWORD),
            ("Data2", wintypes.WORD),
            ("Data3", wintypes.WORD),
            ("Data4", ctypes.c_byte * 8),
        ]

        @classmethod
        def from_str(cls, s: str):
            u = uuid.UUID(s)
            inst = cls()
            inst.Data1 = int.from_bytes(u.bytes_le[0:4], "little")
            inst.Data2 = int.from_bytes(u.bytes_le[4:6], "little")
            inst.Data3 = int.from_bytes(u.bytes_le[6:8], "little")
            inst.Data4 = (ctypes.c_byte * 8)(*u.bytes_le[8:16])
            return inst

    class PROPERTYKEY(ctypes.Structure):
        _fields_ = [("fmtid", GUID), ("pid", wintypes.DWORD)]

    VT_LPWSTR = 31

    class PROPVARIANT(ctypes.Structure):
        _fields_ = [
            ("vt", ctypes.c_ushort),
            ("wReserved1", wintypes.WORD),
            ("wReserved2", wintypes.WORD),
            ("wReserved3", wintypes.WORD),
            ("pwszVal", wintypes.LPWSTR),
            ("padding", ctypes.c_byte * 8),
        ]

    IID_IPropertyStore = GUID.from_str("886d8eeb-8cf2-4446-8d02-cdba1dbdcf99")
    FMTID_AppUserModel = GUID.from_str("9f4c2855-9f79-4b39-a8d0-e1d42de1d5f3")
    PKEY_AppUserModel_ID = PROPERTYKEY(FMTID_AppUserModel, 5)
    PKEY_AppUserModel_RelaunchIconResource = PROPERTYKEY(FMTID_AppUserModel, 2)
    PKEY_AppUserModel_RelaunchDisplayNameResource = PROPERTYKEY(FMTID_AppUserModel, 4)

    SetValueType = ctypes.WINFUNCTYPE(ctypes.HRESULT, ctypes.c_void_p, ctypes.POINTER(PROPERTYKEY), ctypes.POINTER(PROPVARIANT))
    CommitType = ctypes.WINFUNCTYPE(ctypes.HRESULT, ctypes.c_void_p)
    ReleaseType = ctypes.WINFUNCTYPE(wintypes.ULONG, ctypes.c_void_p)

    def set_window_property_string(hwnd: int, prop_key: PROPERTYKEY, val_str: str) -> bool:
        if not hwnd or not val_str:
            return False
        try:
            store_ptr = ctypes.c_void_p()
            hr = ctypes.windll.shell32.SHGetPropertyStoreForWindow(
                hwnd, ctypes.byref(IID_IPropertyStore), ctypes.byref(store_ptr)
            )
            if hr != 0 or not store_ptr:
                return False
            vtable = ctypes.cast(store_ptr, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
            set_value = SetValueType(vtable[6])
            commit = CommitType(vtable[7])
            release = ReleaseType(vtable[2])

            prop = PROPVARIANT()
            prop.vt = VT_LPWSTR
            prop.pwszVal = str(val_str)
            hr_set = set_value(store_ptr, ctypes.byref(prop_key), ctypes.byref(prop))
            hr_commit = commit(store_ptr)
            release(store_ptr)
            return hr_set == 0 and hr_commit == 0
        except Exception:
            return False


def _setup_profile_window(profile_id: str = "", profile_name: str = ""):
    """
    1. Định vị cửa sổ kích thước 1100x900 như ban đầu.
    2. Gán AppUserModelID riêng biệt cho từng HWND (Tách biệt hoàn toàn từng Profile trên thanh Taskbar).
    3. Gán Icon Profile và tiêu đề riêng biệt cho Profile.
    """
    if os.name != "nt":
        return
    try:
        user32 = ctypes.windll.user32

        try:
            ctypes.windll.ole32.CoInitialize(None)
        except Exception:
            pass

        # Đặt AppUserModelID cho tiến trình runner
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(f"DMT.Browser.Profile.{profile_id or 'Default'}")
        except Exception:
            pass

        ico_file = (BASE_DIR / "assets" / "profile_logo.ico").resolve()
        hicon_big = 0
        hicon_small = 0
        if ico_file.exists():
            IMAGE_ICON = 1
            LR_LOADFROMFILE = 0x0010
            LR_DEFAULTSIZE = 0x0040
            hicon_big = user32.LoadImageW(0, str(ico_file), IMAGE_ICON, 0, 0, LR_LOADFROMFILE | LR_DEFAULTSIZE)
            hicon_small = user32.LoadImageW(0, str(ico_file), IMAGE_ICON, 16, 16, LR_LOADFROMFILE)

        app_id = f"DMT.Browser.Profile.{profile_id or 'Default'}"
        disp_name = f"DMT — {profile_name or profile_id or 'Profile'}"

        me = psutil.Process(os.getpid())
        target_hwnd = None

        for _ in range(80):
            try:
                child_pids = {c.pid for c in me.children(recursive=True)}
            except Exception:
                child_pids = set()

            if child_pids:
                found_hwnds = []

                @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
                def enum_cb(hwnd, lparam):
                    pid = wintypes.DWORD()
                    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                    if pid.value in child_pids:
                        cls_buf = ctypes.create_unicode_buffer(256)
                        user32.GetClassNameW(hwnd, cls_buf, 256)
                        if "MozillaWindowClass" in cls_buf.value and user32.IsWindowVisible(hwnd):
                            rect = wintypes.RECT()
                            user32.GetWindowRect(hwnd, ctypes.byref(rect))
                            if (rect.right - rect.left) > 100:
                                found_hwnds.append(hwnd)
                    return True

                user32.EnumWindows(enum_cb, 0)
                if found_hwnds:
                    target_hwnd = found_hwnds[0]
                    break

            time.sleep(0.2)

        if not target_hwnd:
            return

        SW_RESTORE = 9
        user32.ShowWindow(target_hwnd, SW_RESTORE)
        user32.MoveWindow(target_hwnd, 60, 40, 1100, 900, True)

        # Gán AppUserModelID độc lập trên HWND (TÁCH BIỆT TASKBAR 100%)
        set_window_property_string(target_hwnd, PKEY_AppUserModel_ID, app_id)
        set_window_property_string(target_hwnd, PKEY_AppUserModel_RelaunchDisplayNameResource, disp_name)
        if ico_file.exists():
            set_window_property_string(target_hwnd, PKEY_AppUserModel_RelaunchIconResource, str(ico_file))

        # Gán icon Profile vào Titlebar & Taskbar button
        if hicon_big:
            user32.SendMessageW(target_hwnd, 0x0080, 1, hicon_big)
            try:
                user32.SetClassLongPtrW(target_hwnd, -14, hicon_big)
            except Exception:
                pass
        if hicon_small:
            user32.SendMessageW(target_hwnd, 0x0080, 0, hicon_small)
            try:
                user32.SetClassLongPtrW(target_hwnd, -34, hicon_small)
            except Exception:
                pass

        user32.SetWindowTextW(target_hwnd, f"DMT Browser — {disp_name}")

    except Exception:
        pass


def run_profile(
    profile_id: str,
    start_url: str = None,
    public_ip: str = "",
    proxy_country: str = "",
    proxy_tz: str = "",
):
    profile = get_profile_from_db(profile_id)
    if not profile:
        print(f"[Runner] Không tìm thấy Profile ID: {profile_id}", file=sys.stderr)
        sys.exit(1)

    profile_dir = PROFILES_DIR / str(profile_id)
    user_data_dir = profile_dir / "user_data"
    user_data_dir.mkdir(parents=True, exist_ok=True)

    # Đảm bảo nút '+' mở tab mới luôn hiển thị ngay cạnh tab và thanh địa chỉ tìm kiếm Google mượt mà
    ensure_newtab_button_visible(user_data_dir)

    os_type = "macos" if str(profile.get("os", "windows")).lower() in ("macos", "mac") else "windows"
    proxy_str = profile.get("proxy", "") or ""
    proxy_config = parse_proxy(proxy_str)

    # Khóa cứng Fingerprint đã lưu của Profile
    fp = load_or_create_fingerprint(profile_dir, os_type)
    fp_summary = extract_fingerprint_summary(fp, os_type)

    # Sinh trang khởi động DMT Browser cho Profile (dùng cho cả Tab 1 và mọi Tab mới khi bấm '+')
    startpage_path = generate_dmt_startpage(
        profile=profile,
        fp_summary=fp_summary,
        profile_dir=profile_dir,
        public_ip=public_ip,
        proxy_country=proxy_country,
        proxy_tz=proxy_tz,
    )
    startpage_uri = startpage_path.resolve().as_uri()

    from camoufox.sync_api import Camoufox

    webrtc_mode = str(profile.get("webrtc_mode") or "proxy_only").lower()

    custom_prefs = {
        "browser.uiCustomization.state": UI_CUSTOMIZATION_STATE,
        "toolkit.legacyUserProfileCustomizations.stylesheets": True,
        "browser.tabs.closeWindowWithLastTab": True,
        "browser.link.open_newwindow": 3,
        "browser.link.open_newwindow.restriction": 0,
        "extensions.activeThemeID": "firefox-compact-light@mozilla.org",
        "ui.systemUsesDarkTheme": 0,
        "browser.theme.content-theme": 1,
        "browser.theme.toolbar-theme": 1,
        "layout.css.prefers-color-scheme.content-override": 1,
        "browser.in-content.dark-mode": False,
        # 1. Ngôn ngữ mặc định tiếng Anh, Locale theo GeoIP / Proxy
        "intl.accept_languages": "en-US, en;q=0.9",
        "javascript.use_us_english_locale": True,
        "intl.locale.matchOS": False,
    }

    # 2. Khóa chống rò rỉ IP qua WebRTC
    if webrtc_mode == "disabled":
        custom_prefs["media.peerconnection.enabled"] = False
        custom_prefs["media.peerconnection.ice.proxy_only"] = True
        custom_prefs["media.peerconnection.ice.default_address_only"] = True
        custom_prefs["media.peerconnection.ice.no_host"] = True
        camoufox_block_webrtc = True
    elif webrtc_mode == "default":
        camoufox_block_webrtc = False
    else:
        # proxy_only: Ép WebRTC qua Proxy, giấu triệt để IP LAN và IP gốc
        custom_prefs["media.peerconnection.ice.proxy_only"] = True
        custom_prefs["media.peerconnection.ice.default_address_only"] = True
        custom_prefs["media.peerconnection.ice.no_host"] = True
        camoufox_block_webrtc = False

    camoufox_kwargs = {
        "persistent_context": True,
        "user_data_dir": str(user_data_dir),
        "fingerprint": fp,
        "os": os_type,
        "headless": False,
        "humanize": True,
        "allow_addon_new_tab": True,
        "block_webrtc": camoufox_block_webrtc,
        "firefox_user_prefs": custom_prefs,
        "env": {
            "DMT_STARTPAGE_URI": startpage_uri,
        },
        "i_know_what_im_doing": True,
    }

    if proxy_config:
        camoufox_kwargs["proxy"] = proxy_config
        # Nếu đã có public_ip từ bước kiểm tra proxy trước khi mở, truyền thẳng IP vào geoip
        # để vừa khởi động nhanh vừa khớp Timezone & Locale chuẩn theo Proxy
        camoufox_kwargs["geoip"] = public_ip if public_ip else True
    else:
        camoufox_kwargs["geoip"] = False

    print(f"[Runner] Đang khởi động DMT Browser cho Profile '{profile.get('name')}' ({profile_id})...")
    print(f"[Runner] OS: {os_type} | Proxy: {proxy_config['server'] if proxy_config else 'Local Network'}")

    try:
        with Camoufox(**camoufox_kwargs) as context:
            threading.Thread(
                target=_setup_profile_window,
                args=(profile_id, profile.get("name") or ""),
                daemon=True,
            ).start()
            pages = context.pages
            page = pages[0] if pages else context.new_page()

            target_url = (start_url or profile.get("start_url") or "").strip()
            initial_uri = target_url if target_url else startpage_uri

            try:
                page.goto(initial_uri, wait_until="domcontentloaded", timeout=45000)
            except Exception as e:
                print(f"[Runner] Lưu ý khi mở trang khởi động: {e}")

            wait_until_browser_closed(context)
            print(f"[Runner] Profile '{profile.get('name')}' ({profile_id}) đã đóng hoàn toàn.")
            os._exit(0)

    except Exception as e:
        print(f"[Runner] Kết thúc tiến trình trình duyệt ({e}).")
        os._exit(0)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="DMT Browser - Camoufox Profile Runner")
    parser.add_argument("--profile-id", required=True, help="ID của Profile cần mở")
    parser.add_argument("--url", default=None, help="URL mở kèm nếu có")
    parser.add_argument("--public-ip", default="", help="IP Public đã kiểm tra của Proxy")
    parser.add_argument("--proxy-country", default="", help="Quốc gia của Proxy")
    parser.add_argument("--proxy-tz", default="", help="Múi giờ của Proxy")
    args = parser.parse_args()
    run_profile(
        profile_id=args.profile_id,
        start_url=args.url,
        public_ip=args.public_ip,
        proxy_country=args.proxy_country,
        proxy_tz=args.proxy_tz,
    )
