/**
 * AI Image & Video Studio Plugin cho DMT Browser
 * Toàn bộ chức năng nằm gọn trong thư mục `image_studio/`.
 * Nếu xóa thư mục `image_studio/`, DMT Browser sẽ tự động chạy bình thường như cũ mà không báo lỗi.
 */
(function () {
  let studioConfig = null;
  let studioPresets = {};
  let studioHistory = [];
  let studioSubTab = 'create'; // 'create' | 'video' | 'settings'
  let isGeneratingImage = false;
  let isGeneratingVideo = false;
  let currentPreviewItem = null;
  let lastRawApiResponse = null;
  let referenceImages = []; // [{name, data_url}]
  let advSettingsOpen = false;
  let currentMainView = 'profiles';

  function esc(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function notify(msg, type = 'info') {
    if (typeof window.showToast === 'function') {
      window.showToast(msg, type);
    } else {
      console.log(`[ImageStudio][${type}]`, msg);
    }
  }

  function getActiveProfile() {
    if (!studioConfig || !Array.isArray(studioConfig.profiles) || studioConfig.profiles.length === 0) {
      return {
        id: 'default_modelapi',
        name: 'modelapi.vn',
        base_url: 'https://modelapi.vn/v1',
        api_key: '',
        image_path: '/images/generations',
        edit_path: '/images/edits',
        video_path: '/videos/generations',
        models_path: '/models',
        auth_type: 'Bearer',
        custom_headers: '',
        timeout: 120,
        image_model: 'gpt-image-2',
        video_model: 'sora-2',
        available_models: ['gpt-image-2', 'gpt-image-2.5'],
      };
    }
    const activeId = studioConfig.active_profile_id;
    return (
      studioConfig.profiles.find((p) => p.id === activeId) || studioConfig.profiles[0]
    );
  }

  // ==================== 1. GẮN MENU SIDEBAR & KHUNG GIAO DIỆN ====================
  function injectStudioIntoDOM() {
    const navProfilesBtn = document.getElementById('navProfiles');
    if (!navProfilesBtn || document.getElementById('navImageStudio')) return;

    const navContainer = document.getElementById('sidebarPluginNav') || navProfilesBtn.parentElement;
    const btn = document.createElement('button');
    btn.id = 'navImageStudio';
    btn.type = 'button';
    btn.onclick = () => window.switchMainView('image_studio');
    btn.className =
      'w-full px-3 py-2.5 rounded-lg text-xs font-medium flex items-center justify-between text-slate-300 hover:bg-[#1e2d47]/70 hover:text-white transition whitespace-nowrap';
    btn.innerHTML = `
      <span class="flex items-center gap-2.5 min-w-0">
        <i class="fa-solid fa-wand-magic-sparkles w-4 text-center text-violet-400 shrink-0"></i>
        <span class="truncate">Tạo ảnh AI</span>
      </span>
      <span class="text-[10px] px-1.5 py-0.5 rounded bg-violet-500/20 text-violet-300 font-semibold shrink-0">Studio</span>
    `;
    navContainer.appendChild(btn);

    // Tạo container chính bên trong <main>
    const mainEl = document.querySelector('main');
    if (!mainEl) return;

    const studioWrapper = document.createElement('div');
    studioWrapper.id = 'imageStudioWorkspace';
    studioWrapper.className = 'hidden flex-1 flex flex-col min-h-0 overflow-hidden bg-[#f4f6f9] dark:bg-[#0b0f19]';
    studioWrapper.innerHTML = buildStudioHTML();
    mainEl.appendChild(studioWrapper);

    // Tạo Modal xem JSON API
    const jsonModal = document.createElement('div');
    jsonModal.id = 'studioRawJsonModal';
    jsonModal.className = 'fixed inset-0 z-50 hidden items-center justify-center bg-black/60 backdrop-blur-xs p-4';
    jsonModal.innerHTML = `
      <div class="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-700 rounded-xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        <div class="px-5 py-3.5 bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div class="flex items-center gap-2.5">
            <i class="fa-solid fa-code text-violet-500"></i>
            <h3 class="text-sm font-bold text-slate-800 dark:text-white">Response JSON từ API</h3>
          </div>
          <button type="button" id="closeStudioJsonModalBtn" class="w-7 h-7 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-500 flex items-center justify-center">
            <i class="fa-solid fa-xmark"></i>
          </button>
        </div>
        <div class="p-4 flex-1 overflow-auto bg-slate-950 text-slate-100 mono text-xs">
          <pre id="studioRawJsonContent" class="whitespace-pre-wrap break-words select-text"></pre>
        </div>
      </div>
    `;
    document.body.appendChild(jsonModal);

    // Hook selectFolder và selectRunningProfiles để tự chuyển về Profiles nếu đang ở màn hình khác
    const origSelectFolder = window.selectFolder;
    window.selectFolder = function (f) {
      if (window.activeMainWorkspace !== 'profiles' && typeof window.switchMainView === 'function') {
        window.switchMainView('profiles');
      }
      if (typeof origSelectFolder === 'function') {
        origSelectFolder(f);
      }
    };

    const origSelectRunning = window.selectRunningProfiles;
    window.selectRunningProfiles = function () {
      if (window.activeMainWorkspace !== 'profiles' && typeof window.switchMainView === 'function') {
        window.switchMainView('profiles');
      }
      if (typeof origSelectRunning === 'function') {
        origSelectRunning();
      }
    };

    bindStudioEvents();
  }

  function setWorkspaceVisibility(viewName) {
    if (typeof window.switchMainView === 'function') {
      window.switchMainView(viewName);
    }
  }

  // ==================== 2. HTML GIAO DIỆN AI STUDIO ====================
  function buildStudioHTML() {
    return `
      <!-- Thanh Sub-Nav chuyển Tab (Tạo ảnh / Tạo video / Cài đặt API) -->
      <div class="px-6 py-2.5 bg-white dark:bg-[#111827] border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div class="flex items-center gap-2">
          <button type="button" data-studio-tab="create" class="studio-tab-btn px-3.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 bg-violet-600 text-white shadow-xs transition">
            <i class="fa-regular fa-image"></i>
            <span>Tạo ảnh AI</span>
          </button>
          <button type="button" data-studio-tab="video" class="studio-tab-btn px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition">
            <i class="fa-solid fa-film"></i>
            <span>Tạo video AI</span>
          </button>
          <button type="button" data-studio-tab="settings" class="studio-tab-btn px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition">
            <i class="fa-solid fa-sliders"></i>
            <span>Cài đặt API</span>
          </button>
        </div>

        <div class="flex items-center gap-2.5 text-xs">
          <div class="px-3 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center gap-2">
            <span class="text-slate-400 text-[11px]">API đang dùng:</span>
            <b id="studioActiveApiPill" class="text-violet-600 dark:text-violet-400 font-bold">modelapi.vn</b>
          </div>
          <button type="button" id="studioTopOpenFolderBtn" class="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-semibold flex items-center gap-1.5 transition">
            <i class="fa-regular fa-folder-open text-amber-500"></i>
            <span>Thư mục ảnh</span>
          </button>
        </div>
      </div>

      <!-- ==================== TAB 1: TẠO ẢNH AI ==================== -->
      <div id="studioTabCreate" class="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-4 p-4 min-h-0 overflow-hidden">
        <!-- Cột trái: Điều khiển (5 cols) -->
        <div class="lg:col-span-5 bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-col gap-3 overflow-y-auto">
          <div class="flex items-center justify-between">
            <div>
              <h2 class="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2">
                <i class="fa-solid fa-wand-magic-sparkles text-violet-500"></i>
                <span>Tạo ảnh AI (Multi-API)</span>
              </h2>
              <p id="studioCreateApiSub" class="text-[11px] text-violet-600 dark:text-violet-400 mono truncate max-w-[300px]">Nguồn API: modelapi.vn</p>
            </div>
            <button type="button" id="studioShortcutSettingsBtn" class="px-2.5 py-1 rounded-md bg-violet-50 dark:bg-violet-950/60 text-violet-600 dark:text-violet-300 border border-violet-200 dark:border-violet-800 text-[11px] font-semibold hover:bg-violet-100 transition">
              <i class="fa-solid fa-gear mr-1"></i>Cấu hình API khác
            </button>
          </div>

          <!-- Chọn nhanh Profile API & Model -->
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
            <div>
              <label class="block font-semibold text-slate-600 dark:text-slate-300 mb-1">Nguồn API (Profile)</label>
              <select id="studioCreateProfileSelect" class="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white focus:border-violet-500 focus:outline-none"></select>
            </div>
            <div>
              <label class="block font-semibold text-slate-600 dark:text-slate-300 mb-1">Mô hình (Chọn hoặc gõ tên)</label>
              <input id="studioCreateModelInput" list="studioModelDatalist" type="text" placeholder="gpt-image-2" class="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white mono focus:border-violet-500 focus:outline-none" />
              <datalist id="studioModelDatalist"></datalist>
            </div>
          </div>

          <!-- Kích thước, Chất lượng, Phong cách, Số lượng -->
          <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
            <div class="col-span-2 sm:col-span-1">
              <label class="block font-semibold text-slate-600 dark:text-slate-300 mb-1">Kích thước</label>
              <input id="studioSizeInput" list="studioSizeList" type="text" value="1024x1024" class="w-full px-2 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white mono text-[11px] focus:outline-none" />
              <datalist id="studioSizeList">
                <option value="1024x1024">Vuông 1:1</option>
                <option value="1792x1024">Ngang 16:9</option>
                <option value="1024x1792">Dọc 9:16</option>
                <option value="1536x1024">Ngang 3:2</option>
                <option value="1024x1536">Dọc 2:3</option>
                <option value="1280x720">HD 16:9</option>
                <option value="720x1280">HD 9:16</option>
                <option value="512x512">Nhỏ 1:1</option>
                <option value="Auto">Bỏ qua size</option>
              </datalist>
            </div>
            <div>
              <label class="block font-semibold text-slate-600 dark:text-slate-300 mb-1">Chất lượng</label>
              <select id="studioQualitySelect" class="w-full px-2 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white text-[11px] focus:outline-none">
                <option value="standard">standard</option>
                <option value="hd">hd</option>
                <option value="high">high</option>
                <option value="medium">medium</option>
                <option value="low">low</option>
                <option value="auto">auto (bỏ qua)</option>
              </select>
            </div>
            <div>
              <label class="block font-semibold text-slate-600 dark:text-slate-300 mb-1">Phong cách</label>
              <select id="studioStyleSelect" class="w-full px-2 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white text-[11px] focus:outline-none">
                <option value="vivid">vivid</option>
                <option value="natural">natural</option>
                <option value="auto">auto (bỏ qua)</option>
              </select>
            </div>
            <div>
              <label class="block font-semibold text-slate-600 dark:text-slate-300 mb-1">Số lượng (n)</label>
              <select id="studioCountSelect" class="w-full px-2 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white text-[11px] focus:outline-none">
                <option value="1">1 ảnh</option>
                <option value="2">2 ảnh</option>
                <option value="4">4 ảnh</option>
              </select>
            </div>
          </div>

          <!-- Prompt -->
          <div class="text-xs space-y-1.5">
            <div class="flex items-center justify-between">
              <label class="font-semibold text-slate-700 dark:text-slate-200">Mô tả ảnh (Prompt) <span class="text-rose-500">*</span></label>
              <div class="flex items-center gap-1">
                <button type="button" data-prompt-tpl="poster" class="studio-tpl-btn px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 hover:bg-violet-100 dark:hover:bg-slate-700 text-[10px] text-slate-600 dark:text-slate-300">Gợi ý: Poster</button>
                <button type="button" data-prompt-tpl="cyberpunk" class="studio-tpl-btn px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 hover:bg-violet-100 dark:hover:bg-slate-700 text-[10px] text-slate-600 dark:text-slate-300">Gợi ý: Cyberpunk</button>
              </div>
            </div>
            <textarea id="studioPromptInput" rows="4" placeholder="Nhập mô tả chi tiết bức ảnh muốn tạo..." class="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 focus:border-violet-500 text-xs text-slate-800 dark:text-white focus:outline-none resize-none">Một chú mèo con phong cách cyberpunk ngắm nhìn thành phố Sài Gòn ban đêm, ánh đèn neon lung linh rực rỡ, chi tiết sắc nét 8k</textarea>
          </div>

          <!-- Ảnh tham chiếu (Image Edit / Img2Img) -->
          <div class="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
            <div class="flex items-center gap-2">
              <label class="px-2.5 py-1 rounded bg-slate-200/80 dark:bg-slate-800 hover:bg-slate-300 text-slate-700 dark:text-slate-200 font-semibold cursor-pointer transition">
                <i class="fa-solid fa-paperclip mr-1"></i>Chọn ảnh tham chiếu
                <input id="studioRefFilesInput" type="file" accept="image/*" multiple class="hidden" />
              </label>
              <button type="button" id="studioClearRefBtn" class="hidden px-2 py-1 rounded text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/50 text-[11px] font-semibold">Xóa</button>
            </div>
            <span id="studioRefCountLabel" class="text-[11px] text-slate-400">Chưa chọn ảnh</span>
          </div>

          <!-- Negative Prompt & Custom JSON -->
          <div class="text-xs space-y-2">
            <div>
              <label class="block font-semibold text-slate-500 dark:text-slate-400 mb-1 text-[11px]">Negative Prompt (Nếu API hỗ trợ)</label>
              <input id="studioNegPromptInput" type="text" placeholder="blurry, low quality, distorted, watermark..." class="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white text-xs focus:outline-none" />
            </div>

            <label class="flex items-center gap-2 cursor-pointer select-none text-[11px] text-slate-600 dark:text-slate-300">
              <input id="studioCustomJsonToggle" type="checkbox" class="accent-violet-600 rounded" />
              <span>Dùng Custom JSON Body (Cho API cấu trúc riêng)</span>
            </label>

            <textarea id="studioCustomJsonTextarea" rows="4" class="hidden w-full p-2.5 rounded-lg bg-slate-950 text-emerald-300 border border-slate-700 mono text-[11px] focus:outline-none"></textarea>
          </div>

          <!-- Nút Tạo Ảnh & Trạng thái -->
          <div class="pt-1 space-y-2 mt-auto">
            <button type="button" id="studioGenerateBtn" class="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold text-sm shadow-md shadow-violet-500/20 flex items-center justify-center gap-2 transition">
              <i class="fa-solid fa-wand-magic-sparkles"></i>
              <span>✨ Tạo Ảnh Ngay</span>
            </button>
            <div class="flex items-center justify-between text-[11px]">
              <span id="studioCreateStatusText" class="text-slate-500 dark:text-slate-400 truncate">Sẵn sàng tạo ảnh</span>
            </div>
            <div class="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
              <div id="studioProgressBar" class="h-full bg-violet-600 transition-all duration-300" style="width: 0%"></div>
            </div>
          </div>
        </div>

        <!-- Cột phải: Xem trước & Lịch sử ảnh (7 cols) -->
        <div class="lg:col-span-7 bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-col gap-3 min-h-0 overflow-hidden">
          <!-- Khung Preview -->
          <div id="studioPreviewBox" class="flex-1 min-h-[260px] rounded-xl bg-slate-100/80 dark:bg-slate-900/90 border border-slate-200/80 dark:border-slate-800 flex items-center justify-center overflow-hidden relative p-2">
            <div id="studioEmptyPreview" class="text-center text-slate-400 space-y-2 p-6">
              <i class="fa-regular fa-image text-4xl text-slate-300 dark:text-slate-700"></i>
              <p class="text-xs font-medium">Ảnh tạo ra sẽ hiển thị tại đây</p>
              <p class="text-[11px] text-slate-400">Chọn nguồn API, nhập Prompt và bấm "Tạo Ảnh Ngay"</p>
            </div>
            <img id="studioPreviewImg" src="" alt="AI Generated" class="hidden max-h-full max-w-full object-contain rounded-lg shadow-md cursor-pointer" title="Bấm để mở ảnh gốc" />
          </div>

          <!-- Thông tin ảnh & Thanh nút thao tác -->
          <div class="space-y-2 shrink-0">
            <div id="studioRevisedPromptLabel" class="text-[11px] text-slate-600 dark:text-slate-300 italic truncate"></div>
            <div class="flex flex-wrap items-center justify-between gap-2">
              <div class="flex flex-wrap items-center gap-1.5">
                <button type="button" id="studioBtnOpenImg" disabled class="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-40 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5 transition">
                  <i class="fa-regular fa-eye text-sky-500"></i>
                  <span>Mở Ảnh</span>
                </button>
                <button type="button" id="studioBtnSaveAs" disabled class="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-40 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5 transition">
                  <i class="fa-solid fa-download text-emerald-500"></i>
                  <span>Lưu Thành...</span>
                </button>
                <button type="button" id="studioBtnOpenFolder" class="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5 transition">
                  <i class="fa-regular fa-folder-open text-amber-500"></i>
                  <span>Thư Mục Lưu</span>
                </button>
                <button type="button" id="studioBtnCopyPath" disabled class="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-40 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5 transition">
                  <i class="fa-regular fa-copy text-violet-500"></i>
                  <span>Copy Đường Dẫn</span>
                </button>
              </div>
              <button type="button" id="studioBtnViewJson" class="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 mono transition">
                { } Xem JSON API
              </button>
            </div>
          </div>

          <!-- Lịch sử ảnh đã tạo -->
          <div class="pt-1 border-t border-slate-200 dark:border-slate-800 shrink-0">
            <div class="text-[11px] font-bold text-slate-400 mb-1.5 flex items-center justify-between">
              <span>Lịch sử ảnh đã tạo (Lưu tại image_studio/generated_images):</span>
              <span id="studioHistoryCountLabel" class="mono text-[10px]">0 ảnh</span>
            </div>
            <div id="studioHistoryStrip" class="flex items-center gap-2 overflow-x-auto pb-1 min-h-[68px]"></div>
          </div>
        </div>
      </div>

      <!-- ==================== TAB 2: TẠO VIDEO AI ==================== -->
      <div id="studioTabVideo" class="hidden flex-1 p-5 overflow-y-auto">
        <div class="max-w-5xl mx-auto bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
          <div>
            <h2 class="text-base font-bold text-slate-800 dark:text-white flex items-center gap-2">
              <i class="fa-solid fa-film text-violet-500"></i>
              <span>🎬 Tạo Video AI (Multi-API)</span>
            </h2>
            <p id="studioVideoApiSub" class="text-xs text-violet-600 dark:text-violet-400 mono mt-0.5">Nguồn API: modelapi.vn</p>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
            <div>
              <label class="block font-semibold text-slate-600 dark:text-slate-300 mb-1">Nguồn API (Profile)</label>
              <select id="studioVideoProfileSelect" class="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white"></select>
            </div>
            <div>
              <label class="block font-semibold text-slate-600 dark:text-slate-300 mb-1">Video Model (Chọn/Tự gõ)</label>
              <input id="studioVideoModelInput" list="studioVideoModelList" type="text" value="sora-2" class="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white mono" />
              <datalist id="studioVideoModelList">
                <option value="sora-2"></option>
                <option value="veo-2"></option>
                <option value="cogvideox"></option>
                <option value="grok-imagine-video"></option>
              </datalist>
            </div>
            <div>
              <label class="block font-semibold text-slate-600 dark:text-slate-300 mb-1">Thời lượng (giây)</label>
              <select id="studioVideoDuration" class="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white">
                <option value="5">5 giây</option>
                <option value="8">8 giây</option>
                <option value="10">10 giây</option>
                <option value="15">15 giây</option>
              </select>
            </div>
            <div>
              <label class="block font-semibold text-slate-600 dark:text-slate-300 mb-1">Tỉ lệ & Độ phân giải</label>
              <select id="studioVideoRatio" class="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white">
                <option value="16:9 · 720p">16:9 · 720p</option>
                <option value="9:16 · 720p">9:16 · 720p</option>
                <option value="1:1 · 720p">1:1 · 720p</option>
                <option value="16:9 · 1080p">16:9 · 1080p</option>
              </select>
            </div>
          </div>

          <div class="text-xs">
            <label class="block font-semibold text-slate-700 dark:text-slate-200 mb-1">Mô tả Video (Prompt) *</label>
            <textarea id="studioVideoPrompt" rows="4" class="w-full p-3 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white text-xs">Cảnh flycam bay qua vịnh Hạ Long lúc bình minh, ánh nắng vàng chiếu xuống làn nước xanh ngọc bích, điện ảnh 4k</textarea>
          </div>

          <div class="flex items-center gap-3">
            <button type="button" id="studioGenVideoBtn" class="px-5 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-bold text-xs shadow-sm flex items-center gap-2 transition">
              <i class="fa-solid fa-film"></i>
              <span>🎬 Gửi Yêu Cầu Tạo Video</span>
            </button>
            <span id="studioVideoStatus" class="text-xs text-slate-500 dark:text-slate-400">Sẵn sàng gửi request tới Video Endpoint của Profile đang chọn.</span>
          </div>

          <pre id="studioVideoResultBox" class="p-4 rounded-xl bg-slate-950 text-slate-200 mono text-xs h-56 overflow-auto whitespace-pre-wrap select-text">// Kết quả JSON hoặc đường dẫn tải video từ API sẽ hiển thị tại đây...</pre>
        </div>
      </div>

      <!-- ==================== TAB 3: CÀI ĐẶT ĐA PROFILE API ==================== -->
      <div id="studioTabSettings" class="hidden flex-1 p-5 overflow-y-auto">
        <div class="max-w-5xl mx-auto bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5 text-xs">
          <div>
            <h2 class="text-base font-bold text-slate-800 dark:text-white">Cài đặt & Quản lý Nguồn API (Multi-Provider)</h2>
            <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Thêm và chuyển đổi linh hoạt giữa nhiều API khác nhau (cheapkeyai.shop, modelapi.vn, OpenAI, OpenRouter, Together, SiliconFlow, ModelGate, Local API...).</p>
          </div>

          <!-- Danh sách Profile Buttons -->
          <div class="space-y-2">
            <div class="text-[11px] font-bold text-slate-400 uppercase">DANH SÁCH PROFILE API (Bấm để chuyển nguồn API đang dùng):</div>
            <div id="studioProfileButtonsBar" class="flex flex-wrap items-center gap-2"></div>
          </div>

          <!-- Thanh công cụ Preset nhanh + Thêm / Nhân bản / Xóa -->
          <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
            <div class="flex flex-wrap items-center gap-2">
              <span class="font-bold text-slate-700 dark:text-slate-200">⚡ Điền nhanh mẫu API:</span>
              <select id="studioPresetSelect" class="px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white">
                <option value="">Chọn nhà cung cấp API mẫu...</option>
              </select>
              <button type="button" id="studioAddProfileBtn" class="px-3 py-1.5 rounded-lg bg-violet-600 hover:bg-violet-500 text-white font-semibold transition">
                + Tạo Profile Mới
              </button>
              <button type="button" id="studioDupProfileBtn" class="px-3 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 text-slate-700 dark:text-slate-200 font-semibold transition">
                📋 Nhân bản
              </button>
            </div>
            <button type="button" id="studioDeleteProfileBtn" class="px-3 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-600 text-rose-600 dark:text-rose-400 hover:text-white border border-rose-200 dark:border-rose-800 font-semibold transition">
              🗑️ Xóa Profile
            </button>
          </div>

          <!-- Form thông tin Profile -->
          <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label class="block font-bold text-slate-600 dark:text-slate-300 mb-1">TÊN PROFILE (GHI NHỚ)</label>
              <input id="cfgProfileName" type="text" placeholder="VD: cheapkeyai.shop, OpenAI..." class="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white" />
            </div>
            <div class="sm:col-span-2">
              <label class="block font-bold text-slate-600 dark:text-slate-300 mb-1">BASE URL (ĐỊA CHỈ MÁY CHỦ API)</label>
              <input id="cfgBaseUrl" type="text" placeholder="https://modelapi.vn/v1" class="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white mono" />
            </div>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div class="sm:col-span-3">
              <label class="block font-bold text-slate-600 dark:text-slate-300 mb-1">API KEY / TOKEN</label>
              <div class="flex gap-2">
                <input id="cfgApiKey" type="password" placeholder="sk-..." class="flex-1 px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white mono" />
                <button type="button" id="cfgToggleKeyBtn" class="px-3.5 py-2 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 font-semibold">Hiện</button>
              </div>
            </div>
            <div>
              <label class="block font-bold text-slate-600 dark:text-slate-300 mb-1">KIỂU XÁC THỰC (AUTH)</label>
              <select id="cfgAuthType" class="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white">
                <option value="Bearer">Bearer</option>
                <option value="X-API-Key">X-API-Key</option>
                <option value="Api-Key">Api-Key</option>
                <option value="Authorization (Raw)">Authorization (Raw)</option>
                <option value="None (Không dùng)">None (Không dùng)</option>
              </select>
            </div>
          </div>

          <!-- Toggle Cài đặt nâng cao -->
          <div>
            <button type="button" id="cfgAdvToggleBtn" class="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-600 dark:text-slate-300 font-medium">
              ▸ Hiện cài đặt nâng cao (Endpoint Paths, Custom Headers, Timeout)
            </button>

            <div id="cfgAdvBox" class="hidden mt-3 p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
              <div class="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div>
                  <label class="block font-semibold text-slate-500 mb-1">Image Generation Path</label>
                  <input id="cfgImagePath" type="text" value="/images/generations" class="w-full px-2.5 py-1.5 rounded bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 mono" />
                </div>
                <div>
                  <label class="block font-semibold text-slate-500 mb-1">Image Edit Path</label>
                  <input id="cfgEditPath" type="text" value="/images/edits" class="w-full px-2.5 py-1.5 rounded bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 mono" />
                </div>
                <div>
                  <label class="block font-semibold text-slate-500 mb-1">Video Generation Path</label>
                  <input id="cfgVideoPath" type="text" value="/videos/generations" class="w-full px-2.5 py-1.5 rounded bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 mono" />
                </div>
                <div>
                  <label class="block font-semibold text-slate-500 mb-1">Models List Path</label>
                  <input id="cfgModelsPath" type="text" value="/models" class="w-full px-2.5 py-1.5 rounded bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 mono" />
                </div>
              </div>
              <div class="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div class="sm:col-span-3">
                  <label class="block font-semibold text-slate-500 mb-1">Custom Headers (JSON hoặc Key: Value)</label>
                  <input id="cfgCustomHeaders" type="text" placeholder='VD: {"HTTP-Referer": "https://myapp.com"}' class="w-full px-2.5 py-1.5 rounded bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 mono" />
                </div>
                <div>
                  <label class="block font-semibold text-slate-500 mb-1">Timeout (Giây)</label>
                  <input id="cfgTimeout" type="number" value="120" class="w-full px-2.5 py-1.5 rounded bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 mono" />
                </div>
              </div>
            </div>
          </div>

          <!-- Mặc định Image Model & Video Model -->
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label id="cfgImModelLabel" class="block font-bold text-slate-600 dark:text-slate-300 mb-1">MẶC ĐỊNH — IMAGE MODEL (Chọn hoặc tự gõ)</label>
              <input id="cfgImageModel" list="studioModelDatalist" type="text" class="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white mono" />
            </div>
            <div>
              <label class="block font-bold text-slate-600 dark:text-slate-300 mb-1">MẶC ĐỊNH — VIDEO MODEL (Chọn hoặc tự gõ)</label>
              <input id="cfgVideoModel" list="studioVideoModelList" type="text" class="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-white mono" />
            </div>
          </div>

          <!-- Hộp trạng thái -->
          <div id="cfgStatusBanner" class="p-3.5 rounded-xl bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-800/80 text-blue-700 dark:text-blue-300 text-xs">
            💡 Bạn có thể chọn nhanh nhà cung cấp từ 'Điền nhanh mẫu API', hoặc tự nhập Base URL + API Key của bất kỳ bên nào.
          </div>

          <!-- Nút Kiểm tra kết nối & Lưu -->
          <div class="flex flex-wrap items-center gap-3">
            <button type="button" id="cfgTestConnBtn" class="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold shadow-xs flex items-center gap-2 transition">
              <i class="fa-solid fa-bolt"></i>
              <span>⚡ Kiểm tra kết nối & Tải Models</span>
            </button>
            <button type="button" id="cfgSaveBtn" class="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold shadow-xs flex items-center gap-2 transition">
              <i class="fa-solid fa-floppy-disk"></i>
              <span>💾 Lưu cài đặt Profile</span>
            </button>
          </div>
        </div>
      </div>
    `;
  }

  // ==================== 3. ĐỒNG BỘ DỮ LIỆU & SỰ KIỆN ====================
  async function loadStudioState() {
    try {
      const res = await fetch('/api/image-studio/state?t=' + Date.now(), { cache: 'no-store' });
      const data = await res.json();
      if (data.success) {
        studioConfig = data.config;
        studioPresets = data.presets || {};
        studioHistory = data.history || [];
        populatePresetsDropdown();
        refreshAllStudioViews();
        renderHistoryStrip();
        if (studioHistory.length > 0 && !currentPreviewItem) {
          showPreviewItem(studioHistory[0]);
        }
      }
    } catch (e) {
      console.error('[ImageStudio] Không thể tải trạng thái:', e);
    }
  }

  function populatePresetsDropdown() {
    const sel = document.getElementById('studioPresetSelect');
    if (!sel) return;
    const keys = Object.keys(studioPresets);
    sel.innerHTML =
      `<option value="">Chọn nhà cung cấp API mẫu...</option>` +
      keys.map((k) => `<option value="${esc(k)}">${esc(k)}</option>`).join('');
  }

  function refreshAllStudioViews() {
    if (!studioConfig) return;
    const prof = getActiveProfile();
    const profiles = studioConfig.profiles || [];

    // 1. Pill trên thanh sub-nav
    const pill = document.getElementById('studioActiveApiPill');
    if (pill) pill.textContent = `${prof.name} (${prof.base_url})`;

    // 2. Render các nút Profile ở Tab Settings
    const bar = document.getElementById('studioProfileButtonsBar');
    if (bar) {
      bar.innerHTML = profiles
        .map((p) => {
          const active = p.id === studioConfig.active_profile_id;
          return `
            <button
              type="button"
              data-switch-prof="${esc(p.id)}"
              class="px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                active
                  ? 'bg-violet-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
              }"
            >
              ${active ? '✓ ' : ''}${esc(p.name)}
            </button>
          `;
        })
        .join('');

      bar.querySelectorAll('button[data-switch-prof]').forEach((b) => {
        b.onclick = () => switchActiveApiProfile(b.getAttribute('data-switch-prof'));
      });
    }

    const delBtn = document.getElementById('studioDeleteProfileBtn');
    if (delBtn) delBtn.disabled = profiles.length <= 1;

    // 3. Điền form Settings
    const setVal = (id, v) => {
      const el = document.getElementById(id);
      if (el) el.value = v !== undefined && v !== null ? v : '';
    };
    setVal('cfgProfileName', prof.name || 'modelapi.vn');
    setVal('cfgBaseUrl', prof.base_url || 'https://modelapi.vn/v1');
    setVal('cfgApiKey', prof.api_key || '');
    setVal('cfgAuthType', prof.auth_type || 'Bearer');
    setVal('cfgImagePath', prof.image_path || '/images/generations');
    setVal('cfgEditPath', prof.edit_path || '/images/edits');
    setVal('cfgVideoPath', prof.video_path || '/videos/generations');
    setVal('cfgModelsPath', prof.models_path || '/models');
    setVal('cfgCustomHeaders', prof.custom_headers || '');
    setVal('cfgTimeout', prof.timeout || 120);
    setVal('cfgImageModel', prof.image_model || 'gpt-image-2');
    setVal('cfgVideoModel', prof.video_model || 'sora-2');

    const models = prof.available_models || ['gpt-image-2'];
    const imLbl = document.getElementById('cfgImModelLabel');
    if (imLbl) {
      imLbl.textContent = `MẶC ĐỊNH — IMAGE MODEL (${models.length} MODEL - Chọn hoặc tự gõ)`;
    }

    const datalist = document.getElementById('studioModelDatalist');
    if (datalist) {
      datalist.innerHTML = models.map((m) => `<option value="${esc(m)}"></option>`).join('');
    }

    // 4. Dropdown Profile & Model ở Tab Tạo ảnh & Tạo video
    const profOptionsHtml = profiles
      .map(
        (p) =>
          `<option value="${esc(p.id)}" ${
            p.id === studioConfig.active_profile_id ? 'selected' : ''
          }>${esc(p.name)} (${esc(p.base_url)})</option>`
      )
      .join('');

    const createProfSel = document.getElementById('studioCreateProfileSelect');
    if (createProfSel) createProfSel.innerHTML = profOptionsHtml;

    const videoProfSel = document.getElementById('studioVideoProfileSelect');
    if (videoProfSel) videoProfSel.innerHTML = profOptionsHtml;

    setVal('studioCreateModelInput', prof.image_model || models[0] || 'gpt-image-2');
    setVal('studioVideoModelInput', prof.video_model || 'sora-2');

    const createSub = document.getElementById('studioCreateApiSub');
    if (createSub) {
      createSub.textContent = `Nguồn API: ${prof.name} · ${prof.base_url}`;
    }
    const videoSub = document.getElementById('studioVideoApiSub');
    if (videoSub) {
      videoSub.textContent = `Nguồn API: ${prof.name} — ${prof.base_url}${
        prof.video_path || '/videos/generations'
      }`;
    }
  }

  function collectSettingsFormToActiveProfile() {
    if (!studioConfig) return null;
    const prof = getActiveProfile();
    const getVal = (id) => (document.getElementById(id)?.value || '').trim();

    prof.name = getVal('cfgProfileName') || 'Custom API';
    prof.base_url = getVal('cfgBaseUrl') || 'https://modelapi.vn/v1';
    prof.api_key = getVal('cfgApiKey');
    prof.auth_type = getVal('cfgAuthType') || 'Bearer';
    prof.image_path = getVal('cfgImagePath') || '/images/generations';
    prof.edit_path = getVal('cfgEditPath') || '/images/edits';
    prof.video_path = getVal('cfgVideoPath') || '/videos/generations';
    prof.models_path = getVal('cfgModelsPath') || '/models';
    prof.custom_headers = getVal('cfgCustomHeaders');
    prof.timeout = Math.max(10, parseInt(getVal('cfgTimeout') || '120', 10) || 120);

    const imModel = getVal('cfgImageModel');
    if (imModel) {
      prof.image_model = imModel;
      if (!Array.isArray(prof.available_models)) prof.available_models = [];
      if (!prof.available_models.includes(imModel)) {
        prof.available_models.unshift(imModel);
      }
    }
    const vidModel = getVal('cfgVideoModel');
    if (vidModel) {
      prof.video_model = vidModel;
    }
    return prof;
  }

  async function saveStudioConfigToServer(collectFromSettings = true) {
    if (collectFromSettings) {
      collectSettingsFormToActiveProfile();
    }
    const res = await fetch('/api/image-studio/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        active_profile_id: studioConfig.active_profile_id,
        profiles: studioConfig.profiles,
      }),
    });
    const data = await res.json();
    if (data.success) {
      studioConfig = data.config;
      refreshAllStudioViews();
    }
    return data;
  }

  async function switchActiveApiProfile(profileId) {
    collectSettingsFormToActiveProfile();
    studioConfig.active_profile_id = profileId;
    await saveStudioConfigToServer(false);
    const prof = getActiveProfile();
    setSettingsBanner(`🔄 Đã chuyển sang Profile API: ${prof.name} (${prof.base_url})`, 'info');
  }

  function setSettingsBanner(msg, type = 'info') {
    const el = document.getElementById('cfgStatusBanner');
    if (!el) return;
    if (type === 'success') {
      el.className =
        'p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs whitespace-pre-line';
    } else if (type === 'error') {
      el.className =
        'p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-600 dark:text-rose-300 text-xs whitespace-pre-line';
    } else {
      el.className =
        'p-3.5 rounded-xl bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 text-xs whitespace-pre-line';
    }
    el.textContent = msg;
  }

  function switchStudioSubTab(tabName) {
    studioSubTab = tabName;
    document.getElementById('studioTabCreate')?.classList.toggle('hidden', tabName !== 'create');
    document.getElementById('studioTabVideo')?.classList.toggle('hidden', tabName !== 'video');
    document.getElementById('studioTabSettings')?.classList.toggle('hidden', tabName !== 'settings');

    document.querySelectorAll('.studio-tab-btn').forEach((btn) => {
      const t = btn.getAttribute('data-studio-tab');
      if (t === tabName) {
        btn.className =
          'studio-tab-btn px-3.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 bg-violet-600 text-white shadow-xs transition';
      } else {
        btn.className =
          'studio-tab-btn px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition';
      }
    });
  }

  // ==================== 4. LỊCH SỬ & XEM ẢNH ====================
  function showPreviewItem(item) {
    if (!item) return;
    currentPreviewItem = item;
    const emptyEl = document.getElementById('studioEmptyPreview');
    const imgEl = document.getElementById('studioPreviewImg');
    if (emptyEl) emptyEl.classList.add('hidden');
    if (imgEl) {
      imgEl.src = item.url + '?t=' + Date.now();
      imgEl.classList.remove('hidden');
    }

    ['studioBtnOpenImg', 'studioBtnSaveAs', 'studioBtnCopyPath'].forEach((id) => {
      const b = document.getElementById(id);
      if (b) b.disabled = false;
    });

    const rpEl = document.getElementById('studioRevisedPromptLabel');
    if (rpEl) {
      const prov = item.provider ? `[${item.provider}] ` : '';
      if (item.revised_prompt) {
        rpEl.textContent = `📝 ${prov}Model Prompt: ${item.revised_prompt}`;
      } else {
        rpEl.textContent = `📌 ${prov}Model: ${item.model || 'AI'} · Kích thước: ${
          item.size || '1024x1024'
        } · File: ${item.filename}`;
      }
    }
    renderHistoryStrip();
  }

  function renderHistoryStrip() {
    const strip = document.getElementById('studioHistoryStrip');
    const countLbl = document.getElementById('studioHistoryCountLabel');
    if (!strip) return;
    if (countLbl) countLbl.textContent = `${studioHistory.length} ảnh`;

    if (studioHistory.length === 0) {
      strip.innerHTML = `<span class="text-[11px] text-slate-400 italic">Chưa có ảnh nào trong thư mục generated_images.</span>`;
      return;
    }

    strip.innerHTML = studioHistory
      .map((item, idx) => {
        const active = currentPreviewItem && currentPreviewItem.filename === item.filename;
        return `
          <div class="relative group shrink-0">
            <img
              src="${esc(item.url)}"
              data-hist-idx="${idx}"
              alt="${esc(item.filename)}"
              title="${esc(item.prompt || item.filename)}"
              class="w-16 h-16 object-cover rounded-lg cursor-pointer border-2 transition ${
                active
                  ? 'border-violet-600 scale-105 shadow-xs'
                  : 'border-slate-200 dark:border-slate-700 opacity-80 hover:opacity-100'
              }"
            />
            <button
              type="button"
              data-del-file="${esc(item.filename)}"
              title="Xóa ảnh này"
              class="hidden group-hover:flex absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-rose-600 text-white text-[9px] items-center justify-center shadow"
            >
              ×
            </button>
          </div>
        `;
      })
      .join('');

    strip.querySelectorAll('img[data-hist-idx]').forEach((img) => {
      img.onclick = () => {
        const i = parseInt(img.getAttribute('data-hist-idx'), 10);
        if (studioHistory[i]) showPreviewItem(studioHistory[i]);
      };
    });

    strip.querySelectorAll('button[data-del-file]').forEach((btn) => {
      btn.onclick = async (e) => {
        e.stopPropagation();
        const fname = btn.getAttribute('data-del-file');
        if (!fname) return;
        await fetch(`/api/image-studio/images/${encodeURIComponent(fname)}`, {
          method: 'DELETE',
        });
        studioHistory = studioHistory.filter((x) => x.filename !== fname);
        if (currentPreviewItem && currentPreviewItem.filename === fname) {
          currentPreviewItem = studioHistory[0] || null;
          if (currentPreviewItem) {
            showPreviewItem(currentPreviewItem);
          } else {
            document.getElementById('studioPreviewImg')?.classList.add('hidden');
            document.getElementById('studioEmptyPreview')?.classList.remove('hidden');
          }
        }
        renderHistoryStrip();
      };
    });
  }

  // ==================== 5. GẮN SỰ KIỆN NÚT BẤM ====================
  function bindStudioEvents() {
    // Chuyển sub-tab
    document.querySelectorAll('.studio-tab-btn').forEach((btn) => {
      btn.onclick = () => switchStudioSubTab(btn.getAttribute('data-studio-tab'));
    });

    document.getElementById('studioShortcutSettingsBtn')?.addEventListener('click', () => {
      switchStudioSubTab('settings');
    });

    // Chọn Profile ở tab Tạo ảnh / Tạo video
    document.getElementById('studioCreateProfileSelect')?.addEventListener('change', (e) => {
      switchActiveApiProfile(e.target.value);
    });
    document.getElementById('studioVideoProfileSelect')?.addEventListener('change', (e) => {
      switchActiveApiProfile(e.target.value);
    });

    // Gợi ý Prompt
    document.querySelectorAll('.studio-tpl-btn').forEach((btn) => {
      btn.onclick = () => {
        const t = btn.getAttribute('data-prompt-tpl');
        const box = document.getElementById('studioPromptInput');
        if (!box) return;
        if (t === 'poster') {
          box.value =
            'Poster quảng cáo sản phẩm tai nghe gaming phong cách hiện đại tối giản, ánh sáng studio nghệ thuật, typography nổi bật, photorealistic 8k';
        } else if (t === 'cyberpunk') {
          box.value =
            'Một chú robot phong cách cyberpunk đang làm việc tại quán cà phê đêm ở Hà Nội, ánh sáng neon rực rỡ, chi tiết máy móc tinh xảo, 8k';
        }
      };
    });

    // Chọn ảnh tham chiếu
    const refInput = document.getElementById('studioRefFilesInput');
    const clearRefBtn = document.getElementById('studioClearRefBtn');
    const refLabel = document.getElementById('studioRefCountLabel');

    refInput?.addEventListener('change', (e) => {
      const files = Array.from(e.target.files || []);
      if (files.length === 0) return;
      referenceImages = [];
      let loaded = 0;
      files.forEach((f) => {
        const reader = new FileReader();
        reader.onload = (ev) => {
          referenceImages.push({ name: f.name, data_url: ev.target.result });
          loaded++;
          if (loaded === files.length) {
            if (refLabel) {
              refLabel.textContent = `Đã chọn ${referenceImages.length} ảnh`;
              refLabel.className = 'text-[11px] text-emerald-600 font-semibold';
            }
            clearRefBtn?.classList.remove('hidden');
          }
        };
        reader.readAsDataURL(f);
      });
    });

    clearRefBtn?.addEventListener('click', () => {
      referenceImages = [];
      if (refInput) refInput.value = '';
      if (refLabel) {
        refLabel.textContent = 'Chưa chọn ảnh';
        refLabel.className = 'text-[11px] text-slate-400';
      }
      clearRefBtn.classList.add('hidden');
    });

    // Custom JSON toggle
    const customToggle = document.getElementById('studioCustomJsonToggle');
    const customArea = document.getElementById('studioCustomJsonTextarea');
    customToggle?.addEventListener('change', () => {
      if (customToggle.checked) {
        const model = document.getElementById('studioCreateModelInput')?.value || 'gpt-image-2';
        const prompt = document.getElementById('studioPromptInput')?.value || '';
        const size = (document.getElementById('studioSizeInput')?.value || '1024x1024').split(' ')[0];
        const sample = { model, prompt };
        if (size.toLowerCase() !== 'auto') sample.size = size;
        customArea.value = JSON.stringify(sample, null, 2);
        customArea.classList.remove('hidden');
      } else {
        customArea.classList.add('hidden');
      }
    });

    // Nút Tạo ảnh
    document.getElementById('studioGenerateBtn')?.addEventListener('click', handleGenerateImage);

    // Nút Tạo video
    document.getElementById('studioGenVideoBtn')?.addEventListener('click', handleGenerateVideo);

    // Các nút thao tác file ảnh
    document.getElementById('studioPreviewImg')?.addEventListener('click', () => {
      if (currentPreviewItem) {
        fetch('/api/image-studio/open-image', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ filename: currentPreviewItem.filename }),
        });
      }
    });

    document.getElementById('studioBtnOpenImg')?.addEventListener('click', () => {
      if (!currentPreviewItem) return;
      fetch('/api/image-studio/open-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: currentPreviewItem.filename }),
      });
    });

    document.getElementById('studioBtnSaveAs')?.addEventListener('click', async () => {
      if (!currentPreviewItem) return;
      const res = await fetch('/api/image-studio/save-as', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: currentPreviewItem.filename }),
      });
      const data = await res.json();
      if (data.success && data.saved_to) {
        notify(`Đã lưu ảnh ra: ${data.saved_to}`, 'success');
      } else if (data.fallback_download) {
        const a = document.createElement('a');
        a.href = currentPreviewItem.url;
        a.download = currentPreviewItem.filename;
        a.click();
      }
    });

    const openFolderHandler = async () => {
      try {
        const res = await fetch('/api/image-studio/open-folder', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            filename: currentPreviewItem ? currentPreviewItem.filename : null,
          }),
        });
        const data = await res.json();
        if (data && data.success) {
          notify('📁 Đã mở thư mục lưu ảnh trong File Explorer!', 'success');
        } else {
          notify('⚠️ Không thể mở thư mục: ' + ((data && data.error) || 'Lỗi không xác định'), 'error');
        }
      } catch (err) {
        notify('⚠️ Lỗi kết nối khi mở thư mục lưu ảnh', 'error');
      }
    };
    document.getElementById('studioBtnOpenFolder')?.addEventListener('click', openFolderHandler);
    document.getElementById('studioTopOpenFolderBtn')?.addEventListener('click', openFolderHandler);

    document.getElementById('studioBtnCopyPath')?.addEventListener('click', () => {
      if (!currentPreviewItem) return;
      navigator.clipboard.writeText(currentPreviewItem.path);
      notify('📋 Đã chép đường dẫn ảnh vào Clipboard!', 'success');
    });

    document.getElementById('studioBtnViewJson')?.addEventListener('click', () => {
      const modal = document.getElementById('studioRawJsonModal');
      const pre = document.getElementById('studioRawJsonContent');
      if (pre) {
        pre.textContent =
          lastRawApiResponse === null
            ? 'Chưa có phản hồi API nào trong phiên này.'
            : typeof lastRawApiResponse === 'object'
            ? JSON.stringify(lastRawApiResponse, null, 2)
            : String(lastRawApiResponse);
      }
      modal?.classList.remove('hidden');
      modal?.classList.add('flex');
    });

    document.getElementById('closeStudioJsonModalBtn')?.addEventListener('click', () => {
      const modal = document.getElementById('studioRawJsonModal');
      modal?.classList.add('hidden');
      modal?.classList.remove('flex');
    });

    // Sự kiện ở Tab Settings
    document.getElementById('cfgToggleKeyBtn')?.addEventListener('click', () => {
      const inp = document.getElementById('cfgApiKey');
      const btn = document.getElementById('cfgToggleKeyBtn');
      if (!inp || !btn) return;
      if (inp.type === 'password') {
        inp.type = 'text';
        btn.textContent = 'Ẩn';
      } else {
        inp.type = 'password';
        btn.textContent = 'Hiện';
      }
    });

    document.getElementById('cfgAdvToggleBtn')?.addEventListener('click', () => {
      advSettingsOpen = !advSettingsOpen;
      const box = document.getElementById('cfgAdvBox');
      const btn = document.getElementById('cfgAdvToggleBtn');
      if (box) box.classList.toggle('hidden', !advSettingsOpen);
      if (btn) {
        btn.textContent = advSettingsOpen
          ? '▾ Ẩn cài đặt nâng cao (Endpoint Paths, Custom Headers, Timeout)'
          : '▸ Hiện cài đặt nâng cao (Endpoint Paths, Custom Headers, Timeout)';
      }
    });

    document.getElementById('studioPresetSelect')?.addEventListener('change', async (e) => {
      const key = e.target.value;
      if (!key || !studioPresets[key]) return;
      const tpl = studioPresets[key];
      const prof = getActiveProfile();
      prof.name = tpl.name;
      prof.base_url = tpl.base_url;
      prof.image_path = tpl.image_path;
      prof.edit_path = tpl.edit_path;
      prof.video_path = tpl.video_path;
      prof.models_path = tpl.models_path;
      prof.auth_type = tpl.auth_type;
      prof.image_model = tpl.image_model;
      prof.video_model = tpl.video_model;
      prof.available_models = [...(tpl.available_models || [])];
      await saveStudioConfigToServer(false);
      setSettingsBanner(
        `✨ Đã áp dụng mẫu [${key}]. Hãy kiểm tra API Key rồi bấm 'Lưu cài đặt Profile' hoặc 'Kiểm tra kết nối'!`,
        'success'
      );
    });

    document.getElementById('studioAddProfileBtn')?.addEventListener('click', async () => {
      collectSettingsFormToActiveProfile();
      const profiles = studioConfig.profiles || [];
      const newIdx = profiles.length + 1;
      const newId = 'prof_' + Math.random().toString(36).substring(2, 8);
      const presetKey = document.getElementById('studioPresetSelect')?.value;
      const tpl = presetKey && studioPresets[presetKey] ? studioPresets[presetKey] : null;

      const newProf = {
        id: newId,
        name: tpl ? `${tpl.name} #${newIdx}` : `Custom API #${newIdx}`,
        base_url: tpl ? tpl.base_url : 'https://api.openai.com/v1',
        api_key: '',
        image_path: tpl ? tpl.image_path : '/images/generations',
        edit_path: tpl ? tpl.edit_path : '/images/edits',
        video_path: tpl ? tpl.video_path : '/videos/generations',
        models_path: tpl ? tpl.models_path : '/models',
        auth_type: tpl ? tpl.auth_type : 'Bearer',
        custom_headers: '',
        timeout: 120,
        image_model: tpl ? tpl.image_model : 'gpt-image-1',
        video_model: tpl ? tpl.video_model : 'sora-2',
        available_models: tpl ? [...tpl.available_models] : ['gpt-image-1', 'dall-e-3'],
      };
      studioConfig.profiles.push(newProf);
      studioConfig.active_profile_id = newId;
      await saveStudioConfigToServer(false);
      setSettingsBanner(`➕ Đã tạo Profile mới '${newProf.name}'.`, 'success');
    });

    document.getElementById('studioDupProfileBtn')?.addEventListener('click', async () => {
      collectSettingsFormToActiveProfile();
      const cur = getActiveProfile();
      const dup = JSON.parse(JSON.stringify(cur));
      dup.id = 'prof_' + Math.random().toString(36).substring(2, 8);
      dup.name = `${cur.name} (Copy)`;
      studioConfig.profiles.push(dup);
      studioConfig.active_profile_id = dup.id;
      await saveStudioConfigToServer(false);
      setSettingsBanner(`📋 Đã nhân bản sang profile '${dup.name}'.`, 'success');
    });

    document.getElementById('studioDeleteProfileBtn')?.addEventListener('click', async () => {
      if ((studioConfig.profiles || []).length <= 1) return;
      const cur = getActiveProfile();
      if (!confirm(`Xóa Profile API "${cur.name}"?`)) return;
      studioConfig.profiles = studioConfig.profiles.filter((p) => p.id !== cur.id);
      studioConfig.active_profile_id = studioConfig.profiles[0].id;
      await saveStudioConfigToServer(false);
      setSettingsBanner(`🗑️ Đã xóa profile '${cur.name}'.`, 'error');
    });

    document.getElementById('cfgSaveBtn')?.addEventListener('click', async () => {
      await saveStudioConfigToServer(true);
      const prof = getActiveProfile();
      setSettingsBanner(
        `✅ Đã lưu cấu hình Profile '${prof.name}' (${prof.base_url}) vào image_studio/config.json!`,
        'success'
      );
      notify(`Đã lưu cấu hình API: ${prof.name}`, 'success');
    });

    document.getElementById('cfgTestConnBtn')?.addEventListener('click', async () => {
      await saveStudioConfigToServer(true);
      const prof = getActiveProfile();
      const btn = document.getElementById('cfgTestConnBtn');
      if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i><span>Đang kiểm tra...</span>`;
      }
      setSettingsBanner('⏳ Đang kết nối đến máy chủ API để kiểm tra & tải danh sách model...', 'info');

      try {
        const res = await fetch('/api/image-studio/test-connection', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            base_url: prof.base_url,
            api_key: prof.api_key,
            models_path: prof.models_path,
            image_path: prof.image_path,
            auth_type: prof.auth_type,
            custom_headers: prof.custom_headers,
          }),
        });
        const data = await res.json();
        if (data.success) {
          if (Array.isArray(data.models) && data.models.length > 0) {
            prof.available_models = data.models;
            if (!prof.image_model || !data.models.includes(prof.image_model)) {
              const imgCand = data.models.filter((m) =>
                /image|dall|flux|sd|imagen|kolors|midjourney/i.test(m)
              );
              prof.image_model = imgCand[0] || data.models[0];
            }
            await saveStudioConfigToServer(false);
            const preview =
              data.models.slice(0, 12).join(', ') +
              (data.models.length > 12 ? ` ... (+${data.models.length - 12} model khác)` : '');
            setSettingsBanner(`🎉 ${data.message}\nModels: ${preview}`, 'success');
          } else {
            setSettingsBanner(`✅ ${data.message}`, 'success');
          }
          notify('Kết nối API thành công!', 'success');
        } else {
          setSettingsBanner(`❌ ${data.error}`, 'error');
          notify('Lỗi kết nối API', 'error');
        }
      } catch (err) {
        setSettingsBanner(`❌ Lỗi kết nối: ${err.message}`, 'error');
      } finally {
        if (btn) {
          btn.disabled = false;
          btn.innerHTML = `<i class="fa-solid fa-bolt"></i><span>⚡ Kiểm tra kết nối & Tải Models</span>`;
        }
      }
    });
  }

  // ==================== 6. XỬ LÝ TẠO ẢNH & VIDEO ====================
  async function handleGenerateImage() {
    if (isGeneratingImage) return;

    const prof = getActiveProfile();
    const model = (document.getElementById('studioCreateModelInput')?.value || prof.image_model || 'gpt-image-2').trim();
    const prompt = (document.getElementById('studioPromptInput')?.value || '').trim();
    const size = (document.getElementById('studioSizeInput')?.value || '1024x1024').trim();
    const quality = document.getElementById('studioQualitySelect')?.value || 'standard';
    const style = document.getElementById('studioStyleSelect')?.value || 'vivid';
    const n = parseInt(document.getElementById('studioCountSelect')?.value || '1', 10) || 1;
    const negative_prompt = (document.getElementById('studioNegPromptInput')?.value || '').trim();
    const useCustomJson = document.getElementById('studioCustomJsonToggle')?.checked;

    if (!prof.api_key && prof.auth_type !== 'None (Không dùng)') {
      notify('Vui lòng nhập API Key ở tab Cài đặt API!', 'error');
      switchStudioSubTab('settings');
      return;
    }

    let custom_json = null;
    if (useCustomJson) {
      try {
        custom_json = JSON.parse(document.getElementById('studioCustomJsonTextarea')?.value || '{}');
      } catch (e) {
        notify('Custom JSON không hợp lệ: ' + e.message, 'error');
        return;
      }
    } else if (!prompt) {
      notify('Vui lòng nhập mô tả ảnh (Prompt)!', 'error');
      return;
    }

    isGeneratingImage = true;
    const btn = document.getElementById('studioGenerateBtn');
    const statusEl = document.getElementById('studioCreateStatusText');
    const bar = document.getElementById('studioProgressBar');

    if (btn) {
      btn.disabled = true;
      btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i><span>⏳ Đang Tạo Ảnh...</span>`;
    }
    if (statusEl) {
      statusEl.textContent = `🚀 Đang gửi yêu cầu tới [${prof.name}] · Model: ${model}...`;
      statusEl.className = 'text-violet-600 dark:text-violet-400 font-semibold truncate';
    }
    if (bar) bar.style.width = '45%';

    try {
      const res = await fetch('/api/image-studio/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          profile_id: prof.id,
          model,
          prompt,
          size,
          quality,
          style,
          n,
          negative_prompt,
          custom_json,
          reference_images: referenceImages,
        }),
      });
      const data = await res.json();
      if (data.raw_response !== undefined) {
        lastRawApiResponse = data.raw_response;
      }

      if (data.success && Array.isArray(data.items) && data.items.length > 0) {
        if (bar) bar.style.width = '100%';
        if (statusEl) {
          statusEl.textContent = `✅ Đã tạo thành công ${data.items.length} ảnh qua [${prof.name}]!`;
          statusEl.className = 'text-emerald-600 dark:text-emerald-400 font-semibold truncate';
        }
        // Đưa ảnh mới lên đầu lịch sử
        studioHistory = [...data.items.reverse(), ...studioHistory];
        showPreviewItem(studioHistory[0]);
        notify(`Đã tạo xong ${data.items.length} ảnh!`, 'success');
      } else {
        if (bar) bar.style.width = '0%';
        if (statusEl) {
          statusEl.textContent = `❌ Lỗi: ${data.error || 'Không thể tạo ảnh'}`;
          statusEl.className = 'text-rose-500 font-semibold truncate';
        }
        notify(data.error || 'Tạo ảnh thất bại', 'error');
      }
    } catch (err) {
      if (bar) bar.style.width = '0%';
      if (statusEl) {
        statusEl.textContent = `❌ Lỗi kết nối: ${err.message}`;
        statusEl.className = 'text-rose-500 font-semibold truncate';
      }
      notify('Lỗi khi gọi API tạo ảnh: ' + err.message, 'error');
    } finally {
      isGeneratingImage = false;
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = `<i class="fa-solid fa-wand-magic-sparkles"></i><span>✨ Tạo Ảnh Ngay</span>`;
      }
    }
  }

  async function handleGenerateVideo() {
    if (isGeneratingVideo) return;
    const prof = getActiveProfile();
    const model = (document.getElementById('studioVideoModelInput')?.value || 'sora-2').trim();
    const duration = parseInt(document.getElementById('studioVideoDuration')?.value || '5', 10) || 5;
    const ratioRaw = (document.getElementById('studioVideoRatio')?.value || '16:9 · 720p').split('·');
    const aspect_ratio = (ratioRaw[0] || '16:9').trim();
    const resolution = (ratioRaw[1] || '720p').trim();
    const prompt = (document.getElementById('studioVideoPrompt')?.value || '').trim();

    if (!prompt) {
      notify('Vui lòng nhập mô tả video!', 'error');
      return;
    }

    isGeneratingVideo = true;
    const btn = document.getElementById('studioGenVideoBtn');
    const statusEl = document.getElementById('studioVideoStatus');
    const outBox = document.getElementById('studioVideoResultBox');

    if (btn) {
      btn.disabled = true;
      btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i><span>⏳ Đang gửi...</span>`;
    }
    if (statusEl) {
      statusEl.textContent = `🚀 Đang gửi yêu cầu tạo video tới ${model}...`;
    }

    try {
      const res = await fetch('/api/image-studio/generate-video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          profile_id: prof.id,
          model,
          prompt,
          duration,
          aspect_ratio,
          resolution,
        }),
      });
      const data = await res.json();
      if (statusEl) {
        statusEl.textContent = data.success
          ? `✅ API phản hồi HTTP ${data.status_code} từ ${data.endpoint}`
          : `❌ Lỗi gọi Video API (${data.endpoint || ''})`;
      }
      if (outBox) {
        outBox.textContent =
          `Endpoint: ${data.endpoint || ''}\nHTTP Status: ${data.status_code || 0}\n\n` +
          (typeof data.response === 'object'
            ? JSON.stringify(data.response, null, 2)
            : String(data.response || data.error || ''));
      }
    } catch (err) {
      if (statusEl) statusEl.textContent = `❌ Lỗi: ${err.message}`;
    } finally {
      isGeneratingVideo = false;
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = `<i class="fa-solid fa-film"></i><span>🎬 Gửi Yêu Cầu Tạo Video</span>`;
      }
    }
  }

  // Khởi tạo khi DOM sẵn sàng
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      injectStudioIntoDOM();
      loadStudioState();
    });
  } else {
    injectStudioIntoDOM();
    loadStudioState();
  }
})();
