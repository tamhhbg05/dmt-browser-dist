﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;

[assembly: AssemblyTitle("DMT Browser")]
[assembly: AssemblyDescription("DMT Browser — Antidetect Browser Manager (Camoufox C++ Native Core)")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("DMT Browser")]
[assembly: AssemblyProduct("DMT Browser")]
[assembly: AssemblyCopyright("Copyright © 2026 DMT Browser")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

namespace DMTBrowserLauncher
{
    static class Program
    {
        [DllImport("shell32.dll", SetLastError = true)]
        static extern void SetCurrentProcessExplicitAppUserModelID([MarshalAs(UnmanagedType.LPWStr)] string AppID);

        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                SetCurrentProcessExplicitAppUserModelID("DMT.Browser.Desktop.App");
            }
            catch { }

            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            string mainPy = Path.Combine(baseDir, "main.py");
            if (!File.Exists(mainPy))
            {
                MessageBox.Show(
                    "Không tìm thấy file main.py trong thư mục ứng dụng:\n" + mainPy,
                    "DMT Browser — Lỗi khởi động",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
                return;
            }

            string pyExe = Path.Combine(baseDir, "runtime", "python", "python.exe");
            string pywExe = Path.Combine(baseDir, "runtime", "python", "pythonw.exe");
            string targetPython = File.Exists(pyExe) ? pyExe : (File.Exists(pywExe) ? pywExe : "python.exe");

            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = targetPython;
            psi.Arguments = "\"" + mainPy + "\"";
            psi.WorkingDirectory = baseDir;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.WindowStyle = ProcessWindowStyle.Hidden;

            string cacheDir = Path.Combine(baseDir, "runtime", "camoufox_cache");
            psi.EnvironmentVariables["CAMOUFOX_CACHE_DIR"] = cacheDir;
            psi.EnvironmentVariables["PYTHONUTF8"] = "1";
            psi.EnvironmentVariables["PYTHONIOENCODING"] = "utf-8";

            try
            {
                Process.Start(psi);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không thể khởi chạy DMT Browser:\n" + ex.Message,
                    "DMT Browser — Lỗi khởi động",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }
    }
}
