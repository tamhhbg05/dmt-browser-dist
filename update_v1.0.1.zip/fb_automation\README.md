# Thư Mục Script Auto Đăng Bài & Nuôi Nick FB (DMT Browser & GPMLogin)

Toàn bộ mã nguồn, giao diện Web (trong DMT Browser) và giao diện App rời (`run_app.bat`) đã được gom gọn 100% vào trong **duy nhất 1 thư mục `fb_automation` này**.

---

## 📦 Cách gửi bản cập nhật cho người khác

Khi bạn chỉnh sửa kịch bản, giao diện hoặc tính năng mới và muốn gửi cập nhật cho máy khác, **bạn chỉ cần nén và gửi duy nhất thư mục `fb_automation` này**:

1. **Trường hợp máy người nhận đã có DMT Browser:**
   - Giải nén và **chép đè (overwrite)** thư mục `fb_automation` vào trong thư mục `DMT Browser\fb_automation`.
   - *(Chỉ cần chạy 1 lần đầu tiên nếu máy người nhận là bản DMT Browser cũ chưa có tab Auto)*: Bấm đúp vào file `Cai_Dat_Vao_DMT_Browser.bat` trong thư mục `fb_automation`. Những lần cập nhật sau chỉ cần chép đè thư mục `fb_automation` là xong!
   - Cấu hình cá nhân và danh sách Profile đã chọn của người nhận được tự động bảo lưu tại `DMT Browser\profiles_data\fb_automation_config.json`, không sợ bị mất khi chép đè.

2. **Trường hợp muốn mở bằng cửa sổ App rời (CustomTkinter):**
   - Bấm đúp trực tiếp vào file `run_app.bat` ngay bên trong thư mục này.
   - Script sẽ tự động nhận diện Python Portable của `DMT Browser` (hoặc Python hệ thống) và hiển thị đầy đủ 2 tab: **🦊 Profile DMT Browser** và **🌐 Profile GPMLogin**.
