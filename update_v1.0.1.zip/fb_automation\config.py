import os

# ================= CẤU HÌNH HỆ THỐNG GPMLOGIN / DMT BROWSER =================
PROFILE_ENGINE = "DMT"
GPM_API_BASE = "http://127.0.0.1:9495/api/v1"
SKIP_PROXY_CHECK = True
MAX_THREADS = 5
PROFILE_FILE = "id_profile.txt"
USER_FILE = "user.txt"
CONTENT_OUTPUT_DIR = r"C:\Users\DMTam\Desktop\Auto_Create_Contents\output"
APP_THEME = "dark"

# ================= CẤU HÌNH BỐ CỤC MÀN HÌNH =================
ENABLE_WINDOW_LAYOUT = True
SCREEN_WIDTH = 2560
SCREEN_HEIGHT = 1440
WINDOW_SCALE = 0.60
WINDOW_WIDTH = 1100
WINDOW_HEIGHT = 900

# ================= CẤU HÌNH TƯƠNG TÁC (BƯỚC 1) =================
FEED_SCROLL_COUNT = 10
STORIES_TO_WATCH = 1
REELS_TO_WATCH = 6
REEL_LIKE_RATE = 0.05
RANDOM_FEED_LIKE_RATE = 0.25

# ================= CẤU HÌNH ĐĂNG BÀI VÀO CÁC NHÓM (BƯỚC 2) =================
MAX_GROUPS_TO_POST = 5
MAX_SHARE_GROUPS = 5

# ================= CẤU HÌNH TƯƠNG TÁC TRONG NHÓM (BƯỚC 3) =================
GROUP_SCROLL_COUNT = 6
MAX_GROUPS_TO_VISIT = 2

# ================= CẤU HÌNH HẸN GIỜ CHẠY LẠI =================
ENABLE_AUTO_REPEAT = False
REPEAT_DELAY_MINUTES = 30

# ================= CÁC BƯỚC THỰC HIỆN =================
ENABLE_NICK_PAGE_TWO_WAY = False
ENABLE_STEP1_INTERACT = True
ENABLE_STEP2_POST_AND_SHARE = True
ENABLE_STEP3_GROUP_INTERACT = True

# ================= CẤU HÌNH TƯƠNG TÁC BÀI VIẾT BẠN BÈ / USER MỤC TIÊU =================
USER_POST_REACT_RATE = 0.30       # 30% bài của user mục tiêu sẽ được thả cảm xúc (70% bỏ qua để tự nhiên)
USER_POST_LIKE_RATE = 0.70        # Trong 30% được thả: 70% chọn Like 👍
USER_POST_LOVE_RATE = 0.30        # Trong 30% được thả: 30% chọn Thả Tim ❤️
USER_POST_COMMENT_RATE = 0.05     # 5% bài của user mục tiêu sẽ được viết bình luận
USER_POST_COMMENT_TEXTS = [
    "Bài viết rất hay và ý nghĩa bạn ơi 👍",
    "Tuyệt vời quá ạ ❤️",
    "Chúc bạn ngày mới nhiều năng lượng và may mắn nhé!",
    "Rất hữu ích, cảm ơn bạn đã chia sẻ!",
    "Tương tác cùng nhau phát triển nhé bạn ơi 👍",
]

