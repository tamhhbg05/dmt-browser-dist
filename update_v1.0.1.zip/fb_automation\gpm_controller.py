import sys
import time
from typing import Optional, Callable
import requests
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
import os

if os.name == "nt":
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

DEFAULT_GPM_API_BASE = "http://127.0.0.1:9495/api/v1"


def _get_existing_chrome_hwnds() -> set:
    if os.name != "nt":
        return set()
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        hwnds = set()

        @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def enum_cb(hwnd, lparam):
            if user32.IsWindowVisible(hwnd):
                cls_buf = ctypes.create_unicode_buffer(256)
                user32.GetClassNameW(hwnd, cls_buf, 256)
                if "Chrome_WidgetWin_1" in cls_buf.value:
                    hwnds.add(hwnd)
            return True

        user32.EnumWindows(enum_cb, 0)
        return hwnds
    except Exception:
        return set()


def _position_new_chrome_window(
    known_hwnds: set,
    window_pos: Optional[str] = None,
    window_size: Optional[str] = None,
    profile_id: str = "",
) -> Optional[int]:
    """Tìm đúng HWND của cửa sổ Chrome vừa mở (không đè lên window cũ), định vị, resize và kéo nổi lên trên màn hình"""
    if os.name != "nt":
        return None
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32

        target_hwnd = None
        for _ in range(35):
            found = []

            @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
            def enum_cb(hwnd, lparam):
                if user32.IsWindowVisible(hwnd) and hwnd not in known_hwnds:
                    cls_buf = ctypes.create_unicode_buffer(256)
                    user32.GetClassNameW(hwnd, cls_buf, 256)
                    if "Chrome_WidgetWin_1" in cls_buf.value:
                        rect = wintypes.RECT()
                        user32.GetWindowRect(hwnd, ctypes.byref(rect))
                        win_w = rect.right - rect.left
                        win_h = rect.bottom - rect.top
                        if win_w > 200 and win_h > 200:
                            found.append(hwnd)
                return True

            user32.EnumWindows(enum_cb, 0)
            if found:
                target_hwnd = found[-1]
                break
            time.sleep(0.12)

        if target_hwnd:
            x, y = 50, 50
            w, h = 800, 600
            if window_pos:
                x, y = map(int, window_pos.split(","))
            if window_size:
                w, h = map(int, window_size.split(","))

            SW_RESTORE = 9
            user32.ShowWindow(target_hwnd, SW_RESTORE)

            # Ép kích thước, vị trí và đưa nổi lên trên cùng (HWND_TOP = 0)
            HWND_TOP = 0
            SWP_SHOWWINDOW = 0x0040
            user32.SetWindowPos(target_hwnd, HWND_TOP, x, y, w, h, SWP_SHOWWINDOW)

            # Kéo cửa sổ nổi lên foreground phía trên DMT Browser
            try:
                cur_thread = ctypes.windll.kernel32.GetCurrentThreadId()
                fore_thread = user32.GetWindowThreadProcessId(user32.GetForegroundWindow(), None)
                if cur_thread != fore_thread:
                    user32.AttachThreadInput(cur_thread, fore_thread, True)
                    user32.BringWindowToTop(target_hwnd)
                    user32.SetForegroundWindow(target_hwnd)
                    user32.AttachThreadInput(cur_thread, fore_thread, False)
                else:
                    user32.BringWindowToTop(target_hwnd)
                    user32.SetForegroundWindow(target_hwnd)
            except Exception:
                user32.BringWindowToTop(target_hwnd)
                user32.SetForegroundWindow(target_hwnd)

            return target_hwnd
    except Exception:
        pass
    return None


class GPMController:
    WINDOW_LOCK = None

    """Quản lý khởi động, kết nối WebDriver, định vị cửa sổ và đóng profile GPMLogin"""


    @staticmethod
    def check_connection(api_base: str = DEFAULT_GPM_API_BASE) -> dict:
        base = (api_base or DEFAULT_GPM_API_BASE).rstrip("/")
        try:
            r = requests.get(f"{base}/profiles", timeout=3)
            if r.status_code == 200:
                data = r.json() if r.content else {}
                profiles = data.get("data", []) if isinstance(data, dict) else []
                return {
                    "online": True,
                    "status_code": 200,
                    "profiles_count": len(profiles) if isinstance(profiles, list) else 0,
                    "profiles": profiles if isinstance(profiles, list) else [],
                }
            return {"online": False, "status_code": r.status_code, "error": f"HTTP {r.status_code}"}
        except Exception as e:
            return {"online": False, "status_code": 0, "error": str(e)}

    @staticmethod
    def start_profile(
        profile_id: str,
        api_base: str = DEFAULT_GPM_API_BASE,
        skip_proxy_check: bool = True,
        window_size: Optional[str] = None,
        window_scale: Optional[float] = None,
        **kwargs
    ) -> dict:
        base = (api_base or DEFAULT_GPM_API_BASE).rstrip("/")
        url = f"{base}/profiles/start/{profile_id}"
        params = {"skip_proxy_check": str(skip_proxy_check).lower()}

        if window_size:
            params["window_size"] = window_size
        if window_scale is not None:
            params["window_scale"] = str(window_scale)

        try:
            res = requests.get(url, params=params, timeout=45)
            json_data = res.json()
            if json_data.get("success"):
                return json_data.get("data", {})
            else:
                raise RuntimeError(f"{json_data.get('message')}")
        except Exception as e:
            raise RuntimeError(f"{e}")

    @staticmethod
    def stop_profile(profile_id: str, api_base: str = DEFAULT_GPM_API_BASE) -> bool:
        base = (api_base or DEFAULT_GPM_API_BASE).rstrip("/")
        url = f"{base}/profiles/stop/{profile_id}"
        try:
            res = requests.get(url, timeout=15)
            json_data = res.json()
            return bool(json_data.get("success"))
        except Exception:
            return False

    @classmethod
    def create_driver(
        cls,
        profile_id: str,
        api_base: str = DEFAULT_GPM_API_BASE,
        skip_proxy_check: bool = True,
        window_pos: Optional[str] = None,
        window_size: Optional[str] = None,
        window_scale: Optional[float] = None,
        max_retries: int = 3,
        retry_delay: int = 4,
        log_fn: Optional[Callable[[str], None]] = None,
    ) -> webdriver.Chrome:
        def _log(msg: str):
            if log_fn:
                log_fn(msg)
            else:
                print(msg, flush=True)

        try:
            max_retries = int(max_retries)
            if max_retries > 10:
                max_retries = 3
        except Exception:
            max_retries = 3

        if window_scale is not None:
            try:
                window_scale = float(window_scale)
                if window_scale > 5.0:
                    window_scale = window_scale / 100.0
                if not (0.25 <= window_scale <= 2.0):
                    window_scale = 0.60
            except Exception:
                window_scale = 0.60

        import threading
        if cls.WINDOW_LOCK is None:
            cls.WINDOW_LOCK = threading.Lock()

        last_error = None
        short_id = profile_id[:8]

        for attempt in range(1, max_retries + 1):
            try:
                if attempt > 1:
                    _log(f"[{short_id}] 🔄 Đang dừng và mở lại GPM profile lần {attempt}/{max_retries}...")
                    cls.stop_profile(profile_id, api_base=api_base)
                    time.sleep(2)

                data = None
                target_hwnd = None
                with cls.WINDOW_LOCK:
                    known_hwnds = _get_existing_chrome_hwnds()
                    # 1. Mở GPM Profile với GET /profiles/start/{id}?window_size={size}&window_scale={scale}
                    data = cls.start_profile(
                        profile_id,
                        api_base=api_base,
                        skip_proxy_check=skip_proxy_check,
                        window_size=window_size,
                        window_scale=window_scale
                    )
                    port = data.get("remote_debugging_port")
                    driver_path = data.get("driver_path")

                    if not port or not driver_path:
                        raise ValueError(f"Không nhận được port ({port}) hoặc driver_path ({driver_path}) từ GPMLogin!")

                    # 2. Xong đó sắp xếp profile: Định vị chuẩn tọa độ, kích thước và kéo nổi lên trên cùng màn hình
                    target_hwnd = _position_new_chrome_window(known_hwnds, window_pos, window_size, profile_id)

                time.sleep(1.8)

                options = Options()
                options.add_experimental_option("debuggerAddress", f"127.0.0.1:{port}")
                options.add_argument("--log-level=3")
                options.set_capability("unhandledPromptBehavior", "accept")

                service = Service(executable_path=driver_path)

                driver = None
                for conn_i in range(3):
                    try:
                        driver = webdriver.Chrome(service=service, options=options)
                        break
                    except Exception as ce:
                        if conn_i < 2:
                            time.sleep(1.5)
                        else:
                            raise ce

                cls._select_working_tab(driver)

                # 3. Đảm bảo sau khi Selenium kết nối, cửa sổ giữ nguyên vị trí sắp xếp và nổi lên trên cùng (không gọi driver.set_window_size để tránh double scale)
                if os.name == "nt":
                    try:
                        import ctypes
                        user32 = ctypes.windll.user32
                        x, y = (map(int, window_pos.split(","))) if window_pos else (0, 0)
                        w, h = (map(int, window_size.split(","))) if window_size else (800, 600)
                        if target_hwnd:
                            user32.ShowWindow(target_hwnd, 9)
                            user32.SetWindowPos(target_hwnd, 0, x, y, w, h, 0x0040)
                            user32.BringWindowToTop(target_hwnd)
                            user32.SetForegroundWindow(target_hwnd)
                        else:
                            _position_new_chrome_window(known_hwnds, window_pos, window_size, profile_id)
                    except Exception:
                        pass

                return driver


            except Exception as e:
                last_error = e
                _log(f"[{short_id}] ⚠️ Lỗi mở GPM profile/proxy: {e}")
                cls.stop_profile(profile_id, api_base=api_base)

                if attempt < max_retries:
                    _log(f"[{short_id}] ⏳ Đang đợi {retry_delay}s rồi mở lại...")
                    time.sleep(retry_delay)

        raise RuntimeError(f"Không thể mở GPM profile sau {max_retries} lần thử: {last_error}")

    @staticmethod
    def _select_working_tab(driver: webdriver.Chrome):
        handles = driver.window_handles
        target_handle = None

        for h in handles:
            try:
                driver.switch_to.window(h)
                url = driver.current_url
                if not url.startswith("chrome-extension://"):
                    target_handle = h
                    break
            except Exception:
                continue

        if not target_handle and handles:
            driver.switch_to.new_window("tab")

    @classmethod
    def safe_close(cls, driver: webdriver.Chrome, profile_id: str, api_base: str = DEFAULT_GPM_API_BASE):
        if driver:
            try:
                try:
                    alert = driver.switch_to.alert
                    alert.accept()
                except Exception:
                    pass

                try:
                    handles = driver.window_handles
                    for h in handles:
                        try:
                            driver.switch_to.window(h)
                            driver.execute_script("window.onbeforeunload = null;")
                        except Exception:
                            pass
                except Exception:
                    pass

                driver.quit()
            except Exception:
                pass

        time.sleep(1)
        cls.stop_profile(profile_id, api_base=api_base)
