"""
Script Test Độc Lập: Kiểm tra tính năng Tương Tác List User & Bình Luận Facebook
Dành riêng cho Profile GPMLogin: 1e516cb4-e482-459a-9278-1be14766a259
"""

import sys
import time
import json
from pathlib import Path

# Thêm thư mục hiện tại vào sys.path
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from gpm_controller import GPMController
from fb_bot import FacebookBot

TEST_PROFILE_ID = "1e516cb4-e482-459a-9278-1be14766a259"
GPM_API_BASE = "http://127.0.0.1:9495/api/v1"

def load_target_users() -> list[str]:
    # 1. Thử đọc từ config.json
    cfg_file = SCRIPT_DIR / "config.json"
    if cfg_file.exists():
        try:
            with open(cfg_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                users = data.get("target_users", [])
                if users:
                    return [u.strip() for u in users if u.strip()]
        except Exception:
            pass

    # 2. Thử đọc từ user.txt
    user_txt = SCRIPT_DIR / "user.txt"
    if user_txt.exists():
        try:
            with open(user_txt, "r", encoding="utf-8") as f:
                return [line.strip() for line in f if line.strip()]
        except Exception:
            pass

    return ["Phùng Dân", "Giang Hằng", "Cù Nhã", "Trương Nhiên"]

def main():
    print("=" * 70)
    print("   TEST TƯƠNG TÁC FEED (30% REACT: 70% LIKE / 30% TIM, 5% COMMENT)")
    print(f"   Profile GPM ID: {TEST_PROFILE_ID}")
    print("=" * 70)

    target_users = load_target_users()
    print(f"[*] Đã nạp {len(target_users)} người dùng mục tiêu cần tương tác:")
    print(f"    Mẫu: {', '.join(target_users[:5])}...")

    # 1. Kiểm tra kết nối tới GPM API
    print(f"\n[*] Đang kết nối tới GPM API tại {GPM_API_BASE}...")
    conn = GPMController.check_connection(api_base=GPM_API_BASE)
    if not conn.get("online"):
        print("[!] Không thể kết nối tới GPMLogin API. Vui lòng bật GPMLogin!")
        return
    print(f"[OK] Đã kết nối thành công tới GPM! (Đang quản lý {conn.get('profiles_count')} profiles)")

    # 2. Khởi động Profile GPM
    print(f"\n[*] Đang mở Profile GPM [{TEST_PROFILE_ID}]...")
    driver = None
    try:
        driver = GPMController.create_driver(
            profile_id=TEST_PROFILE_ID,
            api_base=GPM_API_BASE,
            window_size="1200,900",
            window_scale=0.75,
            skip_proxy_check=False
        )
        print("[OK] Đã mở trình duyệt Chrome GPM thành công!")

        # 3. Khởi tạo FacebookBot với cấu hình mới
        bot = FacebookBot(
            driver=driver,
            profile_id=TEST_PROFILE_ID,
            target_users=target_users,
            profile_label="GPM-TEST",
            react_rate=0.30,      # 30% React bài viết
            like_rate=0.70,       # 70% Like / 30% Tim
            comment_rate=0.05,    # 5% Comment
            comment_texts=[
                "Bài viết rất hay và ý nghĩa bạn ơi 👍",
                "Tuyệt vời quá ạ ❤️",
                "Chúc bạn ngày mới nhiều năng lượng và may mắn nhé!",
                "Rất hữu ích, cảm ơn bạn đã chia sẻ!",
                "Tương tác cùng nhau phát triển nhé bạn ơi 👍"
            ]
        )

        # 4. Mở Facebook
        print("\n[*] Điều hướng đến Facebook...")
        driver.get("https://www.facebook.com/")
        time.sleep(3.5)

        # 5. Chạy quét tương tác lướt feed
        print("\n[*] Bắt đầu lướt Feed và quét bài viết mục tiêu...")
        bot.run_step1_interact(feed_scroll_count=8, stories_count=0, reels_count=0)

        print("\n" + "=" * 70)
        print("   [HOÀN THÀNH TEST] Quá trình tương tác đã kết thúc thành công!")
        print("=" * 70)

    except KeyboardInterrupt:
        print("\n[!] Đã dừng script theo lệnh người dùng (Ctrl+C).")
    except Exception as e:
        print(f"\n[X] Có lỗi xảy ra trong quá trình test: {e}")
    finally:
        if driver:
            choice = input("\nBạn có muốn đóng profile GPM này lại không? (y/n, mặc định y): ").strip().lower()
            if choice != "n":
                print("[*] Đang đóng profile GPM...")
                try:
                    gpm.stop_profile(TEST_PROFILE_ID)
                except Exception:
                    pass
                print("[OK] Đã đóng profile.")

if __name__ == "__main__":
    main()
