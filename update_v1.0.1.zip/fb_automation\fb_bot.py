import os
import re
import time
import random
import threading
import unicodedata
from typing import List, Set, Optional, Tuple, Callable, Any, Dict
import pyperclip
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains

try:
    from .content_generator import ContentGenerator
except ImportError:
    from content_generator import ContentGenerator

CLIPBOARD_LOCK = threading.Lock()


def _remove_accents(input_str: str) -> str:
    """Chuẩn hóa chuỗi tiếng Việt không dấu để hỗ trợ so khớp tên người đăng linh hoạt"""
    if not input_str:
        return ""
    s = unicodedata.normalize("NFC", input_str).replace("đ", "d").replace("Đ", "D")
    nfkd_form = unicodedata.normalize("NFKD", s)
    return "".join([c for c in nfkd_form if not unicodedata.combining(c)])


def _normalize_name(name: str) -> str:
    """Làm sạch khoảng trắng thừa, chuẩn hóa Unicode NFC và đưa về chữ thường"""
    if not name:
        return ""
    cleaned = " ".join(name.replace("\u200b", "").replace("\ufeff", "").replace("\xa0", " ").strip().split())
    return unicodedata.normalize("NFC", cleaned).casefold()


class FacebookBot:
    """Điều khiển tự động hóa các hành động trên Facebook cho cả Profile DMT Browser (Camoufox) và Profile GPMLogin"""

    def __init__(
        self,
        driver: Any,
        profile_id: str,
        target_users: List[str],
        profile_label: Optional[str] = None,
        log_fn: Optional[Callable[[str], None]] = None,
        stop_event: Optional[threading.Event] = None,
        react_rate: float = 0.30,
        like_rate: float = 0.70,
        comment_rate: float = 0.05,
        comment_texts: Optional[List[str]] = None,
    ):
        self.driver = driver
        self.profile_id = profile_id
        self.profile_label = profile_label or profile_id[:8]
        self.target_users: List[str] = list(dict.fromkeys([u.strip() for u in target_users if u.strip()]))
        self.reacted_posts: Set[str] = set()
        self.seen_authors_log: Set[str] = set()
        self.my_uid: Optional[str] = None
        self.my_display_name: Optional[str] = None
        self.log_fn = log_fn
        self.stop_event = stop_event
        self.is_playwright = bool(getattr(driver, "is_playwright", False))

        self.react_rate = float(react_rate)
        self.like_rate = float(like_rate)
        self.comment_rate = float(comment_rate)
        self.comment_texts = comment_texts if (comment_texts and len(comment_texts) > 0) else [
            "Bài viết rất hay và ý nghĩa bạn ơi 👍",
            "Tuyệt vời quá ạ ❤️",
            "Chúc bạn ngày mới nhiều năng lượng và may mắn nhé!",
            "Rất hữu ích, cảm ơn bạn đã chia sẻ!",
            "Tương tác cùng nhau phát triển nhé bạn ơi 👍",
        ]

        palette = ["#FF3B30", "#34C759", "#FF9500", "#007AFF", "#AF52DE", "#FF2D55", "#5AC8FA"]
        color_idx = abs(hash(profile_id)) % len(palette)
        self.cursor_color = palette[color_idx]

    def _should_stop(self) -> bool:
        return bool(self.stop_event and self.stop_event.is_set())

    def log(self, message: str):
        line = f"[{time.strftime('%H:%M:%S')}][{self.profile_label}] {message}"
        if self.log_fn:
            self.log_fn(line)
        else:
            print(line, flush=True)

    def dismiss_alerts(self):
        """Tắt onbeforeunload và chấp nhận bất kỳ alert nào (như 'Leave site?') đang chặn"""
        try:
            self.driver.execute_script("window.onbeforeunload = null;")
        except Exception:
            pass
        if not self.is_playwright:
            try:
                alert = self.driver.switch_to.alert
                alert.accept()
            except Exception:
                pass

    # =========================================================================
    # HÀM HỖ TRỢ: CON CHUỘT ẢO TRỰC QUAN (VIRTUAL CURSOR OVERLAY)
    # =========================================================================

    def _inject_virtual_cursor(self):
        """Nhúng con trỏ chuột ảo mô phỏng người thật (quỹ đạo Bézier cong, easing phi tuyến, rung lắc tự nhiên)"""
        try:
            self.driver.execute_script(f"""
                if (window.__humanCursorInjected && document.getElementById('human-cursor-wrapper')) return;
                window.__humanCursorInjected = true;

                const color = '{self.cursor_color}';
                let style = document.getElementById('human-cursor-style');
                if (!style) {{
                    style = document.createElement('style');
                    style.id = 'human-cursor-style';
                    document.head.appendChild(style);
                }}
                style.innerHTML = `
                    #human-cursor-wrapper {{
                        position: fixed;
                        top: 0;
                        left: 0;
                        width: 24px;
                        height: 24px;
                        z-index: 2147483647;
                        pointer-events: none;
                        transform: translate(160px, 160px);
                        will-change: transform;
                    }}
                    .human-cursor-svg {{
                        transform-origin: 0 0;
                        filter: drop-shadow(0 2px 5px rgba(0,0,0,0.65));
                        transition: transform 0.08s ease;
                    }}
                    .human-cursor-svg.clicking {{
                        transform: scale(0.88) translate(1px, 1px);
                    }}
                    .human-ripple {{
                        position: absolute;
                        top: -6px;
                        left: -6px;
                        width: 32px;
                        height: 32px;
                        border-radius: 50%;
                        background: ${{color}};
                        opacity: 0.85;
                        pointer-events: none;
                        animation: human-pop 0.55s cubic-bezier(0, 0, 0.2, 1) forwards;
                    }}
                    @keyframes human-pop {{
                        0% {{ transform: scale(0.2); opacity: 0.9; }}
                        100% {{ transform: scale(2.8); opacity: 0; }}
                    }}
                `;

                let wrapper = document.getElementById('human-cursor-wrapper');
                if (!wrapper) {{
                    wrapper = document.createElement('div');
                    wrapper.id = 'human-cursor-wrapper';
                    wrapper.innerHTML = `
                        <svg class="human-cursor-svg" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M4.5 2.5L18.5 12.2C19.3 12.8 18.9 14.1 17.9 14.2L12.7 14.6L16 20.7C16.4 21.4 15.6 22.2 14.8 21.7L12.1 20L8.9 14.1L5.8 17.4C5.1 18.1 3.9 17.6 3.9 16.6L3.9 3.8C3.9 2.8 4.9 2.3 4.5 2.5Z" 
                                  fill="${{color}}" stroke="#FFFFFF" stroke-width="1.8" stroke-linejoin="round"/>
                            <circle cx="8" cy="8" r="2.2" fill="#FFFFFF"/>
                        </svg>
                    `;
                    document.body.appendChild(wrapper);
                }}

                if (typeof window.__cursorX === 'undefined') {{
                    window.__cursorX = 160;
                    window.__cursorY = 160;
                }}

                window.__humanMoveTo = function(targetX, targetY, durationMs, onComplete) {{
                    const w = document.getElementById('human-cursor-wrapper');
                    if (!w) return;
                    const startX = window.__cursorX;
                    const startY = window.__cursorY;
                    const dist = Math.hypot(targetX - startX, targetY - startY);

                    if (dist < 4) {{
                        window.__cursorX = targetX;
                        window.__cursorY = targetY;
                        w.style.transform = `translate(${{targetX}}px, ${{targetY}}px)`;
                        if (onComplete) onComplete();
                        return;
                    }}

                    const midX = (startX + targetX) / 2;
                    const midY = (startY + targetY) / 2;
                    const perpX = -(targetY - startY);
                    const perpY = targetX - startX;
                    const len = Math.hypot(perpX, perpY) || 1;
                    const curvature = (Math.random() * 0.32 - 0.16) * Math.min(dist, 260);
                    const cpX = midX + (perpX / len) * curvature;
                    const cpY = midY + (perpY / len) * curvature;

                    const startTime = performance.now();
                    const duration = durationMs || Math.min(750, Math.max(250, dist * 0.82));

                    function easeOutQuart(x) {{
                        return 1 - Math.pow(1 - x, 4);
                    }}

                    function step(now) {{
                        const elapsed = now - startTime;
                        let t = Math.min(1, elapsed / duration);
                        let easeT = easeOutQuart(t);
                        const jitter = (t < 0.95) ? (Math.random() - 0.5) * 1.2 : 0;

                        const oneMinusT = 1 - easeT;
                        let curX = oneMinusT * oneMinusT * startX + 2 * oneMinusT * easeT * cpX + easeT * easeT * targetX + jitter;
                        let curY = oneMinusT * oneMinusT * startY + 2 * oneMinusT * easeT * cpY + easeT * easeT * targetY + jitter;

                        window.__cursorX = curX;
                        window.__cursorY = curY;
                        w.style.transform = `translate(${{curX}}px, ${{curY}}px)`;

                        if (t < 1) {{
                            requestAnimationFrame(step);
                        }} else {{
                            window.__cursorX = targetX;
                            window.__cursorY = targetY;
                            w.style.transform = `translate(${{targetX}}px, ${{targetY}}px)`;
                            if (onComplete) onComplete();
                        }}
                    }}

                    requestAnimationFrame(step);
                }};

                window.__humanClickAt = function(targetX, targetY, callback) {{
                    window.__humanMoveTo(targetX, targetY, null, () => {{
                        const w = document.getElementById('human-cursor-wrapper');
                        if (!w) return;
                        const svg = w.querySelector('.human-cursor-svg');
                        if (svg) svg.classList.add('clicking');
                        const r = document.createElement('div');
                        r.className = 'human-ripple';
                        w.appendChild(r);
                        setTimeout(() => r.remove(), 600);
                        setTimeout(() => {{
                            if (svg) svg.classList.remove('clicking');
                            if (callback) callback();
                        }}, 140);
                    }});
                }};
            """)
        except Exception:
            pass

    def _move_cursor_to_element(self, element, click: bool = False):
        try:
            self._inject_virtual_cursor()
            dist = self.driver.execute_script("""
                const el = arguments[0];
                const click = arguments[1];
                if (!el) return 0;
                const rect = el.getBoundingClientRect();
                const x = Math.max(10, Math.min(window.innerWidth - 30, rect.left + rect.width / 2 + (Math.random() * 8 - 4)));
                const y = Math.max(10, Math.min(window.innerHeight - 30, rect.top + rect.height / 2 + (Math.random() * 8 - 4)));
                if (click && window.__humanClickAt) {
                    window.__humanClickAt(x, y);
                } else if (window.__humanMoveTo) {
                    window.__humanMoveTo(x, y);
                }
                return Math.hypot(x - (window.__cursorX || 0), y - (window.__cursorY || 0));
            """, element, click)
            move_delay = min(0.65, max(0.25, (dist or 100) * 0.00085))
            time.sleep(move_delay + (0.15 if click else 0.05))
        except Exception:
            pass

    def _click_element_with_cursor(self, element):
        try:
            self._move_cursor_to_element(element, click=True)
            time.sleep(0.12)
            clicked = False
            if self.is_playwright and hasattr(element, "_handle"):
                try:
                    element._handle.click(timeout=3000)
                    clicked = True
                except Exception:
                    pass
            elif not self.is_playwright:
                try:
                    ActionChains(self.driver).move_to_element(element).pause(0.1).click().perform()
                    clicked = True
                except Exception:
                    try:
                        element.click()
                        clicked = True
                    except Exception:
                        pass
            if not clicked:
                self.driver.execute_script("""
                    const el = arguments[0];
                    if (!el) return;
                    const r = el.getBoundingClientRect();
                    const cx = r.left + r.width / 2;
                    const cy = r.top + r.height / 2;
                    const opts = {bubbles: true, cancelable: true, clientX: cx, clientY: cy, pointerId: 1, pointerType: 'mouse', isPrimary: true, button: 0, buttons: 1};
                    try {
                        el.dispatchEvent(new PointerEvent('pointerdown', opts));
                        el.dispatchEvent(new MouseEvent('mousedown', opts));
                        el.dispatchEvent(new PointerEvent('pointerup', opts));
                        el.dispatchEvent(new MouseEvent('mouseup', opts));
                        el.click();
                    } catch (e) {
                        try { el.click(); } catch (e2) {}
                    }
                """, element)
        except Exception:
            try:
                element.click()
            except Exception:
                pass

    def smooth_scroll(self, distance: int, steps: Optional[int] = None):
        self._inject_virtual_cursor()
        if steps is None:
            steps = max(6, int(abs(distance) / 45))
        step_dist = distance / steps
        for i in range(steps):
            if self._should_stop():
                break
            jitter = step_dist * random.uniform(0.85, 1.15)
            self.driver.execute_script(f"window.scrollBy(0, {jitter});")
            if i % 3 == 0:
                self.driver.execute_script("""
                    if (window.__humanMoveTo && typeof window.__cursorX !== 'undefined') {
                        const targetX = window.__cursorX + (Math.random() * 8 - 4);
                        const targetY = window.__cursorY + (Math.random() * 8 - 4);
                        window.__humanMoveTo(targetX, targetY, 140);
                    }
                """)
            time.sleep(random.uniform(0.035, 0.075))

    # =========================================================================
    # QUY TRÌNH TƯƠNG TÁC 2 CHIỀU NICK ⇄ PAGE (ACCOUNTS CENTER & SWITCH PAGE)
    # =========================================================================

    def _goto_url(self, url: str, timeout_sec: float = 60.0):
        """Mở URL với timeout tối đa 60s, hỗ trợ cả Playwright (DMT Browser) và Selenium (GPMLogin)"""
        self.dismiss_alerts()
        if not self.is_playwright and hasattr(self.driver, "set_page_load_timeout"):
            try:
                self.driver.set_page_load_timeout(timeout_sec)
            except Exception:
                pass
        try:
            if self.is_playwright:
                self.driver.get(url, timeout_ms=int(timeout_sec * 1000))
            else:
                self.driver.get(url)
        except Exception as e:
            self.log(f"   ⚠️ Cảnh báo tải trang ({url}): {e}")
        self._inject_virtual_cursor()

    def _find_first_xpath(self, xpath: str) -> Optional[Any]:
        """Tìm phần tử đầu tiên khớp XPath (ưu tiên phần tử đang hiển thị trên màn hình)"""
        try:
            elems = self.driver.find_elements(By.XPATH, xpath)
            if not elems:
                return None
            for el in elems:
                try:
                    if el.is_displayed():
                        return el
                except Exception:
                    continue
            return elems[0]
        except Exception:
            return None

    def _has_xpath(self, xpath: str) -> bool:
        """Kiểm tra phần tử XPath có tồn tại trên trang hay không (hasElement)"""
        return self._find_first_xpath(xpath) is not None

    def _wait_xpath(self, xpath: str, timeout_sec: float = 4.0) -> Optional[Any]:
        """Đợi phần tử XPath xuất hiện trong khoảng thời gian tối đa timeout_sec (Wait element)"""
        deadline = time.time() + max(0.2, timeout_sec)
        while time.time() < deadline:
            if self._should_stop():
                return None
            el = self._find_first_xpath(xpath)
            if el is not None:
                return el
            time.sleep(0.35)
        return self._find_first_xpath(xpath)

    def _click_xpath(self, xpath: str, continue_on_error: bool = True, timeout_sec: float = 2.5) -> bool:
        """Tìm và click chuột thật (Mouse click) vào phần tử theo XPath (hỗ trợ continue_on_error: true/false)"""
        el = self._wait_xpath(xpath, timeout_sec=timeout_sec)
        if el is None:
            if not continue_on_error:
                raise RuntimeError(f"Không tìm thấy phần tử bắt buộc để click: {xpath}")
            self.log(f"   ℹ️ Bỏ qua click (không tìm thấy phần tử): {xpath}")
            return False

        try:
            try:
                self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", el)
                time.sleep(0.2)
            except Exception:
                pass
            self._move_cursor_to_element(el, click=True)
            time.sleep(0.1)

            clicked = False
            try:
                el.click()
                clicked = True
            except Exception:
                if not self.is_playwright:
                    try:
                        ActionChains(self.driver).move_to_element(el).pause(0.1).click().perform()
                        clicked = True
                    except Exception:
                        pass

            if not clicked:
                self.driver.execute_script("""
                    const el = arguments[0];
                    if (!el) return;
                    const r = el.getBoundingClientRect();
                    const cx = r.left + r.width / 2;
                    const cy = r.top + r.height / 2;
                    const opts = {bubbles: true, cancelable: true, clientX: cx, clientY: cy, button: 0, buttons: 1};
                    el.dispatchEvent(new PointerEvent('pointerdown', opts));
                    el.dispatchEvent(new MouseEvent('mousedown', opts));
                    el.dispatchEvent(new PointerEvent('pointerup', opts));
                    el.dispatchEvent(new MouseEvent('mouseup', opts));
                    el.click();
                """, el)
            return True
        except Exception as e:
            if not continue_on_error:
                raise RuntimeError(f"Lỗi khi click phần tử {xpath}: {e}")
            self.log(f"   ⚠️ Không thể click {xpath} (continue_on_error=True): {e}")
            return False

    def check_accounts_center_on_open(self, note: bool = False) -> bool:
        """
        Bước 1 trong quy trình 'Tương tác 2 chiều nick-page' khi vừa mở profile (Chuyển về Nick chính):
        - Go to URL: Mở https://accountscenter.facebook.com/?entry_point=app_settings (timeout 60s, nghỉ 5–8s).
        - If hasElement(//input[@type="submit"]) && $note=False:
            Mouse click: Click vào //input[@type="submit"] (continue_on_error: false, nghỉ 10–15s) để chuyển từ Page về Nick.
        """
        if self._should_stop():
            return False

        self.log("🔄 [Nick ⇄ Page] Bước 1: Mở Accounts Center để chuyển về Nick chính...")
        self._goto_url("https://accountscenter.facebook.com/?entry_point=app_settings", timeout_sec=60.0)
        sleep_open = random.uniform(5.0, 8.0)
        self.log(f"   ⏳ Đang đợi tải trang Accounts Center ({sleep_open:.1f}s)...")
        time.sleep(sleep_open)

        if self._should_stop():
            return False

        submit_xpath = '//input[@type="submit"]'
        if self._has_xpath(submit_xpath) and not note:
            self.log('   🖱️ Phát hiện //input[@type="submit"] (đang ở Page) -> Click chuyển về Nick chính (continue_on_error=False)...')
            self._click_xpath(submit_xpath, continue_on_error=False, timeout_sec=5.0)
            sleep_after = random.uniform(10.0, 15.0)
            self.log(f"   ⏳ Đã click chuyển về Nick, nghỉ {sleep_after:.1f}s...")
            time.sleep(sleep_after)
            self.my_display_name = None
            self.reacted_posts.clear()
            self.seen_authors_log.clear()
            self.log("   ✅ Đã chuyển về Nick chính thành công!")
            return True

        self.my_display_name = None
        self.reacted_posts.clear()
        self.seen_authors_log.clear()
        self.log("   ✅ Tài khoản hiện đã ở giao diện Nick chính, sẵn sàng tương tác Nick!")
        return False

    def switch_to_page(self) -> bool:
        """
        Bước 3 trong quy trình 'Tương tác 2 chiều nick-page': Chuyển từ Nick sang Page để tương tác.
        Vòng lặp For (0 -> 3, bước nhảy 1):
        - Mở https://www.facebook.com/pages/?category=your_pages&ref=bookmarks (timeout 60s, nghỉ 3–4s).
        - Đợi //*[text()='Khám phá'] tối đa 4s (nghỉ 1–2s).
        - If hasElement(//*[text()='Khám phá']):
            + Đợi //div[@aria-label="Xem thêm"] tối đa 3s (nghỉ 2–3s).
            + Click //div[@aria-label="Xem thêm"] (continue_on_error: true, nghỉ 3–5s).
            + Click //span[text()='Chuyển ngay'] (continue_on_error: true, nghỉ 4–6s).
            + Click //span[text()='Chuyển'] (continue_on_error: true, nghỉ 10–12s).
        - Mở https://www.facebook.com/me (timeout 60s, nghỉ 5–8s).
        - Đợi //div[@aria-label="Hiển thị menu" or @aria-label="Ẩn menu"] tối đa 5s (nghỉ 1–3s).
        - If hasElement(//div[@aria-label="Hiển thị menu" or @aria-label="Ẩn menu"]) -> Exit loop (break).
        """
        self.log("🔄 [Nick ⇄ Page] Bắt đầu quy trình chuyển từ Nick sang Page (tối đa 4 lần thử: 0 -> 3)...")

        kham_pha_xpath = "//*[text()='Khám phá']"
        xem_them_xpath = '//div[@aria-label="Xem thêm"]'
        chuyen_ngay_xpath = "//span[text()='Chuyển ngay']"
        chuyen_xpath = "//span[text()='Chuyển']"
        page_menu_xpath = '//div[@aria-label="Hiển thị menu" or @aria-label="Ẩn menu"]'

        for attempt in range(0, 4, 1):
            if self._should_stop():
                return False

            self.log(f"   🔁 [Vòng lặp chuyển Page {attempt}/3] Mở danh sách trang của bạn...")
            self._goto_url("https://www.facebook.com/pages/?category=your_pages&ref=bookmarks", timeout_sec=60.0)
            time.sleep(random.uniform(3.0, 4.0))

            if self._should_stop():
                return False

            # Đợi //*[text()='Khám phá'] tối đa 4s (nghỉ 1–2s)
            self._wait_xpath(kham_pha_xpath, timeout_sec=4.0)
            time.sleep(random.uniform(1.0, 2.0))

            # If hasElement(//*[text()='Khám phá'])
            if self._has_xpath(kham_pha_xpath):
                self.log("   🔎 Phát hiện 'Khám phá' (đang ở giao diện Nick), tiến hành thao tác chuyển sang Page...")

                # Đợi //div[@aria-label="Xem thêm"] tối đa 3s (nghỉ 2–3s)
                self._wait_xpath(xem_them_xpath, timeout_sec=3.0)
                time.sleep(random.uniform(2.0, 3.0))

                # Click //div[@aria-label="Xem thêm"] (continue_on_error: true, nghỉ 3–5s)
                if self._click_xpath(xem_them_xpath, continue_on_error=True, timeout_sec=2.0):
                    self.log('   🖱️ Đã click //div[@aria-label="Xem thêm"], nghỉ 3–5s...')
                time.sleep(random.uniform(3.0, 5.0))

                # Click //span[text()='Chuyển ngay'] (continue_on_error: true, nghỉ 4–6s)
                if self._click_xpath(chuyen_ngay_xpath, continue_on_error=True, timeout_sec=2.5):
                    self.log("   🖱️ Đã click //span[text()='Chuyển ngay'], nghỉ 4–6s...")
                time.sleep(random.uniform(4.0, 6.0))

                # Click //span[text()='Chuyển'] (continue_on_error: true, nghỉ 10–12s)
                if self._click_xpath(chuyen_xpath, continue_on_error=True, timeout_sec=2.5):
                    self.log("   🖱️ Đã click //span[text()='Chuyển'], nghỉ 10–12s chờ đổi sang Page...")
                time.sleep(random.uniform(10.0, 12.0))

            if self._should_stop():
                return False

            # Mở https://www.facebook.com/me (timeout 60s, nghỉ 5–8s)
            self.log("   🌐 Mở https://www.facebook.com/me để kiểm tra giao diện Page...")
            self._goto_url("https://www.facebook.com/me", timeout_sec=60.0)
            time.sleep(random.uniform(5.0, 8.0))

            # Đợi //div[@aria-label="Hiển thị menu" or @aria-label="Ẩn menu"] tối đa 5s (nghỉ 1–3s)
            self._wait_xpath(page_menu_xpath, timeout_sec=5.0)
            time.sleep(random.uniform(1.0, 3.0))

            # If hasElement(//div[@aria-label="Hiển thị menu" or @aria-label="Ẩn menu"]) -> Exit loop (break)
            if self._has_xpath(page_menu_xpath):
                # Reset thông tin tên hiển thị & danh sách bài đã tương tác của phiên Nick
                # để Page nhận diện tên mới và thả Tim/Like độc lập với Nick
                self.my_display_name = None
                self.reacted_posts.clear()
                self.seen_authors_log.clear()
                self.log(f"✅ [Nick ⇄ Page] Đã chuyển sang Page thành công (phát hiện menu quản lý Page ở lần thử {attempt}/3)!")
                return True

            self.log(f"   ⚠️ Chưa thấy menu Page sau lần thử {attempt}/3, tiếp tục vòng lặp...")

        # Ngay cả khi hết vòng lặp, vẫn reset bộ nhớ bài viết để lượt tương tác tiếp theo hoạt động sạch sẽ
        self.my_display_name = None
        self.reacted_posts.clear()
        self.seen_authors_log.clear()
        self.log("⚠️ [Nick ⇄ Page] Kết thúc 4 vòng lặp chuyển Page (0 -> 3).")
        return False

    # =========================================================================
    # BƯỚC 1: TƯƠNG TÁC LƯỚT FEED, REELS, STORY
    # =========================================================================

    def run_step1_interact(self, feed_scroll_count: int = 10, stories_count: int = 1, reels_count: int = 6):
        self.log("🚀 Bắt đầu BƯỚC 1: Tương tác tự nhiên & ngẫu nhiên hóa hành vi người dùng...")
        self.dismiss_alerts()
        self._inject_virtual_cursor()

        routine_type = random.choice([1, 2, 3, 4])
        actual_reels = random.randint(max(3, reels_count - 2), reels_count + 2)
        actual_feed_scrolls = random.randint(max(6, feed_scroll_count - 3), feed_scroll_count + 4)

        if routine_type == 1:
            self.log(f"🎲 [Kịch bản 1] Khởi động lướt Feed dạo ➔ Xem {actual_reels} Reels ➔ Lướt Feed sâu tìm bài Target...")
            self.interact_feed(scroll_count=random.randint(3, 5))
            if self._should_stop():
                return
            time.sleep(random.uniform(2.0, 3.5))
            self.interact_reels(count=actual_reels)
            if self._should_stop():
                return
            time.sleep(random.uniform(2.5, 4.0))
            self.interact_feed(scroll_count=actual_feed_scrolls)

        elif routine_type == 2:
            self.log(f"🎲 [Kịch bản 2] Xem {actual_reels} Reels trước ➔ Lướt News Feed ➔ Xem Story...")
            self.interact_reels(count=actual_reels)
            if self._should_stop():
                return
            time.sleep(random.uniform(2.5, 4.0))
            self.interact_feed(scroll_count=actual_feed_scrolls)
            if self._should_stop():
                return
            time.sleep(random.uniform(2.0, 3.5))
            if random.random() < 0.7:
                self.interact_stories(count=stories_count)

        elif routine_type == 3:
            self.log(f"🎲 [Kịch bản 3] Xem Story trước ➔ Lướt News Feed ➔ Xem {actual_reels} Reels...")
            self.interact_stories(count=stories_count)
            if self._should_stop():
                return
            time.sleep(random.uniform(2.0, 3.5))
            self.interact_feed(scroll_count=actual_feed_scrolls)
            if self._should_stop():
                return
            time.sleep(random.uniform(2.0, 4.0))
            self.interact_reels(count=actual_reels)

        else:
            self.log(f"🎲 [Kịch bản 4] Tập trung lướt News Feed sâu ➔ Xem nhẹ {max(3, actual_reels - 2)} Reels...")
            self.interact_feed(scroll_count=actual_feed_scrolls + 3)
            if self._should_stop():
                return
            time.sleep(random.uniform(2.5, 4.0))
            self.interact_reels(count=max(3, actual_reels - 2))

        self.log("✅ Hoàn thành BƯỚC 1 với trải nghiệm hành vi người dùng tự nhiên!")

    def interact_stories(self, count: int = 1):
        self.log("📖 Bắt đầu xem Stories...")
        self.dismiss_alerts()
        self.driver.get("https://www.facebook.com/")
        time.sleep(4)

        story_elements = self.driver.find_elements(
            By.XPATH,
            '//div[@aria-label="khay tin"]//a[contains(@aria-label, "Tin của")] | '
            '//div[contains(@aria-label, "Tin") or contains(@aria-label, "Stories")]//div[@role="button"]'
        )

        clicked = False
        for elem in story_elements:
            try:
                text = elem.text.lower()
                if "tạo tin" in text or "create story" in text:
                    continue
                self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", elem)
                time.sleep(0.8)
                self._click_element_with_cursor(elem)
                clicked = True
                break
            except Exception:
                continue

        if not clicked:
            self.log("ℹ️ Không tìm thấy Story trên trang chủ.")
            return

        self.log("👀 Đang xem Story đầu tiên (5-7s)...")
        time.sleep(random.uniform(5.0, 7.5))

        next_cards = self.driver.find_elements(
            By.XPATH,
            '//div[@aria-label="Thẻ tiếp theo" or @aria-label="Next card"]'
        )
        if next_cards:
            try:
                self._click_element_with_cursor(next_cards[0])
                self.log("   ➡️ Đã chuyển sang Thẻ tiếp theo...")
                time.sleep(random.uniform(4.0, 6.0))
            except Exception:
                pass

        next_buckets = self.driver.find_elements(
            By.XPATH,
            '//div[@aria-label="Nhóm tiếp theo" or @aria-label="Next story"]'
        )
        if next_buckets:
            try:
                self._click_element_with_cursor(next_buckets[0])
                self.log("   ⏩ Đã chuyển sang Story của người kế tiếp...")
                time.sleep(random.uniform(3.5, 5.0))
            except Exception:
                pass

        try:
            close_btns = self.driver.find_elements(
                By.XPATH,
                '//div[@aria-label="Đóng" or @aria-label="Close"]'
            )
            if close_btns:
                self._click_element_with_cursor(close_btns[0])
            else:
                self.driver.find_element(By.TAG_NAME, "body").send_keys(Keys.ESCAPE)
            time.sleep(2)
        except Exception:
            pass

    def interact_reels(self, count: int = 6):
        self.log(f"🎬 Bắt đầu xem {count} Reels liên tiếp...")
        self.dismiss_alerts()
        self.driver.get("https://www.facebook.com/reel/")
        time.sleep(4)

        for idx in range(count):
            if self._should_stop():
                break
            watch_time = random.uniform(3.5, 8.5)
            self.log(f"👀 Đang xem Reel {idx + 1}/{count} trong {watch_time:.1f}s...")
            time.sleep(watch_time)

            scrolled = False
            try:
                next_btns = self.driver.find_elements(
                    By.XPATH,
                    '//div[@aria-label="Thước phim tiếp theo" or @aria-label="Thẻ tiếp theo" or @aria-label="Video tiếp theo" or @aria-label="Tiếp theo" or @aria-label="Next card" or @aria-label="Next video" or @aria-label="Next"]'
                )
                for nb in next_btns:
                    if nb.is_displayed():
                        self._click_element_with_cursor(nb)
                        scrolled = True
                        break
            except Exception:
                pass

            if not scrolled:
                try:
                    if self.is_playwright:
                        self.driver.page.keyboard.press("ArrowDown")
                        time.sleep(0.3)
                        self.driver.page.keyboard.press("PageDown")
                        scrolled = True
                    else:
                        main_el = self.driver.find_elements(By.XPATH, '//div[@role="main"]//video | //div[@role="main"] | //body')
                        if main_el:
                            ActionChains(self.driver).move_to_element(main_el[0]).click().send_keys(Keys.ARROW_DOWN).perform()
                            time.sleep(0.3)
                            ActionChains(self.driver).send_keys(Keys.PAGE_DOWN).perform()
                            scrolled = True
                except Exception:
                    pass

            try:
                self.driver.execute_script("""
                    const target = document.querySelector('div[role="main"]') || document.body;
                    target.dispatchEvent(new WheelEvent('wheel', {deltaY: 1000, bubbles: true}));
                    window.scrollBy({top: window.innerHeight, behavior: 'smooth'});
                """)
            except Exception:
                pass

            time.sleep(1.5)

        try:
            close_btns = self.driver.find_elements(
                By.XPATH,
                '//div[@aria-label="Đóng" or @aria-label="Close"]'
            )
            if close_btns:
                self.driver.execute_script("arguments[0].click();", close_btns[0])
            else:
                self.driver.get("https://www.facebook.com/")
            time.sleep(3)
        except Exception:
            self.driver.get("https://www.facebook.com/")
            time.sleep(3)

    def interact_feed(self, scroll_count: int = 10):
        self.log(f"📰 Bắt đầu lướt News Feed ({scroll_count} lượt) — CHỈ Thả Tim ❤️ / Like 👍 bài của người trong danh sách...")
        self.dismiss_alerts()
        self.driver.get("https://www.facebook.com/")
        time.sleep(4)

        self._inject_virtual_cursor()
        self._detect_my_display_name()

        target_found_count = 0
        total_posts_seen = 0
        seen_post_hashes: Set[str] = set()

        for scroll_round in range(1, scroll_count + 1):
            if self._should_stop():
                break

            # 1. Tìm tất cả các bài đăng trên màn hình theo đúng XPath người dùng chỉ định
            post_data_list = self.driver.execute_script("""
                const targetXPath = '//div[@class="html-div xdj266r x14z9mp xat24cr x1lziwak xexx8yu xyri2b x18d9i69 x1c1uobl x1iyjqo2 xeuugli"]';
                let headerNodes = [];
                try {
                    const snap = document.evaluate(targetXPath, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
                    for (let i = 0; i < snap.snapshotLength; i++) {
                        headerNodes.push(snap.snapshotItem(i));
                    }
                } catch (e) {}

                // Fallback nếu class bị đảo thứ tự
                if (headerNodes.length === 0) {
                    headerNodes = Array.from(document.querySelectorAll('div.html-div.xdj266r.x14z9mp.xat24cr.x1lziwak.xexx8yu.xyri2b.x18d9i69.x1c1uobl.x1iyjqo2.xeuugli'));
                }

                function findLikeBtnForHeader(headerEl) {
                    if (!headerEl) return null;
                    let container = headerEl.closest('[role="article"]') || headerEl.closest('[data-pagelet*="FeedUnit"]');
                    if (!container) {
                        let curr = headerEl;
                        for (let i = 0; i < 18; i++) {
                            if (!curr.parentElement || curr.parentElement === document.body) break;
                            curr = curr.parentElement;
                            const b = findLikeButtonIn(curr);
                            if (b) {
                                container = curr;
                                break;
                            }
                        }
                    }
                    return container ? findLikeButtonIn(container) : null;
                }

                function findLikeButtonIn(container) {
                    if (!container) return null;
                    const btns = container.querySelectorAll('div[role="button"], span[role="button"], [role="button"]');
                    for (const b of btns) {
                        if (b.closest('form, [aria-label*="Bình luận"], [aria-label*="Comment"], [aria-label="Cảm xúc"], [aria-label="Reactions"]')) continue;
                        if (b.getAttribute('data-fb-auto-reacted') === '1') continue;

                        const r = b.getBoundingClientRect();
                        if (r.width < 32 || r.height < 18) continue;

                        const aria = (b.getAttribute('aria-label') || '').trim().toLowerCase();
                        const txt = (b.innerText || '').normalize('NFC').trim().toLowerCase();

                        if (aria.includes('gỡ') || aria.includes('remove') || aria.includes('yêu thích') || txt === 'yêu thích' || txt === 'thương thương') continue;
                        if (aria.includes('bình luận') || aria.includes('comment') || aria.includes('chia sẻ') || aria.includes('share')) continue;

                        const firstLine = txt.split(/[\\r\\n]+/)[0].trim();
                        if (firstLine === 'thích' || firstLine === 'like' || firstLine.startsWith('thích ') || firstLine.startsWith('like ')) {
                            return b;
                        }
                        if (aria === 'thích' || aria === 'like' || aria.startsWith('thích') || aria.startsWith('like') || aria.startsWith('bày tỏ cảm xúc') || aria.startsWith('react')) {
                            return b;
                        }
                    }
                    return null;
                }

                const results = [];
                for (const hEl of headerNodes) {
                    const text = (hEl.innerText || hEl.textContent || '').normalize('NFC').replace(/\\s+/g, ' ').trim();
                    if (!text || text.length < 2) continue;

                    const likeBtn = findLikeBtnForHeader(hEl);
                    results.push({
                        headerEl: hEl,
                        likeBtn: likeBtn,
                        text: text
                    });
                }
                return results;
            """)

            # Nếu DOM hiện tại chưa khớp XPath cụ thể này, gọi bộ quét dự phòng
            if not post_data_list:
                posts_general = self._scan_posts_with_poster_names()
                post_data_list = [
                    {
                        "headerEl": p.get("likeBtn"),
                        "likeBtn": p.get("likeBtn"),
                        "text": " / ".join(p.get("candidates") or []) or p.get("snippet") or ""
                    }
                    for p in posts_general
                ]

            for item in (post_data_list or []):
                if self._should_stop():
                    break

                text = item.get("text") or ""
                header_el = item.get("headerEl")
                like_btn = item.get("likeBtn")

                if not text:
                    continue

                post_hash = text[:80]
                if post_hash in seen_post_hashes:
                    continue
                seen_post_hashes.add(post_hash)
                total_posts_seen += 1

                # 2. Cuộn dần tới bài đăng đó
                if header_el:
                    try:
                        self.driver.execute_script(
                            "arguments[0].scrollIntoView({block: 'center', inline: 'nearest', behavior: 'smooth'});",
                            header_el
                        )
                        time.sleep(random.uniform(1.2, 1.8))
                    except Exception:
                        pass

                # 3. Lấy text xpath này và in output dạng số thứ tự như người dùng mô tả
                display_text = text if len(text) <= 90 else (text[:87] + "...")
                self.log(f"{total_posts_seen}. {display_text}")

                # 4. Kiểm tra xem text có chứa Tên có trong list target_users hay không
                matched_target = None
                text_norm = _normalize_name(text)
                text_no_acc = _remove_accents(text_norm)

                for u in self.target_users:
                    u_norm = _normalize_name(u)
                    u_no_acc = _remove_accents(u_norm)
                    if (u_norm and u_norm in text_norm) or (len(u_no_acc) >= 4 and u_no_acc in text_no_acc):
                        matched_target = u
                        break

                # 5. Nếu output chứa Tên có trong list -> Like hoặc Tim cho bài viết!
                if matched_target:
                    # Kiểm tra và lấy lại nút Like tươi mới của bài viết sau khi cuộn tới tiêu đề
                    fresh_btn = self.driver.execute_script("""
                        const hEl = arguments[0];
                        const oldBtn = arguments[1];
                        if (oldBtn && document.contains(oldBtn)) {
                            return oldBtn;
                        }
                        if (hEl && document.contains(hEl)) {
                            let container = hEl.closest('[role="article"]') || hEl.closest('[data-pagelet*="FeedUnit"]');
                            if (!container) {
                                let curr = hEl;
                                for (let i = 0; i < 20; i++) {
                                    if (!curr.parentElement || curr.parentElement === document.body) break;
                                    curr = curr.parentElement;
                                    if (curr.querySelector('div[role="button"], span[role="button"], [role="button"]')) {
                                        container = curr;
                                        break;
                                    }
                                }
                            }
                            if (container) {
                                const btns = container.querySelectorAll('div[role="button"], span[role="button"], [role="button"]');
                                for (const b of btns) {
                                    if (b.closest('form, [aria-label*="Bình luận"], [aria-label*="Comment"]')) continue;
                                    const aria = (b.getAttribute('aria-label') || '').trim().toLowerCase();
                                    const txt = (b.innerText || '').normalize('NFC').trim().toLowerCase();
                                    const firstLine = txt.split(/[\\r\\n]+/)[0].trim();
                                    if (firstLine === 'thích' || firstLine === 'like' || firstLine.startsWith('thích ') || firstLine.startsWith('like ')) return b;
                                    if (aria === 'thích' || aria === 'like' || aria.startsWith('thích') || aria.startsWith('like') || aria.startsWith('bày tỏ cảm xúc')) return b;
                                }
                            }
                        }
                        return oldBtn || null;
                    """, header_el, like_btn)

                    if fresh_btn:
                        like_btn = fresh_btn

                if matched_target and like_btn:
                    self.reacted_posts.add(post_hash)
                    try:
                        self.driver.execute_script("arguments[0].setAttribute('data-fb-auto-reacted', '1');", like_btn)
                    except Exception:
                        pass

                    self.log(f"🎯 [KHỚP TÊN MỤC TIÊU] Phát hiện bài viết của [{matched_target}] trong danh sách!")
                    target_found_count += 1

                    try:
                        # 1. Random tỉ lệ Thả cảm xúc (mặc định 30%)
                        if random.random() < self.react_rate:
                            if random.random() < self.like_rate:
                                ok = self._react_like(like_btn)
                                if ok:
                                    self.log(f"   👍 ĐÃ THẢ LIKE CHO BÀI VIẾT CỦA [{matched_target}]!")
                                else:
                                    self.log(f"   ⚠️ Thử tương tác Like bài viết của [{matched_target}] không thành công.")
                            else:
                                ok = self._react_love(like_btn)
                                if ok:
                                    self.log(f"   ❤️ ĐÃ THẢ TIM CHO BÀI VIẾT CỦA [{matched_target}]!")
                                else:
                                    self.log(f"   👍 ĐÃ THẢ LIKE CHO BÀI VIẾT CỦA [{matched_target}]!")
                        else:
                            self.log(f"   🎲 [TỰ NHIÊN] Bỏ qua tương tác cảm xúc bài viết của [{matched_target}] (tỉ lệ cấu hình {int(self.react_rate * 100)}%).")

                        # 2. Random tỉ lệ Bình luận (mặc định 5%)
                        if random.random() < self.comment_rate:
                            time.sleep(random.uniform(1.2, 2.0))
                            self._comment_on_post(like_btn, matched_target)

                        time.sleep(random.uniform(2.2, 3.5))
                    except Exception as e:
                        self.log(f"   ⚠️ Lỗi tương tác bài viết của [{matched_target}]: {e}")

            # Cuộn tiếp xuống dưới để nạp thêm bài đăng mới vào DOM
            scroll_dist = random.randint(550, 750)
            self.smooth_scroll(scroll_dist)
            time.sleep(random.uniform(2.0, 3.2))

        self.log(f"📊 Kết thúc lướt Feed: Đã duyệt {total_posts_seen} bài đăng, tìm thấy và tương tác {target_found_count} bài của người đăng mục tiêu!")

    def _scan_and_react_target_posts_on_feed(self) -> bool:
        return self._scan_and_react_target_posts(context_name="Feed")

    def _detect_my_uid(self) -> Optional[str]:
        if self.my_uid:
            return self.my_uid
        try:
            if hasattr(self.driver, "get_c_user_uid"):
                uid = self.driver.get_c_user_uid()
                if uid:
                    self.my_uid = str(uid)
                    self.log(f"👤 Nhận diện tài khoản hiện tại: UID {self.my_uid}")
                    return self.my_uid

            if hasattr(self.driver, "get_cookie"):
                c = self.driver.get_cookie("c_user")
                if c and c.get("value"):
                    self.my_uid = str(c.get("value"))
                    self.log(f"👤 Nhận diện tài khoản hiện tại: UID {self.my_uid}")
                    return self.my_uid

            uid = self.driver.execute_script("""
                const match = document.cookie.match(/c_user=(\\d+)/);
                if (match) return match[1];
                const meLink = document.querySelector('a[href*="/me/"], a[aria-label*="Trang cá nhân"], a[aria-label*="Dòng thời gian"]');
                if (meLink) {
                    const h = meLink.getAttribute('href') || '';
                    const m = h.match(/id=(\\d+)/);
                    if (m) return m[1];
                }
                return null;
            """)
            if uid:
                self.my_uid = str(uid)
                self.log(f"👤 Nhận diện tài khoản hiện tại: UID {self.my_uid}")
            return self.my_uid
        except Exception:
            return None

    def _detect_my_display_name(self) -> Optional[str]:
        """Nhận diện tên hiển thị Facebook của tài khoản đang chạy để tránh tự tương tác bài chính mình"""
        if self.my_display_name:
            return self.my_display_name
        try:
            name = self.driver.execute_script("""
                const navLinks = document.querySelectorAll('div[role="navigation"] a[role="link"], a[href*="/me/"], a[aria-label*="Trang cá nhân"]');
                for (const a of navLinks) {
                    const href = a.getAttribute('href') || '';
                    if (href.includes('profile.php') || /^https?:\\/\\/(www\\.)?facebook\\.com\\/[A-Za-z0-9._-]+\\/?$/.test(href)) {
                        const txt = (a.innerText || '').trim();
                        if (txt && txt.length >= 2 && txt.length <= 50 && !txt.includes('\\n')) {
                            return txt;
                        }
                    }
                }
                return null;
            """)
            if name and isinstance(name, str) and len(name.strip()) >= 2:
                self.my_display_name = name.strip()
                self.log(f"👤 Nhận diện tên tài khoản hiện tại: [{self.my_display_name}]")
        except Exception:
            pass
        return self.my_display_name

    def _match_poster_name(self, candidate_names: List[str]) -> Optional[Tuple[str, str]]:
        """
        Kiểm tra danh sách tên ứng viên trích xuất từ bài viết xem có khớp với tên nào
        trong danh sách self.target_users hay không (hỗ trợ cả có dấu & không dấu, không phân biệt hoa thường).
        """
        if not candidate_names or not self.target_users:
            return None

        my_name_norm = _normalize_name(self.my_display_name) if self.my_display_name else ""

        for raw_cand in candidate_names:
            if not raw_cand:
                continue
            cand_norm = _normalize_name(raw_cand)
            if not cand_norm or len(cand_norm) < 2:
                continue

            if my_name_norm and cand_norm == my_name_norm:
                continue

            # Làm sạch ký tự phân cách ở đầu/cuối như dấu chấm, phẩy, bullet, mũi tên
            cand_clean = re.sub(r'^[·•>▸›.\-,\s:]+|[·•>▸›.\-,\s:]+$', '', cand_norm).strip()
            cand_no_accent = _remove_accents(cand_clean)

            for raw_target in self.target_users:
                target_norm = _normalize_name(raw_target)
                if not target_norm:
                    continue

                # 1. Khớp chính xác (không phân biệt hoa thường)
                if cand_norm == target_norm or cand_clean == target_norm:
                    return (raw_cand.strip(), raw_target.strip())

                # 2. Khớp cụm từ theo ranh giới từ (ví dụ target "Trương Nhiên" nằm trong "Trương Nhiên · Theo dõi" hoặc "Hội ABC > Trương Nhiên")
                if len(target_norm) >= 4:
                    padded_cand = f" {cand_clean} "
                    padded_target = f" {target_norm} "
                    if padded_target in padded_cand or cand_clean.startswith(f"{target_norm} ") or cand_clean.endswith(f" {target_norm}"):
                        return (raw_cand.strip(), raw_target.strip())
                    try:
                        if re.search(r'(?:\b|^)' + re.escape(target_norm) + r'(?:\b|$)', cand_clean):
                            return (raw_cand.strip(), raw_target.strip())
                    except Exception:
                        pass

                # 3. Khớp không dấu
                target_no_accent = _remove_accents(target_norm)
                if target_no_accent and (cand_no_accent == target_no_accent):
                    return (raw_cand.strip(), raw_target.strip())
                if len(target_no_accent) >= 4:
                    padded_no_acc_cand = f" {cand_no_accent} "
                    padded_no_acc_target = f" {target_no_accent} "
                    if padded_no_acc_target in padded_no_acc_cand:
                        return (raw_cand.strip(), raw_target.strip())
                    try:
                        if re.search(r'(?:\b|^)' + re.escape(target_no_accent) + r'(?:\b|$)', cand_no_accent):
                            return (raw_cand.strip(), raw_target.strip())
                    except Exception:
                        pass

                # 4. Khớp chuỗi con trực tiếp (kể cả khi tên bị dính liền nhãn như Trương KimNội dung hoặc (Nhóm)Cù Nhã)
                if len(target_norm) >= 4 and target_norm in cand_norm:
                    return (raw_cand.strip(), raw_target.strip())
                if len(target_no_accent) >= 4 and target_no_accent in cand_no_accent:
                    return (raw_cand.strip(), raw_target.strip())

        return None

    def _scan_posts_with_poster_names(self) -> List[Dict[str, Any]]:
        """
        Quét tất cả các bài viết đang hiển thị trên màn hình (chưa Thích/Thả tim)
        và trích xuất đầy đủ TÊN NGƯỜI ĐĂNG (candidate_names) từ mọi cấu trúc Feed & Nhóm:
        - Tự động phát hiện nếu tiêu đề bài của Target User đã hiện trên màn hình nhưng nút Like
          nằm tụt bên dưới ảnh poster dài -> cuộn nhẹ để lộ nút Like trước khi quét.
        - Phân tách chính xác ranh giới từng bài viết dựa trên container chuẩn của Facebook.
        - Bóc tách mọi dòng trong tiêu đề bài Nhóm (Tên Nhóm ở dòng 1, Tên Người Đăng ở dòng 2).
        """
        try:
            target_norms = [_normalize_name(u) for u in (self.target_users or []) if _normalize_name(u)]

            need_nudge = self.driver.execute_script("""
                const targets = arguments[0] || [];
                if (!targets.length) return false;
                const nodes = document.querySelectorAll('h2, h3, h4, strong, a[role="link"], span[dir="auto"]');
                for (const n of nodes) {
                    const r = n.getBoundingClientRect();
                    if (r.top < 120 || r.top > window.innerHeight - 20) continue;
                    const txt = ((n.innerText || n.textContent || '').normalize('NFC').replace(/\\s+/g, ' ').trim()).toLowerCase();
                    if (!txt || txt.length > 90) continue;
                    for (const t of targets) {
                        if (txt === t || txt.includes(t)) {
                            if (r.top > window.innerHeight * 0.45) {
                                return true;
                            }
                        }
                    }
                }
                return false;
            """, target_norms)

            if need_nudge:
                self.smooth_scroll(320)
                time.sleep(0.9)

            posts_data = self.driver.execute_script("""
                const results = [];
                const allRoleButtons = Array.from(document.querySelectorAll('div[role="button"], span[role="button"], [role="button"], a[role="button"]'));

                // Kiểm tra xem nút có nằm trong khung bình luận hoặc thanh chọn reaction nổi hay không
                function isCommentOrReactionDock(btn) {
                    if (!btn) return true;
                    if (btn.closest(
                        'form, [aria-label*="Bình luận"], [aria-label*="Comment"], ' +
                        '[aria-label*="Phản hồi"], [aria-label*="Reply"], ' +
                        'ul[role="group"], div[aria-label*="bình luận"]'
                    )) return true;
                    if (btn.closest(
                        '[aria-label="Cảm xúc"], [aria-label="Reactions"], [role="dialog"], [role="tooltip"]'
                    )) return true;
                    return false;
                }

                // Nhận diện nút Like chính của bài viết chưa tương tác
                function isUnreactedMainPostLikeButton(btn) {
                    if (!btn || isCommentOrReactionDock(btn)) return false;
                    if (btn.getAttribute('data-fb-auto-reacted') === '1') return false;
                    const r = btn.getBoundingClientRect();
                    if (r.width < 32 || r.height < 18) return false;

                    const aria = (btn.getAttribute('aria-label') || '').trim();
                    const ariaLower = aria.toLowerCase();
                    const txt = (btn.innerText || '').normalize('NFC').trim().toLowerCase();

                    // Đã tương tác cảm xúc rồi -> bỏ qua
                    if (
                        ariaLower.includes('gỡ ') ||
                        ariaLower.includes('remove ') ||
                        ariaLower.includes('thay đổi cảm xúc') ||
                        ariaLower.includes('đổi cảm xúc') ||
                        ariaLower.includes('yêu thích') ||
                        ariaLower.includes('thương thương') ||
                        ariaLower.includes('haha') ||
                        ariaLower.includes('wow') ||
                        ariaLower.includes('buồn') ||
                        ariaLower.includes('phẫn nộ') ||
                        txt === 'yêu thích' || txt === 'thương thương' || txt === 'haha' || txt === 'wow' || txt === 'buồn' || txt === 'phẫn nộ'
                    ) {
                        return false;
                    }

                    // Loại trừ nút Bình luận hoặc Chia sẻ
                    if (
                        ariaLower.includes('bình luận') || ariaLower.includes('comment') ||
                        ariaLower.includes('chia sẻ') || ariaLower.includes('share') ||
                        ariaLower.includes('chú thích') ||
                        txt.includes('bình luận') || txt.includes('comment') ||
                        txt.includes('chia sẻ') || txt.includes('share')
                    ) {
                        return false;
                    }

                    // Khớp theo text hiển thị
                    const firstLineTxt = txt.split(/[\\r\\n]+/)[0].trim();
                    if (firstLineTxt === 'thích' || firstLineTxt === 'like' || firstLineTxt.startsWith('thích ') || firstLineTxt.startsWith('like ')) {
                        return true;
                    }

                    // Khớp theo aria-label
                    if (
                        ariaLower === 'thích' || ariaLower === 'like' ||
                        ariaLower.startsWith('thích bài viết') || ariaLower.startsWith('thích về bài viết') ||
                        ariaLower.startsWith('like this post') || ariaLower.startsWith('like post') ||
                        ariaLower.startsWith('bày tỏ cảm xúc') || ariaLower.startsWith('react') ||
                        ariaLower.includes('bày tỏ cảm xúc đối với bài viết') ||
                        ariaLower.includes('bày tỏ cảm xúc về bài viết')
                    ) {
                        return true;
                    }

                    return false;
                }

                // Tìm container bài viết chuẩn xác từ likeBtn
                function findPostContainer(likeBtn) {
                    const article = likeBtn.closest('[role="article"]');
                    if (article) return article;

                    const feedUnit = likeBtn.closest('[data-pagelet*="FeedUnit"]');
                    if (feedUnit) return feedUnit;

                    const feed = likeBtn.closest('[role="feed"]');
                    if (feed) {
                        let curr = likeBtn;
                        while (curr && curr.parentElement && curr.parentElement !== feed) {
                            curr = curr.parentElement;
                        }
                        if (curr && curr !== feed && curr !== document.body) return curr;
                    }

                    let curr = likeBtn;
                    let candidate = null;
                    for (let i = 0; i < 22; i++) {
                        if (!curr.parentElement || curr.parentElement === document.body) break;
                        curr = curr.parentElement;
                        const r = curr.getBoundingClientRect();
                        if (r.height > 160 && r.width > 260) {
                            candidate = curr;
                            if (curr.querySelector('h2, h3, h4, [aria-label*="bài viết"]')) {
                                return curr;
                            }
                        }
                    }
                    return candidate || likeBtn.parentElement;
                }

                const postLikeBtns = allRoleButtons.filter(isUnreactedMainPostLikeButton);

                const ignoreWords = new Set([
                    'thích', 'like', 'bình luận', 'comment', 'chia sẻ', 'share',
                    'được tài trợ', 'sponsored', 'theo dõi', 'follow', 'tham gia', 'join',
                    'xem thêm', 'see more', 'tất cả cảm xúc', 'all reactions', 'viết bình luận',
                    'nhắn tin', 'message', 'gửi', 'send', 'ẩn', 'hide', 'báo cáo', 'report',
                    'gợi ý cho bạn', 'suggested for you', 'reels', 'thước phim', 'đăng', 'post',
                    'bạn bè', 'friends', 'công khai', 'public', 'chỉ mình tôi', 'only me',
                    'xem bản dịch', 'see translation', 'tác giả', 'author', 'quản trị viên', 'admin',
                    'người đóng góp nổi bật', 'top contributor', 'thành viên mới', 'new member',
                    'menu trên facebook', 'lối tắt của bạn', 'tạo bài viết', 'bài viết trên bảng feed',
                    'nhóm công khai', 'nhóm riêng tư', 'public group', 'private group', 'thành viên'
                ]);

                function cleanSingleSegment(seg) {
                    if (!seg) return '';
                    let s = seg.normalize('NFC').replace(/[\\u200B-\\u200D\\uFEFF\\u00A0]/g, ' ').replace(/\\s+/g, ' ').trim();
                    const splitMarkers = [
                        ' đang phát trực tiếp', ' đã phát trực tiếp', ' đang cảm thấy ',
                        ' đã thêm ', ' đã cập nhật ', ' đã chia sẻ ', ' đã đăng ',
                        ' đang ở ', ' cùng với ', ' trong ', ' is with ', ' was live', ' is live',
                        ' added ', ' updated ', ' shared ', ' posted ', ' in '
                    ];
                    for (const m of splitMarkers) {
                        const idx = s.toLowerCase().indexOf(m);
                        if (idx > 1) {
                            s = s.substring(0, idx).trim();
                        }
                    }
                    return s.replace(/^[·•>▸›\\s]+|[·•>▸›.\\s]+$/g, '').trim();
                }

                function isNoiseText(txt) {
                    if (!txt) return true;
                    const clean = txt.normalize('NFC').replace(/[\\u200B-\\u200D\\uFEFF·•]/g, '').trim();
                    if (clean.length < 2 || clean.length > 85) return true;
                    if (clean.includes('\\n')) return true;
                    const lower = clean.toLowerCase();
                    if (ignoreWords.has(lower)) return true;
                    if (/^[0-9.,\\sKMBkmb]+$/.test(clean)) return true;
                    if (/^(\\d+\\s*(phút|giờ|ngày|tuần|tháng|năm|giây|p|h|d|w|m|y)|vừa xong|hôm qua|yesterday|just now|hôm nay)$/i.test(clean)) return true;
                    if (/^\\d+\\s+tháng\\s+\\d+/i.test(clean)) return true;
                    if (lower.includes('người khác') || lower.includes('others') || lower.includes('bình luận') || lower.includes('lượt chia sẻ')) return true;
                    return false;
                }

                function extractNameFromAria(ariaStr) {
                    if (!ariaStr) return [];
                    const found = [];
                    const patterns = [
                        /về bài viết của\\s+(.+)$/i,
                        /đối với bài viết này của\\s+(.+)$/i,
                        /đối với bài viết của\\s+(.+)$/i,
                        /với bài viết của\\s+(.+)$/i,
                        /về ảnh của\\s+(.+)$/i,
                        /về video của\\s+(.+)$/i,
                        /về thước phim của\\s+(.+)$/i,
                        /bài viết của\\s+(.+)$/i,
                        /post by\\s+(.+)$/i,
                        /actions for this post by\\s+(.+)$/i,
                        /story by\\s+(.+)$/i
                    ];
                    for (const pat of patterns) {
                        const m = ariaStr.match(pat);
                        if (m && m[1]) {
                            const rawAfter = m[1].trim();
                            const cleaned = cleanSingleSegment(rawAfter);
                            if (cleaned && !isNoiseText(cleaned)) found.push(cleaned);
                            const parts = rawAfter.split(/\\s+trong\\s+|\\s+in\\s+|\\s*[·•>▸›]\\s*/i);
                            for (const pt of parts) {
                                const c = cleanSingleSegment(pt);
                                if (c && !isNoiseText(c) && !found.includes(c)) found.push(c);
                            }
                        }
                    }
                    return found;
                }

                const seenContainers = new Set();

                for (const likeBtn of postLikeBtns) {
                    const lr = likeBtn.getBoundingClientRect();
                    // Cho phép quét cả các bài viết dài có nút Like nằm sâu phía dưới màn hình tới 1100px
                    if (lr.top < -150 || lr.top > window.innerHeight + 1100) {
                        continue;
                    }

                    const bestContainer = findPostContainer(likeBtn);
                    if (!bestContainer || seenContainers.has(bestContainer)) {
                        continue;
                    }
                    seenContainers.add(bestContainer);

                    const candidateNames = [];
                    const addCandidate = (raw) => {
                        if (!raw) return;
                        const lines = String(raw).split(/\\r?\\n/);
                        for (const line of lines) {
                            const cleanedLine = cleanSingleSegment(line);
                            if (cleanedLine && !isNoiseText(cleanedLine) && !candidateNames.includes(cleanedLine)) {
                                candidateNames.push(cleanedLine);
                            }
                            const subParts = line.split(/\\s*[·•>▸›]\\s*/);
                            for (const sp of subParts) {
                                const cSub = cleanSingleSegment(sp);
                                if (cSub && !isNoiseText(cSub) && !candidateNames.includes(cSub)) {
                                    candidateNames.push(cSub);
                                }
                            }
                        }
                    };

                    // Nguồn 0: Lấy từ phần tử header chứa tên người đăng (đúng theo class user chỉ định)
                    const targetHeaders = bestContainer.querySelectorAll('div.html-div.xdj266r.x14z9mp.xat24cr.x1lziwak.xexx8yu.xyri2b.x18d9i69.x1c1uobl.x1iyjqo2.xeuugli');
                    for (const th of targetHeaders) {
                        addCandidate(th.innerText || th.textContent || '');
                    }

                    // Nguồn 1: Lấy trực tiếp từ aria-label của chính nút Like
                    for (const n of extractNameFromAria(likeBtn.getAttribute('aria-label') || '')) {
                        addCandidate(n);
                    }

                    // Nguồn 2: Lấy từ nút 3 chấm "Hành động đối với bài viết này của <Tên>"
                    const actionMenuBtns = bestContainer.querySelectorAll(
                        '[aria-label*="bài viết này của"], [aria-label*="bài viết của"], ' +
                        '[aria-label*="ảnh của"], [aria-label*="video của"], [aria-label*="thước phim của"], ' +
                        '[aria-label*="post by"], [aria-label*="actions for"]'
                    );
                    for (const ab of actionMenuBtns) {
                        if (isCommentOrReactionDock(ab)) continue;
                        for (const n of extractNameFromAria(ab.getAttribute('aria-label') || '')) {
                            addCandidate(n);
                        }
                    }

                    // Nguồn 3: Lấy từ thẻ tiêu đề bài viết (h2, h3, h4) ở phần đầu bài
                    const headings = bestContainer.querySelectorAll('h2, h3, h4');
                    for (const h of headings) {
                        if (isCommentOrReactionDock(h)) continue;
                        const hr = h.getBoundingClientRect();
                        if (hr.top >= lr.top) continue;

                        const subNodes = h.querySelectorAll('a[role="link"], a[href], strong, span[dir="auto"], span');
                        for (const sn of subNodes) {
                            if (sn.children.length === 0) {
                                addCandidate(sn.innerText || sn.textContent || '');
                            }
                            const snAria = sn.getAttribute('aria-label') || '';
                            if (snAria) addCandidate(snAria);
                        }
                        addCandidate(h.innerText || h.textContent || '');
                    }

                    // Nguồn 4: Lấy từ avatar aria-label, strong, a[role="link"], a[href], span[dir="auto"] nằm phía trên nút Like
                    const headerNodes = bestContainer.querySelectorAll(
                        'strong, a[role="link"], a[href*="/user/"], a[href*="profile.php"], a[aria-label], svg[aria-label], span[dir="auto"]'
                    );
                    for (const node of headerNodes) {
                        if (candidateNames.length >= 40) break;
                        if (isCommentOrReactionDock(node)) continue;
                        const nr = node.getBoundingClientRect();
                        if (nr.width <= 0 || nr.height <= 0) continue;
                        if (nr.top >= lr.top - 15) continue;

                        const href = (node.getAttribute && node.getAttribute('href')) || '';
                        if (href.includes('/hashtag/')) continue;

                        const nodeAria = (node.getAttribute && node.getAttribute('aria-label')) || '';
                        if (nodeAria && !nodeAria.toLowerCase().includes('hành động') && !nodeAria.toLowerCase().includes('bày tỏ')) {
                            addCandidate(nodeAria);
                        }

                        if (node.tagName !== 'SVG') {
                            addCandidate(node.innerText || node.textContent || '');
                        }
                    }

                    const primaryAuthor = candidateNames.length > 0 ? candidateNames[0] : 'Unknown';
                    const snippet = ((bestContainer.innerText || '').replace(/\\s+/g, ' ').trim()).substring(0, 90);
                    const postKey = candidateNames.slice(0, 3).join('/') + '|' + snippet;

                    results.push({
                        likeBtn: likeBtn,
                        candidates: candidateNames.slice(0, 40),
                        primaryAuthor: primaryAuthor,
                        postKey: postKey,
                        snippet: snippet
                    });
                }

                return results;
            """)
            return posts_data if isinstance(posts_data, list) else []
        except Exception as e:
            self.log(f"   ⚠️ Lỗi khi quét tên người đăng: {e}")
            return []

    def _scan_and_react_target_posts(self, context_name: str = "Feed") -> bool:
        """
        Quét các bài viết đang hiển thị trên màn hình, tìm bài có Tên người đăng nằm trong
        danh sách self.target_users và thực hiện Thả Tim ❤️ (80%) hoặc Like 👍 (20%).
        Tuyệt đối CHỈ tương tác bài viết của người có tên trong danh sách.
        """
        try:
            self._detect_my_display_name()
            posts = self._scan_posts_with_poster_names()
            if not posts:
                return False

            matched_any = False
            new_authors_this_view = []

            for item in posts:
                if self._should_stop():
                    break

                post_key = item.get("postKey") or ""
                if not post_key or post_key in self.reacted_posts:
                    continue

                candidates: List[str] = item.get("candidates") or []
                primary_author = item.get("primaryAuthor") or "Không rõ"
                like_btn = item.get("likeBtn")
                snippet = item.get("snippet") or ""

                if not like_btn:
                    continue

                if primary_author != "Unknown" and primary_author not in self.seen_authors_log:
                    self.seen_authors_log.add(primary_author)
                    display_scan = (
                        f"{candidates[0]} ({candidates[1]})"
                        if len(candidates) >= 2 and candidates[1] != candidates[0] and len(candidates[1]) <= 35
                        else primary_author
                    )
                    new_authors_this_view.append(display_scan)

                if not self.target_users:
                    continue

                match_res = self._match_poster_name(candidates)
                if match_res:
                    actual_poster, matched_target = match_res
                    self.reacted_posts.add(post_key)
                    try:
                        self.driver.execute_script("arguments[0].setAttribute('data-fb-auto-reacted', '1');", like_btn)
                    except Exception:
                        pass

                    self.log(f"🎯 [KHỚP TÊN MỤC TIÊU] Phát hiện bài viết của [{actual_poster}] (khớp tên '{matched_target}') trên {context_name}!")
                    if snippet:
                        self.log(f"   Trích đoạn: {snippet[:65].strip()}...")

                    try:
                        # 1. Random tỉ lệ Thả cảm xúc (mặc định 30%)
                        if random.random() < self.react_rate:
                            if random.random() < self.like_rate:
                                ok = self._react_like(like_btn)
                                if ok:
                                    self.log(f"   👍 ĐÃ THẢ LIKE CHO BÀI VIẾT CỦA [{actual_poster}]!")
                                else:
                                    self.log(f"   ⚠️ Thử thả Like bài viết của [{actual_poster}] không thành công.")
                            else:
                                ok = self._react_love(like_btn)
                                if ok:
                                    self.log(f"   ❤️ ĐÃ THẢ TIM CHO BÀI VIẾT CỦA [{actual_poster}]!")
                                else:
                                    self.log(f"   👍 ĐÃ THẢ LIKE CHO BÀI VIẾT CỦA [{actual_poster}]!")
                        else:
                            self.log(f"   🎲 [TỰ NHIÊN] Bỏ qua tương tác cảm xúc bài viết của [{actual_poster}] (tỉ lệ cấu hình {int(self.react_rate * 100)}%).")

                        # 2. Random tỉ lệ Bình luận (mặc định 5%)
                        if random.random() < self.comment_rate:
                            time.sleep(random.uniform(1.2, 2.0))
                            self._comment_on_post(like_btn, actual_poster)

                        matched_any = True
                        time.sleep(random.uniform(2.0, 3.2))
                    except Exception as e:
                        self.log(f"   ⚠️ Lỗi tương tác bài viết của [{actual_poster}]: {e}")

            if new_authors_this_view:
                preview = ", ".join([f'"{a}"' for a in new_authors_this_view[:4]])
                self.log(f"🔎 [{context_name}] Đã quét qua bài viết của: {preview}")

            return matched_any
        except Exception as e:
            self.log(f"   ⚠️ Lỗi quét bài viết theo tên trên {context_name}: {e}")
            return False

    def _try_browse_carousel(self):
        try:
            next_arrows = self.driver.find_elements(
                By.XPATH,
                '//div[@aria-label="Mục tiếp theo" or @aria-label="Next"]'
            )
            for arrow in next_arrows:
                if arrow.is_displayed():
                    self._click_element_with_cursor(arrow)
                    time.sleep(1.2)
                    break
        except Exception:
            pass

    def _react_like(self, like_btn_element) -> bool:
        """
        Thực hiện Thả Like 👍 chuẩn xác cho bài viết (CHỈ click 1 lần duy nhất, tránh bấm đúp hủy like).
        """
        try:
            # 1. Kiểm tra trạng thái hiện tại của nút Like: nếu đã Like/Tim rồi thì không bấm lại
            status = self.driver.execute_script("""
                const el = arguments[0];
                if (!el) return "invalid";
                const aria = (el.getAttribute('aria-label') || '').trim().toLowerCase();
                const txt = (el.innerText || '').normalize('NFC').trim().toLowerCase();
                if (
                    aria.includes('gỡ') || aria.includes('remove') ||
                    aria.includes('thay đổi cảm xúc') || aria.includes('đổi cảm xúc') ||
                    aria.includes('yêu thích') || aria.includes('thương thương') ||
                    aria.includes('haha') || aria.includes('wow') || aria.includes('buồn') || aria.includes('phẫn nộ') ||
                    txt === 'yêu thích' || txt === 'thương thương' || txt === 'haha' || txt === 'wow' || txt === 'buồn' || txt === 'phẫn nộ'
                ) {
                    return "already_reacted";
                }
                return "ok";
            """, like_btn_element)

            if status == "already_reacted":
                self.log("   ℹ️ Bài viết này đã có cảm xúc từ trước (không bấm lại).")
                return True
            if status == "invalid":
                return False

            # 2. Cuộn nút Like về giữa màn hình
            self.driver.execute_script(
                "arguments[0].scrollIntoView({block: 'center', inline: 'nearest', behavior: 'instant'});",
                like_btn_element,
            )
            time.sleep(0.35)

            # Di chuyển chuột ảo tới nút Like (click=False để không phát sinh hành vi click phụ)
            self._move_cursor_to_element(like_btn_element, click=False)
            time.sleep(0.12)

            clicked = False
            # 3. Thực hiện Click THẬT đúng 1 lần duy nhất
            if self.is_playwright and hasattr(like_btn_element, "_handle"):
                try:
                    like_btn_element._handle.click(timeout=3000)
                    clicked = True
                except Exception:
                    pass
            elif not self.is_playwright:
                try:
                    ActionChains(self.driver).move_to_element(like_btn_element).pause(0.1).click().perform()
                    clicked = True
                except Exception:
                    try:
                        like_btn_element.click()
                        clicked = True
                    except Exception:
                        pass

            # 4. CHỈ KHI click native thất bại hoàn toàn mới fallback sang JS click (đảm bảo không bao giờ bấm 2 lần)
            if not clicked:
                self.driver.execute_script("if (arguments[0]) arguments[0].click();", like_btn_element)

            time.sleep(0.5)
            return True
        except Exception as e:
            self.log(f"   ⚠️ Lỗi thả Like: {e}")
            return False

    def _react_love(self, like_btn_element) -> bool:
        """
        Di chuột giữ trên nút Thích (Like) để mở thanh Cảm xúc (Reactions Dock)
        và click đúng 1 lần duy nhất vào nút 'Yêu thích' (Love / ❤️).
        Hỗ trợ cả Playwright/Camoufox (DMT Browser) và Selenium (GPMLogin).
        Nếu không mở được dock cảm xúc, tự động fallback về Thả Like 👍 (1 lần click).
        """
        try:
            # 1. Kiểm tra trạng thái hiện tại: nếu đã Like/Tim rồi thì không bấm lại
            status = self.driver.execute_script("""
                const el = arguments[0];
                if (!el) return "invalid";
                const aria = (el.getAttribute('aria-label') || '').trim().toLowerCase();
                const txt = (el.innerText || '').normalize('NFC').trim().toLowerCase();
                if (
                    aria.includes('gỡ') || aria.includes('remove') ||
                    aria.includes('thay đổi cảm xúc') || aria.includes('đổi cảm xúc') ||
                    aria.includes('yêu thích') || aria.includes('thương thương') ||
                    aria.includes('haha') || aria.includes('wow') || aria.includes('buồn') || aria.includes('phẫn nộ') ||
                    txt === 'yêu thích' || txt === 'thương thương' || txt === 'haha' || txt === 'wow' || txt === 'buồn' || txt === 'phẫn nộ'
                ) {
                    return "already_reacted";
                }
                return "ok";
            """, like_btn_element)

            if status == "already_reacted":
                self.log("   ℹ️ Bài viết này đã có cảm xúc từ trước (không bấm lại).")
                return True
            if status == "invalid":
                return False

            # 2. Cuộn bài viết về giữa màn hình TỨC THÌ (behavior: 'instant')
            self.driver.execute_script(
                "arguments[0].scrollIntoView({block: 'center', inline: 'nearest', behavior: 'instant'});",
                like_btn_element,
            )
            time.sleep(0.35)

            rect = self.driver.execute_script("""
                const el = arguments[0];
                if (!el) return null;
                const r = el.getBoundingClientRect();
                if (r.width <= 0 || r.height <= 0) return null;
                return {
                    x: Math.round(r.left + r.width / 2),
                    y: Math.round(r.top + r.height / 2),
                    w: Math.round(r.width),
                    h: Math.round(r.height),
                    top: Math.round(r.top),
                    left: Math.round(r.left)
                };
            """, like_btn_element)

            if not rect:
                return self._react_like(like_btn_element)

            cx, cy = int(rect["x"]), int(rect["y"])
            self._move_cursor_to_element(like_btn_element, click=False)

            # 3. Hover và giữ chuột trên nút Thích để kích hoạt thanh cảm xúc
            if self.is_playwright and hasattr(self.driver, "page"):
                try:
                    self.driver.page.mouse.move(cx, cy, steps=6)
                    time.sleep(0.1)
                except Exception:
                    pass
            else:
                try:
                    ActionChains(self.driver).move_to_element(like_btn_element).pause(0.75).perform()
                except Exception:
                    pass

            # Phát sự kiện hover trên nút Thích
            self.driver.execute_script("""
                const el = arguments[0];
                const cx = arguments[1];
                const cy = arguments[2];
                if (!el) return;
                const topNode = document.elementFromPoint(cx, cy) || el;
                const targets = [topNode, el, el.parentElement].filter(Boolean);
                const ptrOpts = {bubbles: true, cancelable: true, clientX: cx, clientY: cy, pointerId: 1, pointerType: 'mouse', isPrimary: true, buttons: 0};
                const mouseOpts = {bubbles: true, cancelable: true, clientX: cx, clientY: cy, buttons: 0};
                for (const t of targets) {
                    try {
                        t.dispatchEvent(new PointerEvent('pointerover', ptrOpts));
                        t.dispatchEvent(new PointerEvent('pointerenter', ptrOpts));
                        t.dispatchEvent(new MouseEvent('mouseover', mouseOpts));
                        t.dispatchEvent(new MouseEvent('mouseenter', mouseOpts));
                        t.dispatchEvent(new PointerEvent('pointermove', ptrOpts));
                        t.dispatchEvent(new MouseEvent('mousemove', mouseOpts));
                    } catch (e) {}
                }
            """, like_btn_element, cx, cy)

            time.sleep(0.75)

            # 4. Tìm nút 'Yêu thích' / 'Love'
            love_info = None
            love_btn_el = None

            for attempt in range(8):
                if attempt > 0:
                    time.sleep(0.2)

                found = self.driver.execute_script("""
                    const likeEl = arguments[0];
                    if (!likeEl) return null;
                    const lr = likeEl.getBoundingClientRect();
                    const likeCenterX = lr.left + lr.width / 2;

                    // Tìm nút có aria-label 'Yêu thích' hoặc 'Love'
                    const candidates = Array.from(document.querySelectorAll(
                        'div[role="button"][aria-label="Yêu thích"], div[role="button"][aria-label="Love"], ' +
                        '[role="toolbar"] [aria-label="Yêu thích"], [role="toolbar"] [aria-label="Love"], ' +
                        '[aria-label="Yêu thích"][role="button"], [aria-label="Love"][role="button"], ' +
                        '[aria-label^="Yêu thích"], [aria-label^="Love"]'
                    ));

                    for (const n of candidates) {
                        const aria = (n.getAttribute('aria-label') || '').trim().toLowerCase();
                        if (!aria.startsWith('yêu thích') && !aria.startsWith('love')) continue;

                        const r = n.getBoundingClientRect();
                        if (r.width < 18 || r.height < 18) continue;
                        if (r.top < 10 || r.bottom > window.innerHeight - 10) continue;

                        const dy = lr.top - r.top;
                        const dx = Math.abs((r.left + r.width / 2) - likeCenterX);
                        if (dy >= 6 && dy <= 160 && dx <= 280) {
                            return {
                                el: n,
                                x: Math.round(r.left + r.width / 2),
                                y: Math.round(r.top + r.height / 2),
                                label: aria
                            };
                        }
                    }

                    // Tìm theo toolbar cảm xúc
                    const toolbars = document.querySelectorAll('[role="toolbar"], [aria-label="Cảm xúc"], [aria-label="Reactions"]');
                    for (const tb of toolbars) {
                        const tr = tb.getBoundingClientRect();
                        if (tr.width > 100 && tr.height > 22 && tr.top > 10 && Math.abs(tr.bottom - lr.top) < 110) {
                            const btns = tb.querySelectorAll('[role="button"]');
                            if (btns.length >= 2) {
                                const loveNode = btns[1];
                                const r = loveNode.getBoundingClientRect();
                                if (r.width >= 18 && r.height >= 18 && r.top > 10) {
                                    return {
                                        el: loveNode,
                                        x: Math.round(r.left + r.width / 2),
                                        y: Math.round(r.top + r.height / 2),
                                        label: loveNode.getAttribute('aria-label') || 'Yêu thích'
                                    };
                                }
                            }
                        }
                    }
                    return null;
                """, like_btn_element)

                if found and isinstance(found, dict) and found.get("el"):
                    love_info = found
                    love_btn_el = found["el"]
                    break

            # 5. Click THẬT đúng 1 lần vào nút 'Yêu thích'
            if love_btn_el and love_info:
                lx, ly = int(love_info["x"]), int(love_info["y"])
                self._move_cursor_to_element(love_btn_el, click=False)
                time.sleep(0.12)

                clicked_ok = False
                if self.is_playwright and hasattr(self.driver, "page"):
                    try:
                        self.driver.page.mouse.click(lx, ly)
                        clicked_ok = True
                    except Exception:
                        try:
                            if hasattr(love_btn_el, "_handle"):
                                love_btn_el._handle.click()
                            else:
                                love_btn_el.click()
                            clicked_ok = True
                        except Exception:
                            pass
                else:
                    try:
                        ActionChains(self.driver).move_to_element(love_btn_el).pause(0.1).click().perform()
                        clicked_ok = True
                    except Exception:
                        try:
                            love_btn_el.click()
                            clicked_ok = True
                        except Exception:
                            pass

                # CHỈ fallback sang JS click khi native click thất bại (đảm bảo bấm đúng 1 lần)
                if not clicked_ok:
                    self.driver.execute_script("if (arguments[0]) arguments[0].click();", love_btn_el)

                time.sleep(0.5)
                return True

            # Nếu không tìm thấy thanh cảm xúc -> Fallback sang Thả Like 👍 (1 lần click duy nhất)
            return self._react_like(like_btn_element)
        except Exception as e:
            self.log(f"   ⚠️ Lỗi thả tim, fallback thả like: {e}")
            return self._react_like(like_btn_element)

    def _comment_on_post(self, like_btn_element, author_name: str) -> bool:
        """
        Bấm vào viết bình luận và đăng comment vào bài viết của user mục tiêu
        sử dụng các XPath chuẩn:
        - //div[@aria-label="Viết bình luận"]
        - //div[@role="textbox"]
        - //div[@aria-label="Đăng bình luận"]
        Cmt theo danh sách từ/câu được cấu hình ở 'cấu hình kịch bản' (mỗi câu 1 dòng, chọn ngẫu nhiên).
        Sau khi gửi, chờ 5-10 giây để cmt được đăng hoàn tất, sau đó đóng bài và tiếp tục lướt.
        """
        try:
            # Lấy ngẫu nhiên 1 câu/từ từ danh sách cấu hình
            valid_comments = [c.strip() for c in (self.comment_texts or []) if c and c.strip()]
            if not valid_comments:
                valid_comments = [
                    "Bài viết rất hay và ý nghĩa bạn ơi 👍",
                    "Tuyệt vời quá ạ ❤️",
                    "Chúc bạn ngày mới nhiều năng lượng và may mắn!",
                    "Rất hữu ích, cảm ơn bạn đã chia sẻ!",
                    "Tương tác cùng nhau phát triển nhé bạn ơi 👍",
                ]
            cmt_text = random.choice(valid_comments)
            self.log(f"   💬 Chuẩn bị bình luận bài viết của [{author_name}]...")

            # 1. Tìm nút 'Viết bình luận' hoặc nút Bình luận của bài viết
            clicked_open = False
            try:
                open_res = self.driver.execute_script("""
                    const likeEl = arguments[0];
                    if (!likeEl) return null;
                    let container = likeEl.closest('[role="article"]') || likeEl.closest('[data-pagelet*="FeedUnit"]');
                    if (!container) {
                        let curr = likeEl;
                        for (let i = 0; i < 20; i++) {
                            if (!curr.parentElement || curr.parentElement === document.body) break;
                            curr = curr.parentElement;
                            if (curr.querySelector('[role="article"], [data-pagelet*="FeedUnit"]')) {
                                container = curr;
                                break;
                            }
                        }
                    }
                    const root = container || document;
                    const cmtBtn = root.querySelector(
                        'div[aria-label="Viết bình luận"], div[aria-label="Viết bình luận..."], ' +
                        'div[aria-label*="Bình luận"], div[aria-label*="bình luận"], ' +
                        'div[role="button"][aria-label*="Bình luận"], span[role="button"][aria-label*="Bình luận"]'
                    );
                    if (cmtBtn) {
                        cmtBtn.scrollIntoView({block: 'center', inline: 'nearest', behavior: 'instant'});
                        cmtBtn.click();
                        return true;
                    }
                    return false;
                """, like_btn_element)

                if open_res:
                    clicked_open = True
            except Exception:
                pass

            if not clicked_open:
                cmt_btns = self.driver.find_elements(
                    By.XPATH,
                    '//div[@aria-label="Viết bình luận" or @aria-label="Viết bình luận..." or contains(@aria-label, "Viết bình luận")]'
                )
                for b in cmt_btns:
                    if b.is_displayed():
                        self.driver.execute_script("arguments[0].scrollIntoView({block: 'center', inline: 'nearest', behavior: 'instant'});", b)
                        time.sleep(0.3)
                        b.click()
                        clicked_open = True
                        break

            time.sleep(random.uniform(1.0, 1.8))

            # 2. Tìm ô nhập textbox: //div[@role="textbox"]
            tb_el = None
            for _ in range(6):
                textboxes = self.driver.find_elements(By.XPATH, '//div[@role="textbox"]')
                for tb in textboxes:
                    if tb.is_displayed():
                        tb_el = tb
                        break
                if tb_el:
                    break
                time.sleep(0.35)

            if not tb_el:
                self.log(f"   ⚠️ Không tìm thấy ô nhập bình luận (role=textbox) cho bài của [{author_name}].")
                return False

            self.driver.execute_script("arguments[0].scrollIntoView({block: 'center', inline: 'nearest', behavior: 'instant'});", tb_el)
            time.sleep(0.35)
            try:
                tb_el.click()
            except Exception:
                self.driver.execute_script("arguments[0].click();", tb_el)
            time.sleep(0.4)

            # 3. Gõ nội dung bình luận mô phỏng người thật gõ phím
            for ch in cmt_text:
                tb_el.send_keys(ch)
                time.sleep(random.uniform(0.04, 0.12))
            time.sleep(random.uniform(0.8, 1.5))

            # 4. Đăng bình luận: Tìm nút //div[@aria-label="Đăng bình luận"] hoặc gửi phím ENTER
            posted = False
            send_btns = self.driver.find_elements(
                By.XPATH,
                '//div[@aria-label="Đăng bình luận" or @aria-label="Đăng" or @aria-label="Comment"]'
            )
            for sb in send_btns:
                if sb.is_displayed():
                    try:
                        sb.click()
                        posted = True
                        break
                    except Exception:
                        self.driver.execute_script("arguments[0].click();", sb)
                        posted = True
                        break

            if not posted:
                tb_el.send_keys(Keys.ENTER)
                posted = True

            # 5. KHI CMT XONG BẤM GỬI CHỜ 5 - 10 GIÂY ĐỂ ĐỢI CMT ĐƯỢC ĐĂNG THEO YÊU CẦU
            wait_post = random.uniform(5.0, 10.0)
            self.log(f"   ⏳ Đã bấm gửi, đang đợi {wait_post:.1f}s để bình luận được đăng hoàn tất...")
            time.sleep(wait_post)
            self.log(f"   💬 ĐÃ BÌNH LUẬN VÀO BÀI VIẾT CỦA [{author_name}]: \"{cmt_text}\"")

            # 6. Đóng bài đó (nếu bài viết mở dạng modal / dialog) để tiếp tục lướt Feed sạch sẽ
            try:
                dialogs = self.driver.find_elements(By.XPATH, "//div[@role='dialog']")
                for dlg in dialogs:
                    if dlg.is_displayed():
                        close_btns = dlg.find_elements(
                            By.XPATH,
                            ".//div[@aria-label='Đóng' or @aria-label='Close' or @aria-label='Đóng bài viết' or @aria-label='Đóng xem trước']"
                        )
                        for cb in close_btns:
                            if cb.is_displayed():
                                cb.click()
                                time.sleep(0.8)
                                break
                        break
                self.log(f"   ❎ Đã đóng bài viết của [{author_name}], tiếp tục lướt Feed...")
            except Exception:
                pass

            return True
        except Exception as e:
            self.log(f"   ⚠️ Lỗi bình luận bài viết của [{author_name}]: {e}")
            return False

    def _random_like_normal_post(self):
        """Tương tác phụ khi lướt bảng tin: Ngẫu nhiên Thả Tim ❤️ (70%) hoặc Like 👍 (30%) bài viết đang hiển thị"""
        try:
            posts = self._scan_posts_with_poster_names()
            available = [
                p for p in posts
                if p.get("likeBtn") and (p.get("postKey") not in self.reacted_posts)
            ]
            if not available:
                return

            chosen = random.choice(available[:3])
            like_btn = chosen["likeBtn"]
            author = chosen.get("primaryAuthor") or "bài viết trên bảng tin"
            post_key = chosen.get("postKey") or str(time.time())
            self.reacted_posts.add(post_key)

            if random.random() < 0.70:
                ok = self._react_love(like_btn)
                if ok:
                    self.log(f"   ❤️ Đã Thả Tim dạo bài viết của [{author}]!")
                else:
                    self.log(f"   👍 Đã thả Like dạo bài viết của [{author}]!")
            else:
                ok = self._react_like(like_btn)
                if ok:
                    self.log(f"   👍 Đã thả Like dạo bài viết của [{author}]!")
            time.sleep(1.5)
        except Exception:
            pass

    # =========================================================================
    # BƯỚC 2: QUÉT NHÓM ĐÃ THAM GIA -> LẤY NGẪU NHIÊN N NHÓM -> LẦN LƯỢT ĐĂNG BÀI
    # =========================================================================

    def _open_group_composer(self) -> bool:
        self.dismiss_alerts()
        clicked = self.driver.execute_script("""
            const prompts = ['Bạn viết gì đi...', 'Tạo bài viết công khai...', 'Tạo bài viết...', 'Viết gì đó...', 'Tạo bài viết ẩn danh'];
            const allSpans = Array.from(document.querySelectorAll('span, div')).filter(e => {
                const t = (e.textContent || '').trim();
                return e.children.length === 0 && prompts.some(p => t.includes(p));
            });

            if (allSpans.length > 0) {
                let target = allSpans[0];
                target.scrollIntoView({block: 'center'});
                let p = target;
                while (p && p !== document.body) {
                    if (p.getAttribute('role') === 'button') {
                        p.click();
                        return true;
                    }
                    p = p.parentElement;
                }
                target.click();
                return true;
            }

            const photoSpans = Array.from(document.querySelectorAll('span, div')).filter(e => 
                e.children.length === 0 && (e.textContent || '').trim() === 'Ảnh/video'
            );
            for (const span of photoSpans) {
                let p = span;
                while (p && p !== document.body) {
                    if (p.getAttribute('role') === 'button') {
                        p.scrollIntoView({block: 'center'});
                        p.click();
                        return true;
                    }
                    p = p.parentElement;
                }
            }
            return false;
        """)

        if clicked:
            time.sleep(3)
            tb, d = self._find_active_dialog_and_textbox()
            if tb or d:
                return True

        for offset_y in [250, 450, 100]:
            self.driver.execute_script(f"window.scrollTo(0, {offset_y});")
            time.sleep(1)
            clicked = self.driver.execute_script("""
                const prompts = ['Bạn viết gì đi', 'Tạo bài viết', 'Viết gì đó'];
                const spans = Array.from(document.querySelectorAll('span, div')).filter(e => 
                    e.children.length === 0 && e.textContent && prompts.some(p => e.textContent.includes(p))
                );
                if (spans.length === 0) return false;
                let target = spans[0];
                target.scrollIntoView({block: 'center'});
                let p = target;
                while (p && p !== document.body) {
                    if (p.getAttribute('role') === 'button') {
                        p.click();
                        return true;
                    }
                    p = p.parentElement;
                }
                target.click();
                return true;
            """)
            if clicked:
                time.sleep(3)
                tb, d = self._find_active_dialog_and_textbox()
                if tb or d:
                    return True

        return False

    def _paste_text_to_composer(self, content: str, composer_dialog=None) -> bool:
        try:
            container = composer_dialog if composer_dialog else self.driver
            textboxes = container.find_elements(By.XPATH, './/div[@role="textbox" or @contenteditable="true"]')
            if not textboxes:
                textboxes = self.driver.find_elements(By.XPATH, '//div[@role="textbox" or @contenteditable="true"]')
            if not textboxes:
                return False

            textbox = textboxes[0]
            self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'}); arguments[0].focus();", textbox)
            time.sleep(0.5)
            try:
                textbox.click()
            except Exception:
                pass
            time.sleep(0.3)

            with CLIPBOARD_LOCK:
                pyperclip.copy(content)
                time.sleep(0.25)
                textbox.send_keys(Keys.CONTROL, 'v')
                time.sleep(0.4)

            time.sleep(1.2)

            if not (textbox.text or "").strip():
                lines = content.split("\n")
                for i, line in enumerate(lines):
                    if line:
                        textbox.send_keys(line)
                    if i < len(lines) - 1:
                        textbox.send_keys(Keys.SHIFT, Keys.ENTER)
                time.sleep(1)

            return True
        except Exception as e:
            self.log(f"   ⚠️ Lỗi dán nội dung: {e}")
            return False

    def _upload_group_photo(self, image_path: str, dialog_element=None) -> bool:
        try:
            abs_path = os.path.abspath(image_path)
            container = dialog_element if dialog_element else self.driver

            file_inputs = container.find_elements(By.XPATH, './/input[@type="file"]')
            if not file_inputs:
                file_inputs = self.driver.find_elements(By.XPATH, '//div[@role="dialog"]//input[@type="file"]')
            if not file_inputs:
                file_inputs = self.driver.find_elements(By.XPATH, '//input[@type="file"]')

            # Nếu chưa có input file trong DOM, thử bấm nút Ảnh/video bên trong dialog để mở vùng thả ảnh
            if not file_inputs:
                photo_triggers = container.find_elements(
                    By.XPATH,
                    './/div[@aria-label="Ảnh/video" or @aria-label="Photo/video" or contains(@aria-label, "Ảnh/video")] | '
                    './/span[contains(text(), "Ảnh/video")]/ancestor::div[@role="button"][1]'
                )
                if photo_triggers:
                    try:
                        self.driver.execute_script("arguments[0].click();", photo_triggers[0])
                        time.sleep(1.5)
                    except Exception:
                        pass
                    file_inputs = container.find_elements(By.XPATH, './/input[@type="file"]')
                    if not file_inputs:
                        file_inputs = self.driver.find_elements(By.XPATH, '//input[@type="file"]')

            if file_inputs:
                file_inputs[0].send_keys(abs_path)
                self.log(f"   📤 Đã đính kèm ảnh poster: {os.path.basename(image_path)}")
                self.log("   ⏳ Đang chờ 5-8 giây để ảnh tải lên và load bản xem trước...")
                time.sleep(6.0)
                return True
            else:
                self.log("   ⚠️ Không tìm thấy input file để đính kèm ảnh!")
                return False
        except Exception as e:
            self.log(f"   ⚠️ Lỗi upload ảnh nhóm: {e}")
            return False

    def _find_active_group_dialog(self):
        dialogs = self.driver.find_elements(By.XPATH, '//div[@role="dialog"]')
        for d in dialogs:
            try:
                tbs = d.find_elements(By.XPATH, './/div[@role="textbox" or @contenteditable="true"]')
                if tbs:
                    return d
            except Exception:
                continue
        try:
            return self.driver.execute_script("""
                const dialogs = Array.from(document.querySelectorAll('[role="dialog"]'));
                for (const d of dialogs) {
                    if (d.querySelector('[role="textbox"], [contenteditable="true"]')) {
                        return d;
                    }
                }
                return null;
            """)
        except Exception:
            return None

    def run_step2_post_to_selected_groups(self, output_dir: str, num_groups: int = 5) -> bool:
        self.log(f"🚀 Bắt đầu BƯỚC 2: Quét toàn bộ nhóm đã tham gia -> Chọn ngẫu nhiên {num_groups} nhóm -> Lần lượt đăng bài...")
        self.dismiss_alerts()

        joins_url = "https://www.facebook.com/groups/joins/?nav_source=tab"
        self.log(f"   🌐 Đang truy cập trang quản lý nhóm đã tham gia: {joins_url}")
        self.driver.get(joins_url)
        time.sleep(5)
        self.dismiss_alerts()

        self.log("   📜 Đang cuộn trang để tải toàn bộ danh sách nhóm đã tham gia...")
        prev_count = 0
        consecutive_same = 0
        all_groups = []

        for _ in range(15):
            if self._should_stop():
                return False
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(1.8)

            links = self.driver.execute_script("""
                const anchors = Array.from(document.querySelectorAll('a[href*="/groups/"]'));
                const systemKeywords = ['/joins', '/feed', '/discover', '/create', '/notifications', '/categories', '/user/', '/buy_sell_group', '/profile'];
                const groups = new Set();
                for (const a of anchors) {
                    const href = a.getAttribute('href') || '';
                    const clean = href.split('?')[0].replace(/\\/$/, '');
                    if (clean.includes('/groups/')) {
                        const isSystem = systemKeywords.some(k => clean.includes(k));
                        if (!isSystem) {
                            const parts = clean.split('/groups/');
                            if (parts.length > 1 && parts[1].length > 0 && !parts[1].includes('/')) {
                                groups.add(clean + '/');
                            }
                        }
                    }
                }
                return Array.from(groups);
            """)

            current_count = len(links) if links else 0
            if current_count > 0:
                all_groups = links

            if current_count == prev_count and current_count > 0:
                consecutive_same += 1
                if consecutive_same >= 3:
                    self.log(f"   ✅ Đã nạp toàn bộ danh sách: phát hiện {current_count} nhóm đã tham gia.")
                    break
            else:
                consecutive_same = 0
            prev_count = current_count

        if not all_groups:
            self.log("❌ Không tìm thấy nhóm nào đã tham gia trên tài khoản!")
            return False

        actual_num = min(num_groups, len(all_groups))
        selected_groups = random.sample(all_groups, actual_num)
        self.log(f"\n🎲 ĐÃ CHỌN NGẪU NHIÊN {actual_num} NHÓM ĐỂ ĐĂNG BÀI:")
        for idx, g in enumerate(selected_groups, 1):
            self.log(f"   👉 [{idx}/{actual_num}] {g}")

        success_count = 0
        for idx, group_url in enumerate(selected_groups, 1):
            if self._should_stop():
                break
            self.log("\n──────────────────────────────────────────────────")
            self.log(f"📌 [{idx}/{actual_num}] TIẾN HÀNH ĐĂNG BÀI VÀO NHÓM: {group_url}")

            try:
                self.driver.get(group_url)
                time.sleep(random.uniform(4.5, 6.5))
                self.dismiss_alerts()

                self.smooth_scroll(random.randint(150, 300))
                time.sleep(1.5)

                content, img_path = ContentGenerator.get_group_content(output_dir)
                if not content:
                    self.log(f"   ⚠️ Không lấy được nội dung đăng bài từ {output_dir}")
                    continue

                self.log(f"   📄 Nội dung bài đăng:\n{content[:100].strip()}...")
                if img_path:
                    self.log(f"   🖼️ Ảnh poster đính kèm: {os.path.basename(img_path)}")

                composer_opened = self._open_group_composer()
                if not composer_opened:
                    self.log(f"   ⚠️ Không mở được ô tạo bài viết trong nhóm {group_url}")
                    continue

                dialog = None
                for _ in range(6):
                    dialog = self._find_active_group_dialog()
                    if dialog:
                        break
                    time.sleep(1)

                if not dialog:
                    self.log("   ⚠️ Không tìm thấy khung thoại tạo bài viết!")
                    continue

                if img_path and os.path.exists(img_path):
                    self._upload_group_photo(img_path, dialog_element=dialog)

                pasted = self._paste_text_to_composer(content, composer_dialog=dialog)
                if not pasted:
                    self.log("   ⚠️ Không dán được văn bản vào ô soạn thảo!")
                    self._close_open_dialog_safely()
                    continue

                self.log("   🚀 Đang bấm nút 'Đăng' bài vào nhóm...")
                post_btn = None
                post_btns = dialog.find_elements(
                    By.XPATH,
                    './/div[@aria-label="Đăng"] | .//*[text()="Đăng"]/ancestor::div[@role="button"][1]'
                )
                if not post_btns:
                    post_btns = self.driver.find_elements(
                        By.XPATH,
                        '//div[@role="dialog"]//div[@aria-label="Đăng"] | //div[@role="dialog"]//*[text()="Đăng"]/ancestor::div[@role="button"][1]'
                    )
                if post_btns:
                    post_btn = post_btns[0]
                else:
                    post_btn = self._find_post_button(dialog)

                if post_btn:
                    self._click_element_with_cursor(post_btn)
                    self.log("   ⏳ Đã click nút Đăng với chuột ảo, đang chờ Facebook xử lý...")

                    posted = False
                    for _ in range(1, 26):
                        time.sleep(1)
                        self.dismiss_alerts()

                        remaining_tbs = self.driver.find_elements(By.XPATH, '//div[@role="dialog"]//div[@role="textbox"]')
                        if not remaining_tbs:
                            posted = True
                            break

                        approved_text = self.driver.execute_script("""
                            const t = document.body.innerText || '';
                            return t.includes('chờ phê duyệt') || t.includes('đang chờ quản trị viên');
                        """)
                        if approved_text:
                            posted = True
                            self.log("   ℹ️ Bài viết đã được gửi vào nhóm (Đang chờ Quản trị viên phê duyệt).")
                            self._close_open_dialog_safely()
                            break

                    if posted:
                        success_count += 1
                        self.log(f"   🎉 ĐÃ ĐĂNG BÀI THÀNH CÔNG VÀO NHÓM [{idx}/{actual_num}]!")
                    else:
                        self.log("   ⚠️ Hộp thoại chưa đóng sau 25s, đóng an toàn...")
                        self._close_open_dialog_safely()
                else:
                    self.log("   ⚠️ Không tìm thấy nút Đăng!")
                    self._close_open_dialog_safely()

                if self.target_users and not self._should_stop():
                    self.log("   🔍 Bắt đầu lướt nhóm tìm và tương tác bài của người trong danh sách mục tiêu...")
                    time.sleep(2.0)
                    group_interact_count = 0

                    # Quét ngay phần đầu nhóm trước khi cuộn
                    if self._scan_and_react_target_posts(context_name=f"Nhóm [{idx}/{actual_num}]"):
                        group_interact_count += 1

                    scroll_rounds = random.randint(5, 8)

                    for _ in range(1, scroll_rounds + 1):
                        if self._should_stop():
                            break
                        scroll_down = random.randint(450, 680)
                        self.smooth_scroll(scroll_down)
                        read_time = random.uniform(2.2, 3.6)
                        time.sleep(read_time)

                        reacted = self._scan_and_react_target_posts(context_name=f"Nhóm [{idx}/{actual_num}]")
                        if reacted:
                            group_interact_count += 1

                        self._try_browse_carousel()

                        if random.random() < 0.30:
                            scroll_up = -random.randint(120, 220)
                            self.smooth_scroll(scroll_up)
                            time.sleep(1.2)
                            if self._scan_and_react_target_posts(context_name=f"Nhóm [{idx}/{actual_num}]"):
                                group_interact_count += 1
                            self.smooth_scroll(-scroll_up + random.randint(40, 80))
                            time.sleep(0.8)

                    if group_interact_count > 0:
                        self.log(f"   🎯 Đã tìm thấy và tương tác thành công {group_interact_count} bài của người trong danh sách tại nhóm này!")
                    else:
                        self.log("   ℹ️ Không phát hiện bài mới của người trong danh sách tại lượt lướt nhóm này.")

                if idx < actual_num and not self._should_stop():
                    rest_time = random.uniform(5.0, 10.0)
                    self.log(f"   ☕ Nghỉ ngơi {rest_time:.1f}s trước khi chuyển sang nhóm tiếp theo...")
                    time.sleep(rest_time)

            except Exception as e:
                self.log(f"   ⚠️ Lỗi khi đăng bài vào nhóm {group_url}: {e}")
                self._close_open_dialog_safely()

        self.log(f"\n🏁 KẾT THÚC BƯỚC 2: Đã đăng thành công {success_count}/{actual_num} nhóm!")
        return success_count > 0

    def run_step2_post_and_share_to_groups(self, output_dir: str, max_share_groups: int = 5) -> bool:
        return self.run_step2_post_to_selected_groups(output_dir=output_dir, num_groups=max_share_groups)

    # =========================================================================
    # BƯỚC 3: VÀO NHÓM LƯỚT VÀ CHỈ TƯƠNG TÁC BÀI DO TARGET USER ĐĂNG
    # =========================================================================

    def run_step3_group_interact(self, max_groups: int = 2, scroll_per_group: int = 6):
        self.log("🚀 Bắt đầu BƯỚC 3: Vào Nhóm tương tác (CHỈ Thả Tim ❤️ / Like 👍 bài của người trong danh sách)...")
        self.dismiss_alerts()

        joined_groups = self._get_all_joined_groups(max_scrolls=5)
        if not joined_groups:
            self.log("ℹ️ Không lấy được danh sách nhóm, sẽ lướt feed nhóm chung (/groups/feed/)...")
            joined_groups = ["https://www.facebook.com/groups/feed/"]

        random.shuffle(joined_groups)
        groups_to_visit = joined_groups[:max_groups]

        for idx, g_url in enumerate(groups_to_visit):
            if self._should_stop():
                break
            self.log(f"👥 Đang ghé thăm Nhóm ({idx + 1}/{len(groups_to_visit)}): {g_url}")
            self.dismiss_alerts()
            self.driver.get(g_url)
            time.sleep(5)

            target_in_group_found = 0

            # Quét ngay đầu trang nhóm trước khi cuộn
            if self._scan_and_react_target_posts_in_group():
                target_in_group_found += 1

            for _ in range(scroll_per_group):
                if self._should_stop():
                    break
                scroll_down = random.randint(450, 680)
                self.smooth_scroll(scroll_down)
                time.sleep(random.uniform(2.2, 3.6))

                found = self._scan_and_react_target_posts_in_group()
                if found:
                    target_in_group_found += 1

                if random.random() < 0.35:
                    self.smooth_scroll(-random.randint(120, 220))
                    time.sleep(1.3)
                    if self._scan_and_react_target_posts_in_group():
                        target_in_group_found += 1

            self.log(f"   📊 Trong nhóm này: Đã tương tác {target_in_group_found} bài của người trong danh sách.")

        self.log("✅ Hoàn thành BƯỚC 3: Tương tác bài viết trong Nhóm!")

    def _scan_and_react_target_posts_in_group(self) -> bool:
        return self._scan_and_react_target_posts(context_name="Nhóm")

    def _get_all_joined_groups(self, max_scrolls: int = 5) -> List[str]:
        self.dismiss_alerts()
        self.driver.get("https://www.facebook.com/groups/joins/")
        time.sleep(4)

        for _ in range(max_scrolls):
            if self._should_stop():
                break
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(2)

        links = self.driver.find_elements(By.TAG_NAME, "a")
        group_links = set()
        system_keywords = ["/joins", "/feed", "/discover", "/create", "/notifications", "/categories"]

        for a in links:
            try:
                href = a.get_attribute("href")
                if href and "/groups/" in href:
                    clean_url = href.split("?")[0].rstrip("/")
                    if not any(k in clean_url for k in system_keywords):
                        parts = clean_url.split("/groups/")
                        if len(parts) > 1 and len(parts[1]) > 0:
                            group_links.add(clean_url + "/")
            except Exception:
                continue

        unique_list = list(group_links)
        self.log(f"✅ Đã nạp danh sách {len(unique_list)} Nhóm đã tham gia!")
        return unique_list

    # =========================================================================
    # CÁC HÀM TIỆN ÍCH DÙNG CHUNG
    # =========================================================================

    def _find_active_dialog_and_textbox(self) -> Tuple[Optional[Any], Optional[Any]]:
        dialogs = self.driver.find_elements(By.XPATH, '//div[@role="dialog"]')
        for d in reversed(dialogs):
            try:
                tbs = d.find_elements(By.XPATH, './/div[@role="textbox" or @contenteditable="true"]')
                for tb in reversed(tbs):
                    label = (tb.get_attribute("aria-label") or tb.get_attribute("aria-placeholder") or "").lower()
                    if "bình luận" in label or "comment" in label:
                        continue
                    return tb, d
            except Exception:
                continue

        all_tbs = self.driver.find_elements(By.XPATH, '//div[@role="textbox" or @contenteditable="true"]')
        for tb in reversed(all_tbs):
            try:
                label = (tb.get_attribute("aria-label") or tb.get_attribute("aria-placeholder") or "").lower()
                if "bình luận" in label or "comment" in label:
                    continue
                parent_dialog = None
                try:
                    parent_dialog = tb.find_element(By.XPATH, './ancestor::div[@role="dialog"][1]')
                except Exception:
                    pass
                return tb, parent_dialog
            except Exception:
                continue

        return None, None

    def _find_post_button(self, dialog_element):
        container = dialog_element if dialog_element else self.driver
        post_btns = container.find_elements(
            By.XPATH,
            './/div[@aria-label="Đăng" or @aria-label="Post"]'
        )
        for b in post_btns:
            if b.get_attribute("aria-disabled") != "true":
                return b

        spans = container.find_elements(By.XPATH, './/span[text()="Đăng" or text()="Post"]')
        for s in spans:
            try:
                parent_btn = s.find_element(By.XPATH, './ancestor::div[@role="button"][1]')
                if parent_btn.get_attribute("aria-disabled") != "true":
                    return parent_btn
            except Exception:
                pass
            return s
        return None

    def _close_open_dialog_safely(self):
        try:
            self.dismiss_alerts()
            close_btns = self.driver.find_elements(By.XPATH, '//div[@aria-label="Đóng" or @aria-label="Close"]')
            if close_btns:
                self.driver.execute_script("arguments[0].click();", close_btns[0])
                time.sleep(1.5)
                discard_btns = self.driver.find_elements(
                    By.XPATH,
                    '//div[@aria-label="Bỏ" or @aria-label="Discard"] | //span[text()="Bỏ" or text()="Discard"]'
                )
                if discard_btns:
                    self.driver.execute_script("arguments[0].click();", discard_btns[0])
                    time.sleep(1)
            self.dismiss_alerts()
        except Exception:
            pass
