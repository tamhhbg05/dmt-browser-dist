/**
 * DMT Browser — Module Tự Động Hóa Facebook (FB Automation Plugin UI)
 * Thiết kế chuẩn Enterprise (Ant Design / GPMLogin Style): Gọn gàng, khoa học,
 * bảng dữ liệu căn cột sắc nét, hỗ trợ kéo chuột quét chọn (Marquee) & nhật ký phân màu trực quan.
 */
(function () {
  const API_BASE = '/api/fb-automation';

  let fbConfig = null;
  let dmtProfiles = [];
  let gpmApiProfiles = [];
  let contentInfo = { txt_count: 0, img_count: 0, pairs_preview: [] };
  let campaignsInfo = {};
  let editingCampaignId = null; // ID chiến dịch đang mở bảng chọn Profile
  let campaignModalSearch = '';
  let runtimeState = {
    is_running: false,
    current_engine: 'dmt',
    cycle: 1,
    running_count: 0,
    completed_count: 0,
    total_count: 0,
    status_text: 'Sẵn sàng',
    countdown_text: 'Chưa kích hoạt',
    can_skip_wait: false,
    profile_states: {},
  };

  let logOffset = 0;
  let allLogs = [];
  let pollTimer = null;
  let currentSubTab = 'dash'; // 'dash' | 'profiles' | 'settings' | 'logs'
  let profileConfigTab = 'dmt'; // 'dmt' | 'gpm'

  // Bộ lọc & trạng thái quét chọn
  let dashSearchQuery = '';
  let dashFilterFolder = 'ALL';
  let dmtSearchQuery = '';
  let dmtFilterFolder = 'ALL';
  let gpmSearchQuery = '';
  let gpmEditMode = 'list'; // 'list' | 'text'

  let fbDragSelectEnabled = true;
  let isMarqueeDragging = false;
  let lastClickedIdxDash = -1;
  let lastClickedIdxDmt = -1;
  let lastClickedIdxGpm = -1;
  let lastRenderedDashSignature = '';

  function esc(str) {
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function notify(msg, type = 'info') {
    if (typeof window.showToast === 'function') {
      window.showToast(msg, type);
    } else {
      console.log(`[FB-Auto][${type}] ${msg}`);
    }
  }

  // ==================== 1. KHỞI TẠO SIDEBAR & VIEW CONTAINER ====================
  function initPluginUI() {
    const sidebarNav =
      document.getElementById('sidebarPluginNav') ||
      document.getElementById('sidebarMainNav') ||
      document.querySelector('aside nav');
    const mainEl = document.querySelector('main');
    if (!sidebarNav || !mainEl) return;

    if (!document.getElementById('navFbAuto')) {
      const btn = document.createElement('button');
      btn.id = 'navFbAuto';
      btn.type = 'button';
      btn.className =
        'w-full px-3 py-2.5 rounded-lg text-xs font-medium flex items-center justify-between text-slate-300 hover:bg-[#1e2d47]/70 hover:text-white transition whitespace-nowrap';
      btn.innerHTML = `
        <span class="flex items-center gap-2.5 min-w-0">
          <i class="fa-brands fa-facebook w-4 text-center text-sky-400 shrink-0"></i>
          <span class="truncate">Auto Đăng Bài FB</span>
        </span>
        <span id="fbSidebarStatusBadge" class="text-[10px] px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300 mono shrink-0">IDLE</span>
      `;
      btn.addEventListener('click', () => switchMainView('fb_auto'));
      sidebarNav.appendChild(btn);
    }

    let viewContainer = document.getElementById('fbAutoWorkspace');
    if (!viewContainer) {
      viewContainer = document.createElement('div');
      viewContainer.id = 'fbAutoWorkspace';
      viewContainer.className = 'hidden flex-1 flex flex-col min-h-0 overflow-hidden bg-[#f4f6f9] dark:bg-[#0b0f19]';
      viewContainer.innerHTML = buildWorkspaceHTML();
      mainEl.appendChild(viewContainer);
    }

    patchMainViewSwitcher();
    bindEvents();
    initFbMarqueeSelection();
    fetchState(true);
    checkGpmStatus(false);

    if (pollTimer) clearInterval(pollTimer);
    pollTimer = setInterval(() => fetchState(false), 1200);
  }

  function patchMainViewSwitcher() {
    const navProfiles = document.getElementById('navProfiles');
    if (navProfiles && !navProfiles.dataset.fbPatched) {
      navProfiles.dataset.fbPatched = '1';
      navProfiles.addEventListener('click', () => {
        if (window.activeMainWorkspace === 'fb_auto') {
          window.switchMainView('profiles');
        }
      });
    }

    const origSelectFolder = window.selectFolder;
    if (typeof origSelectFolder === 'function' && !origSelectFolder._fbWrapped) {
      const wrappedSelectFolder = function (f) {
        if (window.activeMainWorkspace === 'fb_auto') {
          window.switchMainView('profiles');
        }
        return origSelectFolder.apply(this, arguments);
      };
      wrappedSelectFolder._fbWrapped = true;
      window.selectFolder = wrappedSelectFolder;
    }

    const origSelectRunning = window.selectRunningProfiles;
    if (typeof origSelectRunning === 'function' && !origSelectRunning._fbWrapped) {
      const wrappedSelectRunning = function () {
        if (window.activeMainWorkspace === 'fb_auto') {
          window.switchMainView('profiles');
        }
        return origSelectRunning.apply(this, arguments);
      };
      wrappedSelectRunning._fbWrapped = true;
      window.selectRunningProfiles = wrappedSelectRunning;
    }

    window.fbAutoOnViewActivated = function () {
      fetchState(false);
    };
  }

    const sendProfilesHandler = async function (profileIds) {
      if (typeof window.switchMainView === 'function') {
        window.switchMainView('fb_auto');
      }
      if (Array.isArray(profileIds) && profileIds.length > 0) {
        if (fbConfig) {
          fbConfig.engine = 'dmt';
          fbConfig.dmt_profile_ids = profileIds;
        }
        await saveConfigWithToast(
          { engine: 'dmt', dmt_profile_ids: profileIds },
          `Đã nạp ${profileIds.length} Profile DMT để chuẩn bị chạy Auto FB!`
        );
      }
    };
    window.openFbAutoWithProfiles = sendProfilesHandler;
    window.sendSelectedProfilesToFbAuto = sendProfilesHandler;

  // ==================== 2. XÂY DỰNG GIAO DIỆN HTML CHUẨN ENTERPRISE ====================
  function buildWorkspaceHTML() {
    return `
      <!-- THANH ĐIỀU HƯỚNG PHỤ & CHỌN NGUỒN PROFILE (GỌN GÀNG, RÀNH MẠCH) -->
      <div class="px-6 py-2.5 bg-white dark:bg-[#111827] border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <!-- 4 Sub-tabs -->
        <div class="flex items-center gap-1 bg-slate-100 dark:bg-slate-800/80 p-1 rounded-lg border border-slate-200/70 dark:border-slate-700/70">
          <button type="button" data-fb-tab="dash" class="fb-tab-btn px-3.5 py-1.5 rounded-md text-xs font-semibold flex items-center gap-2 bg-[#1677ff] text-white shadow-xs transition">
            <i class="fa-solid fa-bolt"></i>
            <span>Bảng điều khiển</span>
          </button>
          <button type="button" data-fb-tab="profiles" class="fb-tab-btn px-3.5 py-1.5 rounded-md text-xs font-medium flex items-center gap-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition">
            <i class="fa-solid fa-layer-group"></i>
            <span>Chiến Dịch & Nguồn Bài</span>
          </button>
          <button type="button" data-fb-tab="settings" class="fb-tab-btn px-3.5 py-1.5 rounded-md text-xs font-medium flex items-center gap-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition">
            <i class="fa-solid fa-sliders"></i>
            <span>Cấu hình kịch bản</span>
          </button>
          <button type="button" data-fb-tab="logs" class="fb-tab-btn px-3.5 py-1.5 rounded-md text-xs font-medium flex items-center gap-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition">
            <i class="fa-solid fa-terminal"></i>
            <span>Nhật ký chi tiết</span>
          </button>
        </div>

        <!-- Chuyển đổi chế độ DMT Browser / GPMLogin -->
        <div class="flex items-center gap-2.5">
          <div class="flex items-center bg-slate-100 dark:bg-slate-800/80 p-1 rounded-lg border border-slate-200/70 dark:border-slate-700/70">
            <span class="text-[11px] font-medium text-slate-500 dark:text-slate-400 px-2">Chế độ chạy:</span>
            <button type="button" id="fbEngineBtnDmt" class="px-3 py-1 rounded-md text-xs font-semibold flex items-center gap-1.5 bg-[#1677ff] text-white shadow-xs transition">
              <i class="fa-solid fa-shield-halved"></i>
              <span>DMT Browser</span>
              <span id="fbEngineCountDmt" class="px-1.5 py-0.2 rounded bg-white/20 text-[10px] mono">0</span>
            </button>
            <button type="button" id="fbEngineBtnGpm" class="px-3 py-1 rounded-md text-xs font-medium flex items-center gap-1.5 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition">
              <i class="fa-solid fa-globe"></i>
              <span>GPMLogin</span>
              <span id="fbEngineCountGpm" class="px-1.5 py-0.2 rounded bg-slate-200 dark:bg-slate-700 text-[10px] mono">0</span>
            </button>
          </div>

          <button type="button" id="fbGpmStatusBadge" title="Bấm để kiểm tra kết nối GPMLogin API và đồng bộ danh sách" class="px-2.5 py-1.5 rounded-lg text-[11px] font-medium border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center gap-1.5 hover:bg-slate-50 transition">
            <span class="w-2 h-2 rounded-full bg-amber-400"></span>
            <span>GPM API</span>
          </button>
        </div>
      </div>

      <!-- ==================== TRANG 1: BẢNG ĐIỀU KHIỂN (DASHBOARD) ==================== -->
      <div id="fbPageDash" class="flex-1 flex flex-col gap-3 px-6 py-3.5 min-h-0 overflow-hidden">
        <!-- THANH ĐIỀU KHIỂN TRUNG TÂM & KPI (Gộp gọn trong 1 dải chuẩn hiện đại) -->
        <div id="fbStartCard" class="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs shrink-0 overflow-hidden">
          <div class="px-4 py-3 flex flex-wrap items-center justify-between gap-4">
            <!-- Cụm Trái: Nút Bắt đầu / Dừng + Tùy chọn Lặp lại + Thư mục nguồn -->
            <div class="flex flex-wrap items-center gap-3">
              <button type="button" id="fbBtnStartStop" class="px-5 py-2.5 rounded-lg bg-[#1677ff] hover:bg-[#0958d9] text-white font-bold text-xs shadow-sm flex items-center gap-2 transition cursor-pointer">
                <i class="fa-solid fa-play"></i>
                <span>BẮT ĐẦU CHẠY AUTO</span>
              </button>

              <!-- Tùy chọn: Tương tác 2 chiều nick-page -->
              <label class="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-pink-50/80 dark:bg-pink-950/30 border border-pink-200/80 dark:border-pink-800/60 text-xs cursor-pointer select-none hover:bg-pink-100/70 dark:hover:bg-pink-900/40 transition" title="Quy trình: Mở Accounts Center -> Bước 1 tương tác Nick -> Chuyển sang Page -> Bước 1 tương tác Page -> Bước 2 & 3 (Nhóm)">
                <input id="fbDashTwoWayToggle" type="checkbox" class="w-3.5 h-3.5 accent-pink-600 rounded cursor-pointer" />
                <span class="font-semibold text-pink-700 dark:text-pink-300 flex items-center gap-1.5">
                  <i class="fa-solid fa-arrows-left-right text-[11px]"></i>
                  <span>Tương tác 2 chiều nick-page</span>
                </span>
              </label>

              <!-- Hẹn giờ lặp lại -->
              <div class="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/70 text-xs">
                <label class="flex items-center gap-1.5 cursor-pointer select-none font-semibold text-slate-700 dark:text-slate-200">
                  <input id="fbDashRepeatToggle" type="checkbox" class="w-3.5 h-3.5 accent-[#1677ff] rounded cursor-pointer" />
                  <span>Tự lặp lại sau</span>
                </label>
                <input id="fbDashRepeatDelayInput" type="number" min="1" max="360" value="30" class="w-12 px-1.5 py-0.5 rounded bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-center font-bold mono text-xs focus:border-[#1677ff] focus:outline-none" />
                <span class="text-slate-500 dark:text-slate-400">phút</span>
                <button type="button" id="fbBtnSkipWait" disabled class="ml-1 px-2 py-0.5 rounded bg-indigo-600 hover:bg-indigo-500 disabled:opacity-35 disabled:pointer-events-none text-white text-[11px] font-semibold transition">
                  Chạy ngay
                </button>
              </div>

              <!-- Thư mục bài đăng mặc định & Chiến dịch -->
              <div class="hidden xl:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/70 text-xs max-w-xs">
                <i class="fa-regular fa-folder-open text-amber-500 shrink-0"></i>
                <span id="fbShortContentPath" class="text-[11px] text-slate-600 dark:text-slate-300 mono truncate max-w-[130px]" title="">Chưa chọn...</span>
                <span id="fbContentCountBadge" class="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-semibold shrink-0">0 bài</span>
                <button type="button" id="fbDashBrowseDirBtn" title="Đổi thư mục bài đăng mặc định" class="text-slate-400 hover:text-[#1677ff] transition">
                  <i class="fa-solid fa-pen-to-square"></i>
                </button>
                <button type="button" id="fbDashOpenDirBtn" title="Mở thư mục trong Explorer" class="text-slate-400 hover:text-slate-700 dark:hover:text-white transition">
                  <i class="fa-solid fa-arrow-up-right-from-square"></i>
                </button>
              </div>
            </div>

            <!-- Cụm Phải: Các chỉ số KPI thực thi -->
            <div class="flex flex-wrap items-center gap-2 text-xs">
              <button type="button" id="fbDashGoCampaignsBtn" class="px-2.5 py-1 rounded-md bg-violet-50 dark:bg-violet-950/50 text-violet-600 dark:text-violet-300 font-semibold border border-violet-200/70 dark:border-violet-800/60 hover:bg-violet-100/70 transition flex items-center gap-1" title="Bấm để cấu hình chia nhiều thư mục bài đăng cho từng nhóm Profile">
                <i class="fa-solid fa-layer-group text-[10px]"></i>
                <span id="fbMetricCampaigns">Chiến dịch: 0</span>
              </button>
              <div class="px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-semibold">
                <span id="fbMetricProfiles">Đã chọn: 0</span>
              </div>
              <div class="px-2.5 py-1 rounded-md bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 font-semibold border border-rose-200/60 dark:border-rose-900/50">
                <span id="fbMetricUsers">Tên mục tiêu: 0</span>
              </div>
              <div class="px-2.5 py-1 rounded-md bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 font-semibold border border-emerald-200/60 dark:border-emerald-900/50">
                <span id="fbMetricRunning">Đang chạy: 0</span>
              </div>
              <div class="px-2.5 py-1 rounded-md bg-blue-50 dark:bg-blue-950/40 text-[#1677ff] dark:text-sky-400 font-semibold border border-blue-200/60 dark:border-blue-900/50">
                <span id="fbMetricDone">Hoàn tất: 0/0</span>
              </div>
              <div class="px-2.5 py-1 rounded-md bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 font-semibold border border-amber-200/60 dark:border-amber-900/50">
                <span id="fbMetricCycle">Lượt #1</span>
              </div>
            </div>
          </div>

          <!-- Dòng trạng thái phụ & Thanh tiến độ mỏng sát đáy Card -->
          <div class="px-4 py-1.5 bg-slate-50/80 dark:bg-slate-900/60 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
            <div class="flex items-center gap-3 truncate">
              <span id="fbMetricStatusText" class="font-medium text-slate-600 dark:text-slate-300">Trạng thái: Sẵn sàng</span>
              <span>•</span>
              <span id="fbStartCardDesc" class="truncate">Quét chọn các Profile bên dưới và bấm Bắt đầu chạy</span>
            </div>
            <div class="flex items-center gap-2 shrink-0">
              <span id="fbCountdownLabel" class="font-medium">Đếm ngược: Chưa kích hoạt</span>
              <button type="button" id="fbHeroSelectDmt" class="hidden"></button>
              <button type="button" id="fbHeroSelectGpm" class="hidden"></button>
            </div>
          </div>
          <div class="w-full h-1 bg-slate-100 dark:bg-slate-800 overflow-hidden">
            <div id="fbProgressBar" class="h-full bg-[#1677ff] transition-all duration-300" style="width: 0%"></div>
          </div>
        </div>

        <!-- KHU VỰC CHÍNH (CHIẾM TOÀN BỘ KHÔNG GIAN CÒN LẠI): BẢNG QUÉT CHỌN PROFILE + NHẬT KÝ TRỰC TIẾP -->
        <div class="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-3.5 min-h-0">
          <!-- Cột Trái (7 cols): Bảng dữ liệu Profile chuẩn Ant Design / GPMLogin -->
          <div class="lg:col-span-7 bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl flex flex-col min-h-0 shadow-xs overflow-hidden">
            <!-- Thanh công cụ bảng Profile -->
            <div class="px-3.5 py-2 border-b border-slate-200 dark:border-slate-800 bg-[#f8fafc] dark:bg-[#0d1320] flex flex-col gap-2 shrink-0">
              <div class="flex flex-wrap items-center justify-between gap-2">
                <div class="flex items-center gap-2 flex-1 min-w-[220px]">
                  <div class="relative flex-1 max-w-[200px]">
                    <i class="fa-solid fa-magnifying-glass absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 text-[11px]"></i>
                    <input id="fbDashSearchInput" type="text" placeholder="Tìm tên profile, ID, proxy..." class="w-full pl-7 pr-2.5 py-1 rounded-md bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs focus:border-[#1677ff] focus:outline-none" />
                  </div>
                  <select id="fbDashFolderFilter" class="px-2 py-1 rounded-md bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-200 focus:outline-none">
                    <option value="ALL">Tất cả nhóm</option>
                  </select>
                  <span id="fbMonitoredEngineBadge" class="hidden"></span>
                  <span id="fbMonitoredCountLabel" class="text-[11px] font-semibold text-[#1677ff] dark:text-sky-400 mono whitespace-nowrap">Đã chọn: 0/0</span>
                </div>

                <div class="flex items-center gap-1">
                  <button type="button" id="fbDashDragModeBtn" class="px-2 py-1 rounded border text-[11px] font-semibold flex items-center gap-1 transition bg-blue-50 dark:bg-blue-950/60 border-blue-400 text-[#1677ff] dark:text-blue-400" title="Giữ và kéo chuột dọc theo bảng để quét chọn nhiều Profile">
                    <i class="fa-solid fa-object-group"></i>
                    <span id="fbDashDragModeLabel">Quét chuột: Bật</span>
                  </button>
                  <button type="button" id="fbDashSelectAllBtn" class="px-2 py-1 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-[11px] font-medium text-slate-700 dark:text-slate-200">Chọn hết</button>
                  <button type="button" id="fbDashInvertSelectBtn" class="px-2 py-1 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-[11px] font-medium text-slate-700 dark:text-slate-200">Đảo</button>
                  <button type="button" id="fbDashDeselectAllBtn" class="px-2 py-1 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-[11px] font-medium text-slate-600 dark:text-slate-300">Bỏ chọn</button>
                  <button type="button" id="fbRefreshMonitorBtn" title="Làm mới danh sách Profile" class="px-2 py-1 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-[11px] text-slate-600 dark:text-slate-300">
                    <i class="fa-solid fa-rotate"></i>
                  </button>
                </div>
              </div>

              <!-- Dải gán nhanh các Profile đang chọn vào Chiến dịch (Thư mục bài đăng riêng) -->
              <div class="flex flex-wrap items-center justify-between gap-2 pt-1.5 border-t border-slate-200/70 dark:border-slate-800/80 text-[11px]">
                <div class="flex items-center gap-1.5 flex-wrap">
                  <span class="font-semibold text-violet-700 dark:text-violet-300 flex items-center gap-1">
                    <i class="fa-solid fa-folder-tree text-[10px]"></i>
                    <span>Gán các nick đang tích chọn vào:</span>
                  </span>
                  <select id="fbDashQuickCampaignSelect" class="px-2 py-0.5 rounded bg-white dark:bg-slate-800 border border-violet-300 dark:border-violet-700/80 text-[11px] text-slate-700 dark:text-slate-200 focus:outline-none">
                    <option value="">-- Chọn Chiến dịch / Thư mục bài --</option>
                  </select>
                  <button type="button" id="fbDashQuickAssignBtn" class="px-2.5 py-0.5 rounded bg-violet-600 hover:bg-violet-500 text-white font-semibold transition">
                    Gán ngay
                  </button>
                </div>
                <button type="button" id="fbDashManageCampaignsBtn" class="text-violet-600 dark:text-violet-400 hover:underline font-semibold flex items-center gap-1">
                  <i class="fa-solid fa-plus-circle text-[10px]"></i>
                  <span>Tạo / Quản lý Chiến dịch (Nhiều thư mục)</span>
                </button>
              </div>
            </div>

            <!-- Tiêu đề cột cố định của Bảng Profile -->
            <div class="grid grid-cols-12 gap-2 px-3.5 py-2 bg-slate-100/80 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider shrink-0 select-none">
              <div class="col-span-5 flex items-center gap-2">
                <span>Profile</span>
              </div>
              <div class="col-span-4">Chiến dịch (Thư mục bài) / Nhóm</div>
              <div class="col-span-3 text-right">Trạng thái thực thi</div>
            </div>

            <!-- Danh sách hàng Profile (Kéo chuột quét chọn trực tiếp) -->
            <div id="fbMonitoredProfilesList" class="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/70 select-none">
              <!-- Populated by JS -->
            </div>
          </div>

          <!-- Cột Phải (5 cols): Bố Cục Cửa Sổ Trình Duyệt & Kết Nối GPMLogin -->
          <div class="lg:col-span-5 bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-col justify-between min-h-0 shadow-xs overflow-y-auto space-y-3.5">
            <div class="space-y-3">
              <div class="text-xs font-bold text-slate-800 dark:text-white uppercase tracking-wider pb-2 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span class="flex items-center gap-2">
                  <i class="fa-solid fa-table-cells text-[#1677ff]"></i>
                  <span>Bố Cục Cửa Sổ Trình Duyệt</span>
                </span>
                <span class="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-800">Tối ưu Full màn hình</span>
              </div>

              <div class="flex flex-col gap-2">
                <label class="flex items-center gap-2.5 cursor-pointer select-none text-xs text-slate-700 dark:text-slate-200">
                  <input id="fbChkWindowLayout" type="checkbox" checked class="w-4 h-4 accent-[#1677ff] rounded" />
                  <span class="font-semibold">Bật tự động sắp xếp vị trí cửa sổ</span>
                </label>

                <!-- Ẩn tùy chọn kéo giãn cũ để cố định theo thông số người dùng -->
                <input id="fbChkAutoFitScreen" type="checkbox" class="hidden" />
              </div>

              <!-- 3 Ô thông số người dùng tự chỉnh theo thứ tự: Dài, Rộng, Scale -->
              <div class="grid grid-cols-3 gap-2 text-xs">
                <!-- 1. Dài (Ngang) -->
                <div class="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200/70 dark:border-slate-800">
                  <div class="text-[11px] font-semibold text-slate-600 dark:text-slate-300 mb-1 flex items-center justify-between">
                    <span>Dài (Ngang):</span>
                    <span class="text-[10px] text-slate-400">px</span>
                  </div>
                  <input id="fbInputWinWidth" type="number" min="200" max="2560" step="50" value="1100" class="w-full px-2 py-1 rounded bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 mono font-bold text-slate-800 dark:text-white text-xs focus:border-[#1677ff] focus:outline-none" />
                </div>

                <!-- 2. Rộng (Dọc) -->
                <div class="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200/70 dark:border-slate-800">
                  <div class="text-[11px] font-semibold text-slate-600 dark:text-slate-300 mb-1 flex items-center justify-between">
                    <span>Rộng (Dọc):</span>
                    <span class="text-[10px] text-slate-400">px</span>
                  </div>
                  <input id="fbInputWinHeight" type="number" min="150" max="1600" step="50" value="900" class="w-full px-2 py-1 rounded bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 mono font-bold text-slate-800 dark:text-white text-xs focus:border-[#1677ff] focus:outline-none" />
                </div>

                <!-- 3. Scale zoom (%) -->
                <div class="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200/70 dark:border-slate-800">
                  <div class="text-[11px] font-semibold text-slate-600 dark:text-slate-300 mb-1 flex items-center justify-between">
                    <span>Scale zoom:</span>
                    <span class="text-[10px] text-[#1677ff] font-bold">%</span>
                  </div>
                  <input id="fbInputWinScale" type="number" min="20" max="150" step="5" value="60" class="w-full px-2 py-1 rounded bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 mono font-bold text-[#1677ff] text-xs focus:border-[#1677ff] focus:outline-none" />
                </div>
              </div>

              <!-- Thông số hiển thị trực quan -->
              <div class="space-y-1.5 text-[11px] p-2.5 rounded-lg bg-blue-50/70 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-blue-900/50">
                <div class="flex items-center justify-between">
                  <span class="flex items-center gap-1.5"><i class="fa-solid fa-desktop text-[10px]"></i> Màn hình: <b>DPI-Aware</b></span>
                  <span class="flex items-center gap-1.5"><i class="fa-solid fa-stopwatch text-[10px]"></i> Mở luồng: <b>Cách nhau 2.5s</b></span>
                </div>
                <div class="text-[10px] text-blue-600/90 dark:text-blue-400/90 flex items-center gap-1">
                  <i class="fa-solid fa-circle-check text-[9px]"></i>
                  <span>Xếp ngang ➔ Hết ngang xuống dòng dưới Profile 1 ➔ Hết màn hình lặp lại</span>
                </div>
              </div>

              <div class="pt-1 space-y-2 border-t border-slate-100 dark:border-slate-800">
                <label class="flex items-center gap-2 cursor-pointer select-none text-xs text-slate-700 dark:text-slate-200">
                  <input id="fbChkSkipProxy" type="checkbox" checked class="w-3.5 h-3.5 accent-[#1677ff] rounded" />
                  <span>Bỏ qua kiểm tra proxy GPMLogin (<code class="text-[#1677ff]">--skip-proxy-check</code>)</span>
                </label>

                <div class="flex items-center gap-2 text-xs">
                  <span class="text-slate-500 shrink-0 text-[11px]">GPMLogin API:</span>
                  <input id="fbGpmApiBaseInput" type="text" value="http://127.0.0.1:9495/api/v1" class="flex-1 px-2.5 py-1 rounded-md bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 mono text-xs focus:outline-none" />
                </div>
              </div>
            </div>

            <div class="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
              <span class="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                <i class="fa-solid fa-circle-check"></i> Tự động lưu cấu hình khi thay đổi
              </span>
              <button type="button" onclick="document.querySelector('[data-fb-tab=\\'settings\\']').click()" class="text-[#1677ff] hover:underline font-medium">
                Cài đặt kịch bản →
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- ==================== TRANG 2: CHIẾN DỊCH NHIỀU THƯ MỤC, TÊN MỤC TIÊU & PROFILE ==================== -->
      <div id="fbPageProfiles" class="hidden flex-1 flex flex-col gap-4 px-6 py-4 min-h-0 overflow-y-auto">
        <!-- KHỐI NỔI BẬT: CHIA THEO CHIẾN DỊCH / NHÓM CHẠY (MỖI THƯ MỤC 1 NHÓM PROFILE RIÊNG - TỰ ĐỘNG LƯU) -->
        <div class="bg-white dark:bg-[#111827] border-2 border-violet-200 dark:border-violet-900/70 rounded-xl p-4 shadow-xs shrink-0">
          <div class="flex flex-wrap items-center justify-between gap-3 pb-3 mb-3 border-b border-slate-200 dark:border-slate-800">
            <div>
              <div class="flex items-center gap-2">
                <span class="w-6 h-6 rounded-lg bg-violet-600 text-white flex items-center justify-center text-xs shadow-xs">
                  <i class="fa-solid fa-layer-group"></i>
                </span>
                <h3 class="text-xs font-bold text-slate-800 dark:text-white uppercase tracking-wide">
                  Phân Nhóm Chiến Dịch Theo Thư Mục Bài Đăng (Tự Động Lưu Cố Định)
                </h3>
                <span id="fbCampaignTotalBadge" class="text-[11px] px-2 py-0.5 rounded-full bg-violet-100 dark:bg-violet-950/80 text-violet-700 dark:text-violet-300 font-bold mono">
                  0 Chiến dịch
                </span>
              </div>
              <p class="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                Mỗi chiến dịch gắn <b>1 Thư mục bài đăng riêng</b> với <b>1 Nhóm Profile riêng</b>. Mọi cài đặt đều <b>tự động lưu</b> — những lần mở app sau bạn chỉ việc bấm <b>"BẮT ĐẦU CHẠY AUTO"</b>! (Các nick không gắn chiến dịch sẽ lấy bài ở Thư mục mặc định).
              </p>
            </div>

            <div class="flex items-center gap-2">
              <button type="button" id="fbAddCampaignBtn" class="px-3.5 py-2 rounded-lg bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold shadow-xs flex items-center gap-1.5 transition cursor-pointer">
                <i class="fa-solid fa-plus"></i>
                <span>Thêm Chiến Dịch / Thư Mục Mới</span>
              </button>
            </div>
          </div>

          <!-- Danh sách các thẻ Chiến dịch -->
          <div id="fbCampaignsListContainer" class="grid grid-cols-1 xl:grid-cols-2 gap-3">
            <!-- Populated by renderCampaignsSection() -->
          </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1 min-h-[380px]">
          <!-- Cột Trái (5 cols): Danh sách Tên Người Đăng Cần Thả Tim (user.txt) -->
          <div class="lg:col-span-5 bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-col min-h-0 shadow-xs">
            <div class="pb-3 mb-2.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
              <div class="flex items-center gap-2">
                <i class="fa-solid fa-heart text-rose-500 text-sm"></i>
                <span class="text-xs font-bold text-slate-800 dark:text-white">Danh Sách Tên Người Đăng Cần Thả Tim (user.txt)</span>
              </div>
              <span id="fbTargetUsersCountBadge" class="text-[11px] px-2 py-0.5 rounded bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 font-bold mono">0 Tên</span>
            </div>

            <p class="text-[11px] text-slate-500 dark:text-slate-400 mb-2.5 leading-relaxed shrink-0">
              Nhập mỗi dòng 1 <b>Tên hiển thị Facebook</b> của người đăng bài (không cần dùng UID). Khi lướt Bảng tin (Bước 1) hoặc lướt Nhóm (Bước 2 & 3), gặp bài của người có tên trong danh sách này bot sẽ tự động giữ chuột <b>Thả Tim ❤️ / Like 👍</b>.
            </p>

            <textarea id="fbTargetUsersTextarea" rows="12" placeholder="Ví dụ:&#10;Nguyễn Văn A&#10;Trần Thị B&#10;Hoàng Minh..." class="flex-1 w-full p-3 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 mono text-xs text-slate-800 dark:text-white focus:border-[#1677ff] focus:outline-none resize-none"></textarea>

            <div class="pt-3 mt-auto flex justify-end shrink-0">
              <button type="button" id="fbSaveTargetUsersBtn" class="w-full py-2 px-4 rounded-lg bg-[#1677ff] hover:bg-[#0958d9] text-white text-xs font-semibold shadow-xs flex items-center justify-center gap-1.5 transition">
                <i class="fa-solid fa-floppy-disk"></i>
                <span>Lưu Danh Sách Tên Người Đăng</span>
              </button>
            </div>
          </div>

          <!-- Cột Phải (7 cols): Quản lý Thư mục Bài đăng mặc định & Quét chọn Profile dự phòng -->
          <div class="lg:col-span-7 flex flex-col gap-4 min-h-0">
            <!-- Khối 1: Thư mục chứa bài đăng & ảnh Poster Mặc định -->
            <div class="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl p-4 shrink-0 shadow-xs">
              <div class="flex items-center justify-between mb-2">
                <label class="text-xs font-bold text-slate-800 dark:text-white flex items-center gap-2">
                  <i class="fa-regular fa-folder-open text-amber-500"></i>
                  <span>Thư Mục Bài Đăng Mặc Định (Dùng cho các Profile chưa gán Chiến dịch riêng)</span>
                </label>
                <span class="text-[11px] text-slate-400">Hỗ trợ cấu trúc <code class="text-[#1677ff]">baidang/</code> + <code class="text-[#1677ff]">poster/</code></span>
              </div>
              <div class="flex flex-wrap items-center gap-2">
                <input id="fbContentDirInput" type="text" placeholder="C:\\Users\\DMTam\\Desktop\\Auto_Create_Contents\\output" class="flex-1 px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 mono text-xs text-slate-800 dark:text-white focus:border-[#1677ff] focus:outline-none" />
                <button type="button" id="fbBrowseDirBtn2" class="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 flex items-center gap-1.5 transition">
                  <i class="fa-regular fa-folder-open text-amber-500"></i>
                  <span>Chọn thư mục...</span>
                </button>
                <button type="button" id="fbSaveContentDirBtn" class="px-3.5 py-1.5 rounded-lg bg-[#1677ff] hover:bg-[#0958d9] text-white text-xs font-semibold transition">
                  Lưu đường dẫn
                </button>
              </div>
            </div>

            <!-- Khối 2: Quản lý chi tiết danh sách Profile DMT / GPMLogin -->
            <div class="flex-1 bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-col min-h-0 shadow-xs">
              <div class="flex flex-wrap items-center justify-between gap-2 pb-2.5 mb-2.5 border-b border-slate-200 dark:border-slate-800 shrink-0">
                <div class="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
                  <button type="button" id="fbProfTabBtnDmt" class="px-3 py-1 rounded-md text-xs font-semibold bg-[#1677ff] text-white transition flex items-center gap-1.5">
                    <i class="fa-solid fa-shield-halved"></i>
                    <span>Profile DMT Browser</span>
                  </button>
                  <button type="button" id="fbProfTabBtnGpm" class="px-3 py-1 rounded-md text-xs font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition flex items-center gap-1.5">
                    <i class="fa-solid fa-globe"></i>
                    <span>Profile GPMLogin (id_profile.txt)</span>
                  </button>
                </div>
                <span id="fbActiveEngineHint" class="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                  Đang dùng: Profile DMT Browser
                </span>
              </div>

              <!-- Pane DMT -->
              <div id="fbProfPaneDmt" class="flex-1 flex flex-col min-h-0">
                <div class="flex flex-wrap items-center justify-between gap-2 mb-2 shrink-0">
                  <div class="flex items-center gap-2 flex-1">
                    <input id="fbDmtSearchInput" type="text" placeholder="Tìm tên profile, ID, ghi chú..." class="px-2.5 py-1 rounded-md bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs flex-1 focus:border-[#1677ff] focus:outline-none" />
                    <select id="fbDmtFolderFilter" class="px-2.5 py-1 rounded-md bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs focus:outline-none">
                      <option value="ALL">Tất cả nhóm</option>
                    </select>
                  </div>
                  <div class="flex items-center gap-1">
                    <button type="button" id="fbDmtSelectAllBtn" class="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-xs font-medium">Chọn hết</button>
                    <button type="button" id="fbDmtInvertBtn" class="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-xs font-medium">Đảo</button>
                    <button type="button" id="fbDmtDeselectAllBtn" class="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-xs font-medium">Bỏ chọn</button>
                  </div>
                </div>

                <div id="fbDmtChecklistContainer" class="flex-1 overflow-y-auto border border-slate-200 dark:border-slate-800 rounded-lg divide-y divide-slate-100 dark:divide-slate-800/80 bg-slate-50/40 dark:bg-slate-900/40 select-none"></div>

                <div class="pt-2.5 mt-auto flex items-center justify-between gap-3 shrink-0">
                  <span id="fbDmtSelectedSummary" class="text-xs font-medium text-slate-600 dark:text-slate-300">Đã chọn: 0 Profile DMT</span>
                  <button type="button" id="fbSaveDmtProfilesBtn" class="px-4 py-1.5 rounded-lg bg-[#1677ff] hover:bg-[#0958d9] text-white text-xs font-semibold transition">
                    Lưu & Chọn Chế Độ DMT
                  </button>
                </div>
              </div>

              <!-- Pane GPM -->
              <div id="fbProfPaneGpm" class="hidden flex-1 flex flex-col min-h-0">
                <div class="flex flex-wrap items-center justify-between gap-2 mb-2 shrink-0">
                  <div class="flex items-center gap-1.5">
                    <button type="button" id="fbFetchGpmApiProfilesBtn" class="px-2.5 py-1 rounded-md bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 text-indigo-600 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 text-xs font-semibold flex items-center gap-1.5 transition">
                      <i class="fa-solid fa-rotate"></i>
                      <span>Đồng bộ từ GPMLogin (Port 9495)</span>
                    </button>
                    <button type="button" id="fbToggleGpmEditModeBtn" class="px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-xs font-medium text-slate-700 dark:text-slate-200 transition">
                      Sửa dạng văn bản (ID)
                    </button>
                  </div>
                  <div id="fbGpmListToolbar" class="flex items-center gap-1">
                    <button type="button" id="fbGpmSelectAllBtn" class="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 text-xs font-medium">Chọn hết</button>
                    <button type="button" id="fbGpmDeselectAllBtn" class="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 text-xs font-medium">Bỏ chọn</button>
                  </div>
                </div>

                <div id="fbGpmChecklistWrap" class="flex-1 flex flex-col min-h-0">
                  <input id="fbGpmSearchInput" type="text" placeholder="Tìm tên hoặc ID profile GPMLogin..." class="mb-2 px-2.5 py-1 rounded-md bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs focus:outline-none shrink-0" />
                  <div id="fbGpmChecklistContainer" class="flex-1 overflow-y-auto border border-slate-200 dark:border-slate-800 rounded-lg divide-y divide-slate-100 dark:divide-slate-800/80 bg-slate-50/40 dark:bg-slate-900/40 select-none"></div>
                </div>

                <textarea id="fbGpmProfilesTextarea" rows="8" placeholder="Nhập danh sách ID Profile GPMLogin (mỗi ID 1 dòng)..." class="hidden flex-1 w-full p-3 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 mono text-xs text-slate-800 dark:text-white focus:border-[#1677ff] focus:outline-none resize-none"></textarea>

                <div class="pt-2.5 mt-auto flex items-center justify-between gap-3 shrink-0">
                  <span id="fbGpmCountSummary" class="text-xs font-medium text-slate-600 dark:text-slate-300">Đã chọn: 0 GPM Profile</span>
                  <button type="button" id="fbSaveGpmProfilesBtn" class="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition">
                    Lưu & Chọn Chế Độ GPM
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- ==================== TRANG 3: CẤU HÌNH KỊCH BẢN & TƯƠNG TÁC ==================== -->
      <div id="fbPageSettings" class="hidden flex-1 flex flex-col gap-4 px-6 py-4 min-h-0 overflow-y-auto">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
          <!-- Khối Trái (5 cols): Bật / Tắt 3 Bước Kịch Bản & Hệ thống -->
          <div class="lg:col-span-5 flex flex-col gap-4">
            <div class="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-3 shadow-xs">
              <div class="text-xs font-bold text-slate-800 dark:text-white uppercase tracking-wider pb-2 border-b border-slate-100 dark:border-slate-800">
                1. Các Bước Trong Kịch Bản Tự Động
              </div>

              <label class="flex items-start gap-2.5 p-2.5 rounded-lg bg-pink-50/70 dark:bg-pink-950/25 border border-pink-200/80 dark:border-pink-800/60 cursor-pointer select-none text-xs text-slate-700 dark:text-slate-200">
                <input id="fbChkTwoWayNickPage" type="checkbox" class="mt-0.5 w-4 h-4 accent-pink-600 rounded" />
                <div>
                  <div class="font-bold text-pink-700 dark:text-pink-300 flex items-center gap-1.5">
                    <i class="fa-solid fa-arrows-left-right text-[11px]"></i>
                    <span>Tương tác 2 chiều nick-page</span>
                  </div>
                  <div class="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">
                    1) Chuyển về Nick chính (mở Accounts Center & click submit) ➔ 2) Bước 1 tương tác Nick ➔ 3) Chuyển sang Page (<code class="text-pink-600 dark:text-pink-400">0 → 3</code>) ➔ 4) Bước 1 tương tác Page ➔ 5) Bước 2 & 3 (Page đăng bài & tương tác Nhóm).
                  </div>
                </div>
              </label>

              <label class="flex items-start gap-2.5 p-2.5 rounded-lg bg-slate-50/70 dark:bg-slate-900/50 border border-slate-200/60 dark:border-slate-800 cursor-pointer select-none text-xs text-slate-700 dark:text-slate-200">
                <input id="fbChkStep1" type="checkbox" checked class="mt-0.5 w-4 h-4 accent-[#1677ff] rounded" />
                <div>
                  <div class="font-bold text-slate-800 dark:text-white">Bước 1: Lướt Bảng tin, Xem Reels / Story & Thả Tim theo Tên</div>
                  <div class="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">Tự động quét Tên người đăng trên Feed để thả Tim ❤️ / Like 👍 và tương tác tự nhiên.</div>
                </div>
              </label>

              <label class="flex items-start gap-2.5 p-2.5 rounded-lg bg-slate-50/70 dark:bg-slate-900/50 border border-slate-200/60 dark:border-slate-800 cursor-pointer select-none text-xs text-slate-700 dark:text-slate-200">
                <input id="fbChkStep2" type="checkbox" checked class="mt-0.5 w-4 h-4 accent-[#1677ff] rounded" />
                <div>
                  <div class="font-bold text-slate-800 dark:text-white">Bước 2: Quét Nhóm & Đăng Bài Kèm Ảnh Poster</div>
                  <div class="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">Chọn ngẫu nhiên N nhóm đã tham gia, đăng bài + ảnh và lướt nhóm thả Tim theo Tên.</div>
                </div>
              </label>

              <label class="flex items-start gap-2.5 p-2.5 rounded-lg bg-slate-50/70 dark:bg-slate-900/50 border border-slate-200/60 dark:border-slate-800 cursor-pointer select-none text-xs text-slate-700 dark:text-slate-200">
                <input id="fbChkStep3" type="checkbox" checked class="mt-0.5 w-4 h-4 accent-[#1677ff] rounded" />
                <div>
                  <div class="font-bold text-slate-800 dark:text-white">Bước 3: Vào Nhóm Tương Tác Bài Của Tên Mục Tiêu</div>
                  <div class="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">Ghé thăm các nhóm đã tham gia và thả Tim/Like cho bài viết của người trong danh sách.</div>
                </div>
              </label>
            </div>

            <!-- Khối Cấu hình Bình luận & Tương tác List User -->
            <div class="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-3 shadow-xs">
              <div class="text-xs font-bold text-slate-800 dark:text-white uppercase tracking-wider pb-2 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span>3. Cấu hình Bình Luận & Tương Tác List User</span>
                <span id="fbCommentCountBadge" class="px-2 py-0.5 rounded text-[10px] font-mono bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-200 dark:border-sky-800/60 font-bold">5 câu</span>
              </div>

              <div class="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <label class="block text-[11px] font-semibold text-slate-600 dark:text-slate-300 mb-1">Tỉ lệ Thả Cảm Xúc:</label>
                  <select id="fbSelectReactRate" class="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs text-slate-800 dark:text-white focus:outline-none focus:border-[#1677ff]">
                    <option value="0.10">10%</option>
                    <option value="0.20">20%</option>
                    <option value="0.30" selected>30% (70% Like / 30% Tim)</option>
                    <option value="0.50">50%</option>
                    <option value="0.70">70%</option>
                    <option value="1.00">100%</option>
                  </select>
                </div>
                <div>
                  <label class="block text-[11px] font-semibold text-slate-600 dark:text-slate-300 mb-1">Tỉ lệ Bình Luận:</label>
                  <select id="fbSelectCommentRate" class="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs text-slate-800 dark:text-white focus:outline-none focus:border-[#1677ff]">
                    <option value="0.02">2%</option>
                    <option value="0.05" selected>5% (Khuyên dùng)</option>
                    <option value="0.10">10%</option>
                    <option value="0.20">20%</option>
                    <option value="0.50">50%</option>
                    <option value="1.00">100%</option>
                  </select>
                </div>
              </div>

              <div>
                <div class="flex items-center justify-between mb-1">
                  <label class="text-[11px] font-semibold text-slate-600 dark:text-slate-300">
                    Danh sách câu/từ bình luận (Mỗi câu 1 dòng, chọn ngẫu nhiên):
                  </label>
                  <span id="fbCommentCountBadge" class="text-[10px] px-1.5 py-0.5 rounded bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-300 font-semibold">0 câu</span>
                </div>
                <textarea id="fbCommentTextsTextarea" rows="4" placeholder="Ví dụ:&#10;Bài viết rất hay và ý nghĩa bạn ơi 👍&#10;Tuyệt vời quá ạ ❤️&#10;Chúc bạn ngày mới năng lượng và may mắn!&#10;Tương tác cùng nhau phát triển nhé bạn ơi 👍" class="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 mono text-xs text-slate-800 dark:text-white focus:border-[#1677ff] focus:outline-none resize-none"></textarea>
              </div>
            </div>
          </div>

          <!-- Khối Phải (7 cols): Thông số Số luồng & Định lượng từng bước -->
          <div class="lg:col-span-7 bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-xs">
            <div class="space-y-4">
              <div class="text-xs font-bold text-slate-800 dark:text-white uppercase tracking-wider pb-2 border-b border-slate-100 dark:border-slate-800">
                2. Thông Số Luồng & Định Lượng Tương Tác
              </div>

              <div class="grid grid-cols-1 md:grid-cols-2 gap-3.5 text-xs">
                <div class="p-3 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200/70 dark:border-slate-800">
                  <div class="flex justify-between mb-1.5">
                    <span class="font-semibold text-slate-700 dark:text-slate-200">Số luồng chạy song song:</span>
                    <b id="fbValThreads" class="text-[#1677ff] mono">5</b>
                  </div>
                  <input id="fbSliderThreads" type="range" min="1" max="10" step="1" value="5" class="w-full accent-[#1677ff] cursor-pointer" />
                </div>

                <div class="p-3 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200/70 dark:border-slate-800">
                  <div class="flex justify-between mb-1.5">
                    <span class="font-semibold text-slate-700 dark:text-slate-200">Số nhóm đăng bài (Bước 2):</span>
                    <b id="fbValShareGroups" class="text-[#1677ff] mono">5</b>
                  </div>
                  <input id="fbSliderShareGroups" type="range" min="1" max="20" step="1" value="5" class="w-full accent-[#1677ff] cursor-pointer" />
                </div>

                <div class="p-3 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200/70 dark:border-slate-800">
                  <div class="flex justify-between mb-1.5">
                    <span class="font-semibold text-slate-700 dark:text-slate-200">Số lần cuộn Bảng tin (Bước 1):</span>
                    <b id="fbValFeed" class="text-[#1677ff] mono">10</b>
                  </div>
                  <input id="fbSliderFeed" type="range" min="4" max="25" step="1" value="10" class="w-full accent-[#1677ff] cursor-pointer" />
                </div>

                <div class="p-3 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200/70 dark:border-slate-800">
                  <div class="flex justify-between mb-1.5">
                    <span class="font-semibold text-slate-700 dark:text-slate-200">Số video Reels xem (Bước 1):</span>
                    <b id="fbValReels" class="text-[#1677ff] mono">6</b>
                  </div>
                  <input id="fbSliderReels" type="range" min="2" max="15" step="1" value="6" class="w-full accent-[#1677ff] cursor-pointer" />
                </div>

                <div class="p-3 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200/70 dark:border-slate-800">
                  <div class="flex justify-between mb-1.5">
                    <span class="font-semibold text-slate-700 dark:text-slate-200">Số nhóm ghé thăm (Bước 3):</span>
                    <b id="fbValVisit" class="text-[#1677ff] mono">2</b>
                  </div>
                  <input id="fbSliderVisit" type="range" min="1" max="10" step="1" value="2" class="w-full accent-[#1677ff] cursor-pointer" />
                </div>

                <div class="p-3 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200/70 dark:border-slate-800">
                  <div class="flex justify-between mb-1.5">
                    <span class="font-semibold text-slate-700 dark:text-slate-200">Thời gian nghỉ lặp lại:</span>
                    <b id="fbValRepeatDelay" class="text-[#1677ff] mono">30 phút</b>
                  </div>
                  <input id="fbSliderRepeatDelay" type="range" min="1" max="180" step="1" value="30" class="w-full accent-[#1677ff] cursor-pointer" />
                </div>
              </div>
            </div>

            <div class="pt-4 mt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end">
              <button type="button" id="fbSaveAllSettingsBtn" class="px-5 py-2 rounded-lg bg-[#1677ff] hover:bg-[#0958d9] text-white font-semibold text-xs shadow-sm flex items-center gap-2 transition">
                <i class="fa-solid fa-check"></i>
                <span>Lưu Toàn Bộ Cấu Hình Kịch Bản</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- ==================== TRANG 4: NHẬT KÝ CHI TIẾT TOÀN MÀN HÌNH ==================== -->
      <div id="fbPageLogs" class="hidden flex-1 flex flex-col gap-3 px-6 py-4 min-h-0 overflow-hidden">
        <div class="flex items-center justify-between shrink-0">
          <div class="flex items-center gap-2">
            <span class="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
            <h2 class="text-sm font-bold text-slate-800 dark:text-white">Nhật Ký Hoạt Động Chi Tiết (Full Console Logs)</h2>
          </div>
          <div class="flex items-center gap-2">
            <button type="button" id="fbCopyFullLogsBtn" class="px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 text-xs font-medium text-slate-700 dark:text-slate-200">
              <i class="fa-regular fa-copy mr-1"></i> Sao chép Log
            </button>
            <button type="button" id="fbClearFullLogsBtn" class="px-3 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 text-xs font-medium text-rose-600 dark:text-rose-400">
              <i class="fa-regular fa-trash-can mr-1"></i> Xóa toàn bộ
            </button>
          </div>
        </div>

        <div id="fbFullLogBox" class="flex-1 overflow-y-auto p-4 rounded-xl bg-[#0d1320] text-slate-200 border border-slate-800 mono text-xs leading-relaxed space-y-1 select-text"></div>
      </div>

      <!-- ==================== MODAL CHỌN PROFILE CHO CHIẾN DỊCH ==================== -->
      <div id="fbCampaignProfileModal" class="hidden fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
        <div class="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl w-full max-w-2xl max-h-[85vh] flex flex-col overflow-hidden">
          <div class="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-violet-50/60 dark:bg-violet-950/30">
            <div class="flex items-center gap-2.5 min-w-0">
              <span class="w-7 h-7 rounded-lg bg-violet-600 text-white flex items-center justify-center text-xs shrink-0">
                <i class="fa-solid fa-users-gear"></i>
              </span>
              <div class="min-w-0">
                <h4 id="fbCampModalTitle" class="text-xs font-bold text-slate-800 dark:text-white truncate">Chọn Profile cho Chiến dịch</h4>
                <p id="fbCampModalSub" class="text-[11px] text-slate-500 dark:text-slate-400 truncate">Tích chọn các Profile sẽ lấy bài đăng từ thư mục của chiến dịch này</p>
              </div>
            </div>
            <button type="button" id="fbCampModalCloseBtn" class="w-7 h-7 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-500 flex items-center justify-center transition">
              <i class="fa-solid fa-xmark"></i>
            </button>
          </div>

          <div class="px-5 py-2.5 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 bg-slate-50/70 dark:bg-slate-900/50">
            <input id="fbCampModalSearchInput" type="text" placeholder="Tìm tên profile, ID, nhóm..." class="flex-1 min-w-[180px] px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs focus:border-violet-500 focus:outline-none" />
            <div class="flex items-center gap-1.5">
              <button type="button" id="fbCampModalSelectAllBtn" class="px-2.5 py-1 rounded-md bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 text-xs font-medium">Chọn hết</button>
              <button type="button" id="fbCampModalDeselectAllBtn" class="px-2.5 py-1 rounded-md bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 text-xs font-medium">Bỏ chọn hết</button>
            </div>
          </div>

          <div id="fbCampModalList" class="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/70 p-2 select-none">
            <!-- Populated by renderCampaignProfileModal() -->
          </div>

          <div class="px-5 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/70 flex items-center justify-between gap-3">
            <span id="fbCampModalSelectedCount" class="text-xs font-semibold text-violet-600 dark:text-violet-400">Đã gán: 0 Profile</span>
            <button type="button" id="fbCampModalDoneBtn" class="px-5 py-2 rounded-lg bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold shadow-xs transition">
              <i class="fa-solid fa-check mr-1"></i> Xong (Đã tự động lưu)
            </button>
          </div>
        </div>
      </div>
    `;
  }

  // ==================== 3. KÉO CHUỘT QUÉT CHỌN (RUBBER-BAND MARQUEE SELECTION) ====================
  function initFbMarqueeSelection() {
    if (window.__fbMarqueeInitialized) return;
    window.__fbMarqueeInitialized = true;

    let marqueeEl = document.getElementById('selectionMarquee');
    if (!marqueeEl) {
      marqueeEl = document.createElement('div');
      marqueeEl.id = 'selectionMarquee';
      document.body.appendChild(marqueeEl);
    }

    function setupMarqueeForContainer(containerId, getEngineType) {
      let active = false;
      let startX = 0;
      let startY = 0;
      let baseSet = new Set();
      let pendingIds = null;

      document.addEventListener('mousedown', (e) => {
        if (e.button !== 0) return;
        if (window.__currentMainView !== 'fb_auto') return;
        if (!fbDragSelectEnabled) return;

        const container = document.getElementById(containerId);
        if (!container || container.offsetParent === null) return;

        if (
          e.target.closest(
            'button, input, select, textarea, a, label, #fbClearMiniLogBtn'
          )
        ) {
          return;
        }

        const rect = container.getBoundingClientRect();
        if (
          e.clientX < rect.left ||
          e.clientX > rect.right ||
          e.clientY < rect.top ||
          e.clientY > rect.bottom
        ) {
          return;
        }

        const engine = getEngineType();
        const currentArr =
          engine === 'dmt'
            ? fbConfig?.dmt_profile_ids || []
            : fbConfig?.gpm_profile_ids || [];

        active = true;
        startX = e.clientX;
        startY = e.clientY;
        baseSet = e.ctrlKey || e.metaKey || e.shiftKey ? new Set(currentArr) : new Set();
        pendingIds = null;
      });

      document.addEventListener('mousemove', (e) => {
        if (!active) return;

        const dx = Math.abs(e.clientX - startX);
        const dy = Math.abs(e.clientY - startY);
        if (!isMarqueeDragging && dx < 6 && dy < 6) return;

        isMarqueeDragging = true;

        const left = Math.min(startX, e.clientX);
        const top = Math.min(startY, e.clientY);
        const width = Math.abs(e.clientX - startX);
        const height = Math.abs(e.clientY - startY);

        marqueeEl.style.display = 'block';
        marqueeEl.style.left = `${left}px`;
        marqueeEl.style.top = `${top}px`;
        marqueeEl.style.width = `${width}px`;
        marqueeEl.style.height = `${height}px`;

        const boxBottom = top + height;
        const container = document.getElementById(containerId);
        if (!container) return;

        const nextSet = new Set(baseSet);
        const rows = container.querySelectorAll('.fb-selectable-row');
        rows.forEach((row) => {
          const r = row.getBoundingClientRect();
          const pid = row.getAttribute('data-pid');
          if (!pid) return;
          const overlapsY = r.bottom >= top && r.top <= boxBottom;
          if (overlapsY) {
            nextSet.add(pid);
          }
        });

        pendingIds = Array.from(nextSet);
        updateVisualSelectionOnly(container, nextSet);
      });

      document.addEventListener('mouseup', () => {
        if (!active) return;
        active = false;

        if (isMarqueeDragging) {
          marqueeEl.style.display = 'none';
          isMarqueeDragging = false;
          window._fbJustFinishedMarquee = true;
          setTimeout(() => {
            window._fbJustFinishedMarquee = false;
          }, 120);

          if (pendingIds !== null) {
            const engine = getEngineType();
            applySelectionArray(engine, pendingIds);
          }
        }
      });
    }

    setupMarqueeForContainer('fbMonitoredProfilesList', () =>
      (fbConfig?.engine || 'dmt').toLowerCase()
    );
    setupMarqueeForContainer('fbDmtChecklistContainer', () => 'dmt');
    setupMarqueeForContainer('fbGpmChecklistContainer', () => 'gpm');
  }

  function updateVisualSelectionOnly(container, selectedSet) {
    const rows = container.querySelectorAll('.fb-selectable-row');
    rows.forEach((row) => {
      const pid = row.getAttribute('data-pid');
      const chk = row.querySelector('input[type="checkbox"]');
      const isSel = selectedSet.has(pid);
      if (chk) chk.checked = isSel;
      if (isSel) {
        row.classList.add('row-selected');
      } else {
        row.classList.remove('row-selected');
      }
    });
  }

  function isDmtProfileId(id) {
    if (!id) return false;
    const clean = String(id).trim();
    return dmtProfiles.some((p) => String(p.id) === clean);
  }

  function applySelectionArray(engine, newIds, silent = false) {
    if (!fbConfig) return;
    const cleanIds = Array.from(new Set(newIds.map((x) => String(x).trim()).filter(Boolean)));
    if (engine === 'dmt') {
      const validDmtIds = cleanIds.filter(isDmtProfileId);
      fbConfig.dmt_profile_ids = validDmtIds;
      saveConfigQuiet({ dmt_profile_ids: validDmtIds });
    } else {
      // Đảm bảo danh sách gốc gpm_all_profile_ids không bị mất khi chỉ tích chọn / bỏ chọn và không bị lẫn ID DMT
      const validGpmIds = cleanIds.filter((id) => !isDmtProfileId(id));
      const allSet = new Set((fbConfig.gpm_all_profile_ids || []).filter((id) => !isDmtProfileId(id)));
      (fbConfig.gpm_profile_ids || []).filter((id) => !isDmtProfileId(id)).forEach((id) => allSet.add(String(id).trim()));
      validGpmIds.forEach((id) => allSet.add(id));
      fbConfig.gpm_all_profile_ids = Array.from(allSet).filter(Boolean);
      fbConfig.gpm_profile_ids = validGpmIds;
      saveConfigQuiet({ gpm_all_profile_ids: fbConfig.gpm_all_profile_ids, gpm_profile_ids: validGpmIds });
    }
    updateEngineCounters();
    lastRenderedDashSignature = '';
    renderMonitoredProfiles();
    renderDmtChecklist();
    renderGpmChecklist();
    updateMetricsBar();
  }

  function toggleFbDragSelectMode() {
    fbDragSelectEnabled = !fbDragSelectEnabled;
    const btn = document.getElementById('fbDashDragModeBtn');
    const lbl = document.getElementById('fbDashDragModeLabel');
    if (fbDragSelectEnabled) {
      if (btn)
        btn.className =
          'px-2 py-1 rounded border text-[11px] font-semibold flex items-center gap-1 transition bg-blue-50 dark:bg-blue-950/60 border-blue-400 text-[#1677ff] dark:text-blue-400';
      if (lbl) lbl.textContent = 'Quét chuột: Bật';
    } else {
      if (btn)
        btn.className =
          'px-2 py-1 rounded border text-[11px] font-semibold flex items-center gap-1 transition bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300';
      if (lbl) lbl.textContent = 'Quét chuột: Tắt';
    }
  }

  // ==================== 4. SỰ KIỆN & LOGIC ĐIỀU KHIỂN ====================
  function bindEvents() {
    document.querySelectorAll('.fb-tab-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const tab = btn.getAttribute('data-fb-tab') || 'dash';
        switchSubTab(tab);
      });
    });

    document.getElementById('fbEngineBtnDmt')?.addEventListener('click', () => setEngine('dmt', true));
    document.getElementById('fbEngineBtnGpm')?.addEventListener('click', () => setEngine('gpm', true));

    document.getElementById('fbProfTabBtnDmt')?.addEventListener('click', () => switchProfileConfigTab('dmt'));
    document.getElementById('fbProfTabBtnGpm')?.addEventListener('click', () => switchProfileConfigTab('gpm'));

    document.getElementById('fbGpmStatusBadge')?.addEventListener('click', () => checkGpmStatus(true));

    document.getElementById('fbBtnStartStop')?.addEventListener('click', toggleStartStop);
    document.getElementById('fbBtnSkipWait')?.addEventListener('click', skipCountdown);

    document.getElementById('fbDashTwoWayToggle')?.addEventListener('change', (e) => {
      if (!fbConfig) return;
      const checked = !!e.target.checked;
      fbConfig.enable_nick_page_two_way = checked;
      const chkSettings = document.getElementById('fbChkTwoWayNickPage');
      if (chkSettings) chkSettings.checked = checked;
      saveConfigQuiet({ enable_nick_page_two_way: checked });
      notify(
        checked
          ? 'Đã bật chế độ: Tương tác 2 chiều nick-page!'
          : 'Đã tắt chế độ: Tương tác 2 chiều nick-page.',
        'info'
      );
    });

    document.getElementById('fbChkTwoWayNickPage')?.addEventListener('change', (e) => {
      if (!fbConfig) return;
      const checked = !!e.target.checked;
      fbConfig.enable_nick_page_two_way = checked;
      const chkDash = document.getElementById('fbDashTwoWayToggle');
      if (chkDash) chkDash.checked = checked;
      saveConfigQuiet({ enable_nick_page_two_way: checked });
    });

    document.getElementById('fbDashRepeatToggle')?.addEventListener('change', (e) => {
      if (!fbConfig) return;
      fbConfig.enable_auto_repeat = e.target.checked;
      saveConfigQuiet({ enable_auto_repeat: e.target.checked });
    });

    document.getElementById('fbDashRepeatDelayInput')?.addEventListener('change', (e) => {
      const val = Math.max(1, Math.min(360, parseInt(e.target.value, 10) || 30));
      e.target.value = val;
      const slider = document.getElementById('fbSliderRepeatDelay');
      const label = document.getElementById('fbValRepeatDelay');
      if (slider && val <= 180) slider.value = val;
      if (label) label.textContent = `${val} phút`;
      saveConfigQuiet({ repeat_delay_minutes: val });
    });

    document.getElementById('fbDashBrowseDirBtn')?.addEventListener('click', browseContentFolder);
    document.getElementById('fbBrowseDirBtn2')?.addEventListener('click', browseContentFolder);
    document.getElementById('fbDashOpenDirBtn')?.addEventListener('click', openContentFolder);
    document.getElementById('fbSaveContentDirBtn')?.addEventListener('click', () => {
      const dir = (document.getElementById('fbContentDirInput')?.value || '').trim();
      saveConfigWithToast({ content_output_dir: dir }, 'Đã lưu đường dẫn thư mục nội dung!');
    });

    // Dashboard Profile Selector controls
    document.getElementById('fbDashDragModeBtn')?.addEventListener('click', toggleFbDragSelectMode);
    document.getElementById('fbDashSearchInput')?.addEventListener('input', (e) => {
      dashSearchQuery = (e.target.value || '').trim().toLowerCase();
      lastRenderedDashSignature = '';
      renderMonitoredProfiles();
    });
    document.getElementById('fbDashFolderFilter')?.addEventListener('change', (e) => {
      dashFilterFolder = e.target.value || 'ALL';
      lastRenderedDashSignature = '';
      renderMonitoredProfiles();
    });
    document.getElementById('fbDashSelectAllBtn')?.addEventListener('click', () => {
      const engine = (fbConfig?.engine || 'dmt').toLowerCase();
      const visibleIds = getDashboardCandidateProfiles().map((p) => p.id);
      const current = new Set(getActiveProfileIds());
      visibleIds.forEach((id) => current.add(id));
      applySelectionArray(engine, Array.from(current));
    });
    document.getElementById('fbDashInvertSelectBtn')?.addEventListener('click', () => {
      const engine = (fbConfig?.engine || 'dmt').toLowerCase();
      const visibleIds = getDashboardCandidateProfiles().map((p) => p.id);
      const current = new Set(getActiveProfileIds());
      visibleIds.forEach((id) => {
        if (current.has(id)) current.delete(id);
        else current.add(id);
      });
      applySelectionArray(engine, Array.from(current));
    });
    document.getElementById('fbDashDeselectAllBtn')?.addEventListener('click', () => {
      const engine = (fbConfig?.engine || 'dmt').toLowerCase();
      const visibleIds = new Set(getDashboardCandidateProfiles().map((p) => p.id));
      const next = getActiveProfileIds().filter((id) => !visibleIds.has(id));
      applySelectionArray(engine, next);
    });
    document.getElementById('fbRefreshMonitorBtn')?.addEventListener('click', async () => {
      lastRenderedDashSignature = '';
      await fetchState(false);
      await fetchGpmProfilesFromApi(false);
      notify('Đã làm mới danh sách Profile!', 'info');
    });

    // Logs controls
    document.getElementById('fbClearMiniLogBtn')?.addEventListener('click', clearLogs);
    document.getElementById('fbClearFullLogsBtn')?.addEventListener('click', clearLogs);
    document.getElementById('fbCopyFullLogsBtn')?.addEventListener('click', () => {
      navigator.clipboard.writeText(allLogs.join('\n')).then(() => {
        notify('Đã sao chép toàn bộ nhật ký vào Clipboard!', 'success');
      });
    });

    // DMT Checklist controls in Tab 2
    document.getElementById('fbDmtSearchInput')?.addEventListener('input', (e) => {
      dmtSearchQuery = (e.target.value || '').trim().toLowerCase();
      renderDmtChecklist();
    });
    document.getElementById('fbDmtFolderFilter')?.addEventListener('change', (e) => {
      dmtFilterFolder = e.target.value || 'ALL';
      renderDmtChecklist();
    });
    document.getElementById('fbDmtSelectAllBtn')?.addEventListener('click', () => {
      const visible = getFilteredDmtProfiles().map((p) => p.id);
      const set = new Set(fbConfig?.dmt_profile_ids || []);
      visible.forEach((id) => set.add(id));
      applySelectionArray('dmt', Array.from(set));
    });
    document.getElementById('fbDmtInvertBtn')?.addEventListener('click', () => {
      const visible = getFilteredDmtProfiles().map((p) => p.id);
      const set = new Set(fbConfig?.dmt_profile_ids || []);
      visible.forEach((id) => {
        if (set.has(id)) set.delete(id);
        else set.add(id);
      });
      applySelectionArray('dmt', Array.from(set));
    });
    document.getElementById('fbDmtDeselectAllBtn')?.addEventListener('click', () => {
      const visible = new Set(getFilteredDmtProfiles().map((p) => p.id));
      const next = (fbConfig?.dmt_profile_ids || []).filter((id) => !visible.has(id));
      applySelectionArray('dmt', next);
    });
    document.getElementById('fbSaveDmtProfilesBtn')?.addEventListener('click', () => {
      const ids = fbConfig?.dmt_profile_ids || [];
      if (fbConfig) fbConfig.engine = 'dmt';
      saveConfigWithToast(
        { engine: 'dmt', dmt_profile_ids: ids },
        `Đã lưu ${ids.length} Profile DMT Browser và chuyển sang chế độ DMT!`
      );
    });

    // GPM Checklist & Textarea controls in Tab 2
    document.getElementById('fbGpmSearchInput')?.addEventListener('input', (e) => {
      gpmSearchQuery = (e.target.value || '').trim().toLowerCase();
      renderGpmChecklist();
    });
    document.getElementById('fbToggleGpmEditModeBtn')?.addEventListener('click', () => {
      gpmEditMode = gpmEditMode === 'list' ? 'text' : 'list';
      const listWrap = document.getElementById('fbGpmChecklistWrap');
      const ta = document.getElementById('fbGpmProfilesTextarea');
      const tb = document.getElementById('fbGpmListToolbar');
      const btn = document.getElementById('fbToggleGpmEditModeBtn');
      if (gpmEditMode === 'text') {
        listWrap?.classList.add('hidden');
        tb?.classList.add('hidden');
        ta?.classList.remove('hidden');
        if (ta && fbConfig) {
          const allGpmIds = getAllKnownGpmProfiles().map((p) => p.id);
          ta.value = allGpmIds.join('\n');
        }
        if (btn) btn.textContent = 'Chế độ danh sách';
      } else {
        const lines = parseLines(ta?.value);
        if (fbConfig) {
          const prevAll = new Set(fbConfig.gpm_all_profile_ids || []);
          const prevSel = new Set(fbConfig.gpm_profile_ids || []);
          const nextSel = lines.filter((id) => prevSel.has(id) || !prevAll.has(id));
          fbConfig.gpm_all_profile_ids = lines;
          fbConfig.gpm_profile_ids = nextSel.length > 0 ? nextSel : [...lines];
          saveConfigQuiet({
            gpm_all_profile_ids: fbConfig.gpm_all_profile_ids,
            gpm_profile_ids: fbConfig.gpm_profile_ids,
          });
        }
        ta?.classList.add('hidden');
        listWrap?.classList.remove('hidden');
        tb?.classList.remove('hidden');
        if (btn) btn.textContent = 'Sửa dạng văn bản (ID)';
        renderGpmChecklist();
        lastRenderedDashSignature = '';
        renderMonitoredProfiles();
      }
    });
    document.getElementById('fbGpmSelectAllBtn')?.addEventListener('click', () => {
      const allIds = getAllKnownGpmProfiles().map((p) => p.id);
      applySelectionArray('gpm', allIds);
    });
    document.getElementById('fbGpmDeselectAllBtn')?.addEventListener('click', () => {
      applySelectionArray('gpm', []);
    });
    document.getElementById('fbGpmProfilesTextarea')?.addEventListener('input', () => {
      const lines = parseLines(document.getElementById('fbGpmProfilesTextarea')?.value);
      const summaryEl = document.getElementById('fbGpmCountSummary');
      if (summaryEl) summaryEl.textContent = `Tổng danh sách: ${lines.length} GPM Profile`;
    });
    document.getElementById('fbFetchGpmApiProfilesBtn')?.addEventListener('click', () => fetchGpmProfilesFromApi(true));
    document.getElementById('fbSaveGpmProfilesBtn')?.addEventListener('click', () => {
      if (gpmEditMode === 'text') {
        const lines = parseLines(document.getElementById('fbGpmProfilesTextarea')?.value);
        if (fbConfig) {
          const prevAll = new Set(fbConfig.gpm_all_profile_ids || []);
          const prevSel = new Set(fbConfig.gpm_profile_ids || []);
          const nextSel = lines.filter((id) => prevSel.has(id) || !prevAll.has(id));
          fbConfig.gpm_all_profile_ids = lines;
          fbConfig.gpm_profile_ids = nextSel.length > 0 ? nextSel : [...lines];
        }
        // Chuyển luôn về chế độ danh sách để người dùng tích chọn dễ dàng
        gpmEditMode = 'list';
        document.getElementById('fbGpmProfilesTextarea')?.classList.add('hidden');
        document.getElementById('fbGpmChecklistWrap')?.classList.remove('hidden');
        document.getElementById('fbGpmListToolbar')?.classList.remove('hidden');
        const toggleBtn = document.getElementById('fbToggleGpmEditModeBtn');
        if (toggleBtn) toggleBtn.textContent = 'Sửa dạng văn bản (ID)';
      }
      const allIds = fbConfig?.gpm_all_profile_ids || [];
      const selectedIds = fbConfig?.gpm_profile_ids || [];
      if (fbConfig) fbConfig.engine = 'gpm';
      saveConfigWithToast(
        {
          engine: 'gpm',
          gpm_all_profile_ids: allIds,
          gpm_profile_ids: selectedIds,
        },
        `Đã lưu ${allIds.length} Profile GPMLogin (đang chọn ${selectedIds.length} Profile) và chuyển sang chế độ GPM!`
      );
    });

    // Target Users actions
    document.getElementById('fbTargetUsersTextarea')?.addEventListener('input', () => {
      const lines = parseLines(document.getElementById('fbTargetUsersTextarea')?.value);
      const badge = document.getElementById('fbTargetUsersCountBadge');
      if (badge) badge.textContent = `${lines.length} Tên`;
    });
    document.getElementById('fbSaveTargetUsersBtn')?.addEventListener('click', () => {
      const lines = parseLines(document.getElementById('fbTargetUsersTextarea')?.value);
      if (fbConfig) fbConfig.target_users = lines;
      saveConfigWithToast(
        { target_users: lines },
        `Đã lưu ${lines.length} Tên người đăng mục tiêu vào user.txt!`
      );
    });

    document.getElementById('fbCommentTextsTextarea')?.addEventListener('input', () => {
      const lines = parseLines(document.getElementById('fbCommentTextsTextarea')?.value);
      const badge = document.getElementById('fbCommentCountBadge');
      if (badge) badge.textContent = `${lines.length} câu`;
    });

    // Sliders in Settings
    const sliderBindings = [
      ['fbSliderThreads', 'fbValThreads', ''],
      ['fbSliderShareGroups', 'fbValShareGroups', ''],
      ['fbSliderReels', 'fbValReels', ''],
      ['fbSliderFeed', 'fbValFeed', ''],
      ['fbSliderVisit', 'fbValVisit', ''],
      ['fbSliderRepeatDelay', 'fbValRepeatDelay', ' phút'],
    ];
    sliderBindings.forEach(([sliderId, valId, suffix]) => {
      const sl = document.getElementById(sliderId);
      const vl = document.getElementById(valId);
      if (sl && vl) {
        sl.addEventListener('input', () => {
          vl.textContent = `${sl.value}${suffix}`;
          if (sliderId === 'fbSliderRepeatDelay') {
            const dashInput = document.getElementById('fbDashRepeatDelayInput');
            if (dashInput) dashInput.value = sl.value;
          }
        });
      }
    });

    document.getElementById('fbSaveAllSettingsBtn')?.addEventListener('click', saveAllSettingsFromPage);

    ['fbInputWinWidth', 'fbInputWinHeight', 'fbInputWinScale'].forEach((id) => {
      document.getElementById(id)?.addEventListener('change', () => {
        const payload = {
          window_width: parseInt(document.getElementById('fbInputWinWidth')?.value || '1100', 10),
          window_height: parseInt(document.getElementById('fbInputWinHeight')?.value || '900', 10),
          window_scale: (function() {
            const v = parseFloat(document.getElementById('fbInputWinScale')?.value || '60');
            return v > 5 ? Math.round(v) / 100.0 : v;
          })(),
        };
        saveConfigQuiet(payload);
      });
    });

    ['fbChkWindowLayout', 'fbChkAutoFitScreen', 'fbChkSkipProxy'].forEach((id) => {
      document.getElementById(id)?.addEventListener('change', () => {
        saveConfigQuiet({
          enable_window_layout: !!document.getElementById('fbChkWindowLayout')?.checked,
          auto_fit_screen: !!document.getElementById('fbChkAutoFitScreen')?.checked,
          skip_proxy_check: !!document.getElementById('fbChkSkipProxy')?.checked,
        });
      });
    });

    document.getElementById('fbGpmApiBaseInput')?.addEventListener('change', () => {
      saveConfigQuiet({
        gpm_api_base: (document.getElementById('fbGpmApiBaseInput')?.value || 'http://127.0.0.1:9495/api/v1').trim(),
      });
    });

    // Campaign Mapping events
    document.getElementById('fbDashGoCampaignsBtn')?.addEventListener('click', () => switchSubTab('profiles'));
    document.getElementById('fbDashManageCampaignsBtn')?.addEventListener('click', () => switchSubTab('profiles'));
    document.getElementById('fbAddCampaignBtn')?.addEventListener('click', addNewCampaign);
    document.getElementById('fbDashQuickAssignBtn')?.addEventListener('click', quickAssignSelectedProfilesToCampaign);

    document.getElementById('fbCampModalCloseBtn')?.addEventListener('click', closeCampaignProfileModal);
    document.getElementById('fbCampModalDoneBtn')?.addEventListener('click', closeCampaignProfileModal);
    document.getElementById('fbCampaignProfileModal')?.addEventListener('click', (e) => {
      if (e.target.id === 'fbCampaignProfileModal') closeCampaignProfileModal();
    });
    document.getElementById('fbCampModalSearchInput')?.addEventListener('input', (e) => {
      campaignModalSearch = (e.target.value || '').trim().toLowerCase();
      renderCampaignProfileModal();
    });
    document.getElementById('fbCampModalSelectAllBtn')?.addEventListener('click', () => {
      if (!editingCampaignId) return;
      const allProfs = getAllAvailableProfilesForCurrentEngine();
      const visibleIds = allProfs
        .filter((p) => {
          if (!campaignModalSearch) return true;
          return `${p.name || ''} ${p.id || ''} ${p.folder || ''}`.toLowerCase().includes(campaignModalSearch);
        })
        .map((p) => p.id);
      assignProfilesToCampaign(editingCampaignId, visibleIds, 'add');
    });
    document.getElementById('fbCampModalDeselectAllBtn')?.addEventListener('click', () => {
      if (!editingCampaignId) return;
      assignProfilesToCampaign(editingCampaignId, [], 'clear');
    });
  }

  // ==================== QUẢN LÝ CHIẾN DỊCH / NHÓM CHẠY NHIỀU THƯ MỤC ====================
  function getCampaignsList() {
    if (!fbConfig || !Array.isArray(fbConfig.campaigns)) return [];
    return fbConfig.campaigns;
  }

  function getShortFolderName(fullPath) {
    const raw = String(fullPath || '').trim();
    if (!raw) return 'Chưa chọn thư mục';
    const parts = raw.split(/[\\/]/).filter(Boolean);
    return parts.length >= 2 ? parts.slice(-2).join('/') : parts[0] || raw;
  }

  function getProfileCampaignInfo(pid) {
    const cleanPid = String(pid || '').trim();
    if (!cleanPid) return null;
    const campaigns = getCampaignsList();
    for (const c of campaigns) {
      const pids = Array.isArray(c.profile_ids) ? c.profile_ids : [];
      if (pids.includes(cleanPid)) {
        return {
          id: c.id,
          name: c.name || 'Chiến dịch',
          enabled: c.enabled !== false,
          content_dir: c.content_dir || '',
          folderShort: getShortFolderName(c.content_dir),
        };
      }
    }
    return null;
  }

  function getAllAvailableProfilesForCurrentEngine() {
    const engine = (fbConfig?.engine || 'dmt').toLowerCase();
    return engine === 'dmt' ? dmtProfiles : getAllKnownGpmProfiles();
  }

  async function addNewCampaign() {
    if (!fbConfig) return;
    const campaigns = [...getCampaignsList()];
    const nextNum = campaigns.length + 1;
    const newId = `camp_${Date.now().toString(36)}`;
    const newCamp = {
      id: newId,
      name: `Chiến dịch ${nextNum}`,
      enabled: true,
      content_dir: fbConfig.content_output_dir || '',
      profile_ids: [],
    };
    campaigns.push(newCamp);
    fbConfig.campaigns = campaigns;
    lastRenderedDashSignature = '';
    renderCampaignsSection();
    await saveConfigWithToast(
      { campaigns },
      `Đã tạo "${newCamp.name}"! Hãy chọn thư mục bài đăng và bấm "Chọn Profile" cho chiến dịch này.`
    );
  }

  async function deleteCampaign(campId) {
    if (!fbConfig) return;
    const campaigns = getCampaignsList().filter((c) => c.id !== campId);
    fbConfig.campaigns = campaigns;
    lastRenderedDashSignature = '';
    renderCampaignsSection();
    renderMonitoredProfiles();
    await saveConfigWithToast({ campaigns }, 'Đã xóa chiến dịch!');
  }

  async function pickFolderForCampaign(campId) {
    try {
      const res = await fetch(`${API_BASE}/pick-folder`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ campaign_id: campId }),
      });
      if (!res.ok) return;
      const data = await res.json();
      const chosen = data.selected || data.path;
      if (chosen) {
        fbConfig = data.config || fbConfig;
        campaignsInfo = data.campaigns_info || campaignsInfo;
        lastRenderedDashSignature = '';
        renderCampaignsSection();
        renderMonitoredProfiles();
        notify(`Đã lưu thư mục cho chiến dịch: ${chosen}`, 'success');
      }
    } catch (e) {
      notify('Không thể mở hộp thoại chọn thư mục', 'error');
    }
  }

  async function openSpecificFolder(folderPath) {
    try {
      await fetch(`${API_BASE}/open-folder`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: folderPath || '' }),
      });
    } catch (e) {}
  }

  function ensureProfilesActivatedInEngine(profileIds) {
    if (!fbConfig || !Array.isArray(profileIds) || profileIds.length === 0) return {};
    const engine = (fbConfig.engine || 'dmt').toLowerCase();
    if (engine === 'dmt') {
      const validDmtIds = profileIds.filter(isDmtProfileId).map((x) => String(x).trim());
      const set = new Set((fbConfig.dmt_profile_ids || []).filter(isDmtProfileId));
      validDmtIds.forEach((id) => set.add(id));
      fbConfig.dmt_profile_ids = Array.from(set).filter(Boolean);
      return { dmt_profile_ids: fbConfig.dmt_profile_ids };
    } else {
      const validGpmIds = profileIds.filter((id) => !isDmtProfileId(id)).map((x) => String(x).trim());
      const set = new Set((fbConfig.gpm_profile_ids || []).filter((id) => !isDmtProfileId(id)));
      validGpmIds.forEach((id) => set.add(id));
      fbConfig.gpm_profile_ids = Array.from(set).filter(Boolean);
      return { gpm_profile_ids: fbConfig.gpm_profile_ids };
    }
  }

  async function assignProfilesToCampaign(campId, targetProfileIds, mode = 'toggle_one') {
    if (!fbConfig) return;
    const campaigns = getCampaignsList().map((c) => ({
      ...c,
      profile_ids: Array.isArray(c.profile_ids) ? [...c.profile_ids] : [],
    }));
    const currentEngine = (fbConfig?.engine || 'dmt').toLowerCase();
    const cleanTarget = targetProfileIds.map((x) => String(x).trim()).filter(Boolean);
    const targetSet = new Set(
      currentEngine === 'dmt'
        ? cleanTarget.filter(isDmtProfileId)
        : cleanTarget.filter((id) => !isDmtProfileId(id))
    );

    if (campId === '__DEFAULT__') {
      // Gỡ các profile này khỏi mọi chiến dịch để quay về dùng thư mục mặc định
      campaigns.forEach((c) => {
        c.profile_ids = c.profile_ids.filter((id) => !targetSet.has(id));
      });
      fbConfig.campaigns = campaigns;
      lastRenderedDashSignature = '';
      renderCampaignsSection();
      renderMonitoredProfiles();
      await saveConfigWithToast(
        { campaigns },
        `Đã chuyển ${targetSet.size} Profile về dùng Thư mục mặc định!`
      );
      return;
    }

    const camp = campaigns.find((c) => c.id === campId);
    if (!camp) return;

    if (mode === 'clear') {
      camp.profile_ids = currentEngine === 'dmt'
        ? camp.profile_ids.filter((id) => !isDmtProfileId(id))
        : camp.profile_ids.filter(isDmtProfileId);
    } else if (mode === 'add') {
      // Gỡ khỏi các chiến dịch khác để tránh 1 nick nằm ở 2 chiến dịch
      campaigns.forEach((c) => {
        if (c.id !== campId) {
          c.profile_ids = c.profile_ids.filter((id) => !targetSet.has(id));
        }
      });
      // Nếu chiến dịch này có chứa các profile cũ của Engine khác bị lọt vào, làm sạch luôn
      const sanitizedOld = currentEngine === 'gpm'
        ? camp.profile_ids.filter((id) => !isDmtProfileId(id))
        : camp.profile_ids.filter(isDmtProfileId);
      const cur = new Set(sanitizedOld);
      targetSet.forEach((id) => cur.add(id));
      camp.profile_ids = Array.from(cur);
    } else if (mode === 'toggle_one') {
      const pid = Array.from(targetSet)[0];
      if (!pid) return;
      const cur = new Set(camp.profile_ids);
      if (cur.has(pid)) {
        cur.delete(pid);
      } else {
        campaigns.forEach((c) => {
          if (c.id !== campId) {
            c.profile_ids = c.profile_ids.filter((id) => id !== pid);
          }
        });
        cur.add(pid);
      }
      camp.profile_ids = Array.from(cur);
    }

    fbConfig.campaigns = campaigns;
    const extraEnginePayload = ensureProfilesActivatedInEngine(Array.from(targetSet));
    lastRenderedDashSignature = '';
    renderCampaignsSection();
    renderCampaignProfileModal();
    renderMonitoredProfiles();
    renderDmtChecklist();
    renderGpmChecklist();
    updateMetricsBar();
    await saveConfigQuiet({ campaigns, ...extraEnginePayload });
  }

  async function quickAssignSelectedProfilesToCampaign() {
    const selEl = document.getElementById('fbDashQuickCampaignSelect');
    const campId = selEl?.value || '';
    if (!campId) {
      notify('Vui lòng chọn Chiến dịch trong danh sách thả xuống (hoặc bấm Tạo Chiến dịch mới)!', 'info');
      return;
    }
    const activeIds = getActiveProfileIds();
    if (activeIds.length === 0) {
      notify('Vui lòng tích chọn (hoặc kéo chuột quét chọn) ít nhất 1 Profile bên dưới trước khi gán!', 'error');
      return;
    }
    if (campId === '__DEFAULT__') {
      await assignProfilesToCampaign('__DEFAULT__', activeIds, 'add');
      return;
    }
    const camp = getCampaignsList().find((c) => c.id === campId);
    await assignProfilesToCampaign(campId, activeIds, 'add');
    if (camp) {
      notify(
        `Đã gán ${activeIds.length} Profile vào "${camp.name}" (${getShortFolderName(camp.content_dir)}) và tự động lưu!`,
        'success'
      );
    }
  }

  function openCampaignProfileModal(campId) {
    editingCampaignId = campId;
    campaignModalSearch = '';
    const searchIn = document.getElementById('fbCampModalSearchInput');
    if (searchIn) searchIn.value = '';
    const modal = document.getElementById('fbCampaignProfileModal');
    modal?.classList.remove('hidden');
    renderCampaignProfileModal();
  }

  function closeCampaignProfileModal() {
    editingCampaignId = null;
    const modal = document.getElementById('fbCampaignProfileModal');
    modal?.classList.add('hidden');
  }

  function renderCampaignProfileModal() {
    const modal = document.getElementById('fbCampaignProfileModal');
    const listEl = document.getElementById('fbCampModalList');
    const titleEl = document.getElementById('fbCampModalTitle');
    const subEl = document.getElementById('fbCampModalSub');
    const countEl = document.getElementById('fbCampModalSelectedCount');
    if (!modal || !listEl || !editingCampaignId) return;

    const camp = getCampaignsList().find((c) => c.id === editingCampaignId);
    if (!camp) {
      closeCampaignProfileModal();
      return;
    }

    if (titleEl) titleEl.textContent = `Chọn Profile cho: ${camp.name}`;
    if (subEl) {
      subEl.textContent = camp.content_dir
        ? `Thư mục bài đăng: ${camp.content_dir}`
        : 'Chưa chọn thư mục bài đăng cho chiến dịch này';
    }

    const assignedSet = new Set(Array.isArray(camp.profile_ids) ? camp.profile_ids : []);
    const allProfs = getAllAvailableProfilesForCurrentEngine();
    const assignedInCurrentEngine = allProfs.filter((p) => assignedSet.has(p.id));
    if (countEl) {
      countEl.textContent = `Đã gán vào "${camp.name}": ${assignedInCurrentEngine.length} Profile`;
    }

    const filtered = allProfs.filter((p) => {
      if (!campaignModalSearch) return true;
      return `${p.name || ''} ${p.id || ''} ${p.folder || ''}`.toLowerCase().includes(campaignModalSearch);
    });

    if (filtered.length === 0) {
      listEl.innerHTML = `<div class="p-6 text-center text-xs text-slate-400">Không tìm thấy Profile nào khớp từ khóa.</div>`;
      return;
    }

    listEl.innerHTML = filtered
      .map((p, idx) => {
        const isAssignedHere = assignedSet.has(p.id);
        const otherCamp = getProfileCampaignInfo(p.id);
        const otherBadge =
          otherCamp && otherCamp.id !== camp.id
            ? `<span class="text-[10px] px-2 py-0.5 rounded bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800">Đang ở: ${esc(otherCamp.name)}</span>`
            : '';

        return `
          <div
            data-camp-pid="${esc(p.id)}"
            class="px-3 py-2 rounded-lg flex items-center justify-between gap-3 cursor-pointer transition ${
              isAssignedHere
                ? 'bg-violet-50/70 dark:bg-violet-950/30 border border-violet-200/80 dark:border-violet-800/60'
                : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
            }"
          >
            <div class="flex items-center gap-2.5 min-w-0">
              <input type="checkbox" ${isAssignedHere ? 'checked' : ''} class="w-4 h-4 accent-violet-600 rounded cursor-pointer shrink-0" />
              <div class="min-w-0">
                <div class="text-xs font-semibold text-slate-800 dark:text-slate-100 truncate">
                  ${idx + 1}. ${esc(p.name)} <span class="text-[10px] text-slate-400 mono">#${esc(String(p.id).slice(0, 8))}</span>
                </div>
                <div class="text-[10px] text-slate-500 dark:text-slate-400">
                  Nhóm gốc: <b>${esc(p.folder || 'Mặc định')}</b>
                </div>
              </div>
            </div>
            <div class="flex items-center gap-1.5 shrink-0">
              ${
                isAssignedHere
                  ? `<span class="text-[10px] px-2 py-0.5 rounded bg-violet-600 text-white font-semibold">Đã chọn</span>`
                  : otherBadge
              }
            </div>
          </div>
        `;
      })
      .join('');

    listEl.querySelectorAll('[data-camp-pid]').forEach((row) => {
      row.addEventListener('click', () => {
        const pid = row.getAttribute('data-camp-pid');
        if (pid && editingCampaignId) {
          assignProfilesToCampaign(editingCampaignId, [pid], 'toggle_one');
        }
      });
    });
  }

  function renderCampaignsSection() {
    const container = document.getElementById('fbCampaignsListContainer');
    const totalBadge = document.getElementById('fbCampaignTotalBadge');
    const metricCamp = document.getElementById('fbMetricCampaigns');
    const quickSelect = document.getElementById('fbDashQuickCampaignSelect');

    const campaigns = getCampaignsList();
    const activeCount = campaigns.filter((c) => c.enabled !== false).length;

    if (totalBadge) {
      totalBadge.textContent = `${campaigns.length} Chiến dịch (${activeCount} đang bật)`;
    }
    if (metricCamp) {
      metricCamp.textContent = `Chiến dịch: ${activeCount}/${campaigns.length}`;
    }

    const currentEngine = (fbConfig?.engine || 'dmt').toLowerCase();

    if (quickSelect && document.activeElement !== quickSelect) {
      const prevVal = quickSelect.value;
      quickSelect.innerHTML =
        `<option value="">-- Chọn Chiến dịch / Thư mục bài --</option>` +
        campaigns
          .map((c) => {
            const pids = Array.isArray(c.profile_ids) ? c.profile_ids : [];
            const activeNickCount = currentEngine === 'dmt'
              ? pids.filter(isDmtProfileId).length
              : pids.filter((id) => !isDmtProfileId(id)).length;
            return `<option value="${esc(c.id)}">🗂️ ${esc(c.name)} (📁 ${esc(getShortFolderName(c.content_dir))} • ${activeNickCount} nick)</option>`;
          })
          .join('') +
        `<option value="__DEFAULT__">📁 Gỡ khỏi chiến dịch (Dùng thư mục mặc định)</option>`;
      if (prevVal) quickSelect.value = prevVal;
    }

    if (!container) return;

    if (campaigns.length === 0) {
      container.innerHTML = `
        <div class="col-span-full py-6 px-4 rounded-xl border border-dashed border-violet-300 dark:border-violet-800/70 bg-violet-50/30 dark:bg-violet-950/15 text-center">
          <div class="text-xs font-bold text-slate-700 dark:text-slate-200 mb-1">
            Chưa có Chiến dịch chia thư mục riêng nào
          </div>
          <p class="text-[11px] text-slate-500 dark:text-slate-400 max-w-xl mx-auto">
            Hiện tại tất cả Profile đang lấy bài từ <b>Thư mục mặc định</b> bên dưới. Nếu bạn muốn chia <b>Mỗi thư mục bài đăng cho 1 nhóm Profile riêng</b>, hãy bấm nút <b>"+ Thêm Chiến Dịch / Thư Mục Mới"</b> ở góc phải phía trên!
          </p>
        </div>
      `;
      return;
    }

    const allKnownMap = new Map();
    dmtProfiles.forEach((p) => allKnownMap.set(String(p.id), p.name));
    getAllKnownGpmProfiles().forEach((p) => {
      if (!allKnownMap.has(String(p.id))) allKnownMap.set(String(p.id), p.name);
    });

    container.innerHTML = campaigns
      .map((c, idx) => {
        const cid = c.id;
        const isEnabled = c.enabled !== false;
        const pids = Array.isArray(c.profile_ids) ? c.profile_ids : [];
        const activeEnginePids = currentEngine === 'dmt'
          ? pids.filter(isDmtProfileId)
          : pids.filter((id) => !isDmtProfileId(id));
        const info = (campaignsInfo && campaignsInfo[cid]) || { txt_count: 0, img_count: 0 };
        const previewNames = activeEnginePids
          .slice(0, 4)
          .map((id) => allKnownMap.get(String(id)) || `#${String(id).slice(0, 6)}`)
          .join(', ');
        const moreCount = activeEnginePids.length > 4 ? ` +${activeEnginePids.length - 4} nick khác` : '';

        return `
          <div
            data-camp-card="${esc(cid)}"
            class="rounded-xl border p-3.5 transition flex flex-col gap-2.5 ${
              isEnabled
                ? 'bg-violet-50/25 dark:bg-violet-950/15 border-violet-300 dark:border-violet-800/80 shadow-xs'
                : 'bg-slate-50/60 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800 opacity-70'
            }"
          >
            <!-- Hàng 1: Bật/Tắt + Tên Chiến Dịch + Thống kê bài + Xóa -->
            <div class="flex items-center justify-between gap-2">
              <div class="flex items-center gap-2 flex-1 min-w-0">
                <input
                  type="checkbox"
                  data-camp-toggle="${esc(cid)}"
                  ${isEnabled ? 'checked' : ''}
                  title="Bật / Tắt chiến dịch này"
                  class="w-4 h-4 accent-violet-600 rounded cursor-pointer shrink-0"
                />
                <span class="text-[11px] font-bold text-violet-600 dark:text-violet-400 mono shrink-0">#${idx + 1}</span>
                <input
                  type="text"
                  data-camp-name="${esc(cid)}"
                  value="${esc(c.name || '')}"
                  placeholder="Tên chiến dịch (VD: Nhóm BĐS)..."
                  class="flex-1 min-w-0 px-2.5 py-1 rounded-md bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-white focus:border-violet-500 focus:outline-none"
                />
              </div>

              <div class="flex items-center gap-1.5 shrink-0">
                <span class="text-[10px] px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 font-bold mono">
                  ${info.txt_count || 0} bài · ${info.img_count || 0} ảnh
                </span>
                <button
                  type="button"
                  data-camp-del="${esc(cid)}"
                  title="Xóa chiến dịch này"
                  class="w-6 h-6 rounded-md hover:bg-rose-100 dark:hover:bg-rose-950/60 text-slate-400 hover:text-rose-500 flex items-center justify-center transition"
                >
                  <i class="fa-regular fa-trash-can text-xs"></i>
                </button>
              </div>
            </div>

            <!-- Hàng 2: Đường dẫn Thư mục bài đăng riêng của Chiến dịch -->
            <div class="flex items-center gap-1.5">
              <div class="relative flex-1 min-w-0">
                <i class="fa-regular fa-folder-open absolute left-2.5 top-1/2 -translate-y-1/2 text-amber-500 text-xs"></i>
                <input
                  type="text"
                  data-camp-dir="${esc(cid)}"
                  value="${esc(c.content_dir || '')}"
                  placeholder="Chọn thư mục chứa bài đăng & ảnh riêng cho nhóm này..."
                  class="w-full pl-8 pr-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 mono text-[11px] text-slate-700 dark:text-slate-200 focus:border-violet-500 focus:outline-none"
                />
              </div>
              <button
                type="button"
                data-camp-browse="${esc(cid)}"
                class="px-2.5 py-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/50 hover:bg-amber-100 border border-amber-200 dark:border-amber-800/70 text-amber-700 dark:text-amber-300 text-xs font-semibold flex items-center gap-1 shrink-0 transition"
                title="Chọn thư mục bài đăng cho chiến dịch này"
              >
                <i class="fa-regular fa-folder-open"></i>
                <span>Chọn thư mục</span>
              </button>
              <button
                type="button"
                data-camp-open="${esc(cid)}"
                class="px-2 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-600 dark:text-slate-300 text-xs shrink-0 transition"
                title="Mở thư mục này trong Windows Explorer"
              >
                <i class="fa-solid fa-arrow-up-right-from-square"></i>
              </button>
            </div>

            <!-- Hàng 3: Nhóm Profile được gán vào Chiến dịch -->
            <div class="pt-1.5 border-t border-slate-200/60 dark:border-slate-800/80 flex items-center justify-between gap-2">
              <div class="min-w-0 flex-1 text-[11px] text-slate-600 dark:text-slate-300 truncate">
                <span class="font-semibold text-violet-700 dark:text-violet-300">👥 ${activeEnginePids.length} Profile:</span>
                <span class="ml-1 text-slate-500 dark:text-slate-400">
                  ${activeEnginePids.length > 0 ? esc(previewNames + moreCount) : 'Chưa gán nick nào (Bấm nút bên phải để chọn)'}
                </span>
              </div>
              <button
                type="button"
                data-camp-pick-profs="${esc(cid)}"
                class="px-3 py-1 rounded-lg bg-violet-600 hover:bg-violet-500 text-white text-[11px] font-semibold flex items-center gap-1.5 shrink-0 transition shadow-2xs"
              >
                <i class="fa-solid fa-user-check text-[10px]"></i>
                <span>Chọn Profile (${activeEnginePids.length})</span>
              </button>
            </div>
          </div>
        `;
      })
      .join('');

    // Gắn sự kiện cho từng thẻ Chiến dịch
    container.querySelectorAll('[data-camp-toggle]').forEach((chk) => {
      chk.addEventListener('change', (e) => {
        const cid = chk.getAttribute('data-camp-toggle');
        const camp = getCampaignsList().find((x) => x.id === cid);
        if (!camp) return;
        camp.enabled = !!e.target.checked;
        lastRenderedDashSignature = '';
        renderCampaignsSection();
        renderMonitoredProfiles();
        saveConfigQuiet({ campaigns: fbConfig.campaigns });
      });
    });

    container.querySelectorAll('[data-camp-name]').forEach((inp) => {
      inp.addEventListener('change', (e) => {
        const cid = inp.getAttribute('data-camp-name');
        const camp = getCampaignsList().find((x) => x.id === cid);
        if (!camp) return;
        camp.name = (e.target.value || '').trim() || 'Chiến dịch';
        lastRenderedDashSignature = '';
        renderCampaignsSection();
        renderMonitoredProfiles();
        saveConfigQuiet({ campaigns: fbConfig.campaigns });
      });
    });

    container.querySelectorAll('[data-camp-dir]').forEach((inp) => {
      inp.addEventListener('change', (e) => {
        const cid = inp.getAttribute('data-camp-dir');
        const camp = getCampaignsList().find((x) => x.id === cid);
        if (!camp) return;
        camp.content_dir = (e.target.value || '').trim();
        lastRenderedDashSignature = '';
        saveConfigWithToast(
          { campaigns: fbConfig.campaigns },
          `Đã lưu thư mục bài đăng cho "${camp.name}"!`
        );
      });
    });

    container.querySelectorAll('[data-camp-browse]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const cid = btn.getAttribute('data-camp-browse');
        if (cid) pickFolderForCampaign(cid);
      });
    });

    container.querySelectorAll('[data-camp-open]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const cid = btn.getAttribute('data-camp-open');
        const camp = getCampaignsList().find((x) => x.id === cid);
        if (camp) openSpecificFolder(camp.content_dir || fbConfig?.content_output_dir || '');
      });
    });

    container.querySelectorAll('[data-camp-del]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const cid = btn.getAttribute('data-camp-del');
        if (cid) deleteCampaign(cid);
      });
    });

    container.querySelectorAll('[data-camp-pick-profs]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const cid = btn.getAttribute('data-camp-pick-profs');
        if (cid) openCampaignProfileModal(cid);
      });
    });
  }

  function parseLines(raw) {
    return (raw || '')
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter((l) => l && !l.startsWith('#'));
  }

  function switchSubTab(tabName) {
    currentSubTab = tabName;
    const pages = {
      dash: document.getElementById('fbPageDash'),
      profiles: document.getElementById('fbPageProfiles'),
      settings: document.getElementById('fbPageSettings'),
      logs: document.getElementById('fbPageLogs'),
    };
    Object.entries(pages).forEach(([k, el]) => {
      if (!el) return;
      if (k === tabName) el.classList.remove('hidden');
      else el.classList.add('hidden');
    });

    document.querySelectorAll('.fb-tab-btn').forEach((btn) => {
      const t = btn.getAttribute('data-fb-tab');
      if (t === tabName) {
        btn.className =
          'fb-tab-btn px-3.5 py-1.5 rounded-md text-xs font-semibold flex items-center gap-2 bg-[#1677ff] text-white shadow-xs transition';
      } else {
        btn.className =
          'fb-tab-btn px-3.5 py-1.5 rounded-md text-xs font-medium flex items-center gap-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition';
      }
    });
  }

  function switchProfileConfigTab(mode) {
    profileConfigTab = mode === 'gpm' ? 'gpm' : 'dmt';
    const paneDmt = document.getElementById('fbProfPaneDmt');
    const paneGpm = document.getElementById('fbProfPaneGpm');
    const btnDmt = document.getElementById('fbProfTabBtnDmt');
    const btnGpm = document.getElementById('fbProfTabBtnGpm');

    if (profileConfigTab === 'dmt') {
      paneDmt?.classList.remove('hidden');
      paneGpm?.classList.add('hidden');
      if (btnDmt)
        btnDmt.className =
          'px-3 py-1 rounded-md text-xs font-semibold bg-[#1677ff] text-white transition flex items-center gap-1.5';
      if (btnGpm)
        btnGpm.className =
          'px-3 py-1 rounded-md text-xs font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition flex items-center gap-1.5';
    } else {
      paneDmt?.classList.add('hidden');
      paneGpm?.classList.remove('hidden');
      if (btnGpm)
        btnGpm.className =
          'px-3 py-1 rounded-md text-xs font-semibold bg-indigo-600 text-white transition flex items-center gap-1.5';
      if (btnDmt)
        btnDmt.className =
          'px-3 py-1 rounded-md text-xs font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition flex items-center gap-1.5';
      renderGpmChecklist();
    }
  }

  async function setEngine(engine, persist = true) {
    const clean = engine === 'gpm' ? 'gpm' : 'dmt';
    if (fbConfig) fbConfig.engine = clean;
    switchProfileConfigTab(clean);
    renderEngineUI();
    lastRenderedDashSignature = '';
    renderMonitoredProfiles();
    updateMetricsBar();
    if (persist) {
      await saveConfigQuiet({ engine: clean });
      notify(
        clean === 'dmt'
          ? 'Đã chuyển sang chế độ Profile DMT Browser (Camoufox C++)'
          : 'Đã chuyển sang chế độ Profile GPMLogin (Port 9495)',
        'info'
      );
    }
  }

  function updateEngineCounters() {
    if (!fbConfig) return;
    const dmtSet = new Set(dmtProfiles.map((p) => p.id));
    const validDmtCount = (fbConfig.dmt_profile_ids || []).filter((id) => dmtSet.has(id)).length;
    const gpmCount = (fbConfig.gpm_profile_ids || []).length;

    const cDmt = document.getElementById('fbEngineCountDmt');
    const cGpm = document.getElementById('fbEngineCountGpm');
    if (cDmt) cDmt.textContent = String(validDmtCount);
    if (cGpm) cGpm.textContent = String(gpmCount);
  }

  function renderEngineUI() {
    const engine = (fbConfig?.engine || 'dmt').toLowerCase();
    updateEngineCounters();

    const btnDmt = document.getElementById('fbEngineBtnDmt');
    const btnGpm = document.getElementById('fbEngineBtnGpm');
    const hintEl = document.getElementById('fbActiveEngineHint');
    const startDesc = document.getElementById('fbStartCardDesc');
    const folderFilterEl = document.getElementById('fbDashFolderFilter');

    if (engine === 'dmt') {
      if (btnDmt)
        btnDmt.className =
          'px-3 py-1 rounded-md text-xs font-semibold flex items-center gap-1.5 bg-[#1677ff] text-white shadow-xs transition';
      if (btnGpm)
        btnGpm.className =
          'px-3 py-1 rounded-md text-xs font-medium flex items-center gap-1.5 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition';
      if (hintEl) hintEl.textContent = 'Đang dùng: Profile DMT Browser';
      folderFilterEl?.classList.remove('hidden');
      if (startDesc && !runtimeState.is_running) {
        startDesc.textContent = `Chế độ DMT Browser • Đã chọn ${getActiveProfileIds().length} Profile`;
      }
    } else {
      if (btnGpm)
        btnGpm.className =
          'px-3 py-1 rounded-md text-xs font-semibold flex items-center gap-1.5 bg-indigo-600 text-white shadow-xs transition';
      if (btnDmt)
        btnDmt.className =
          'px-3 py-1 rounded-md text-xs font-medium flex items-center gap-1.5 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition';
      if (hintEl) hintEl.textContent = 'Đang dùng: Profile GPMLogin';
      folderFilterEl?.classList.add('hidden');
      if (startDesc && !runtimeState.is_running) {
        startDesc.textContent = `Chế độ GPMLogin • Đã chọn ${getActiveProfileIds().length} Profile`;
      }
    }
  }

  function getActiveProfileIds() {
    if (!fbConfig) return [];
    const engine = (fbConfig.engine || 'dmt').toLowerCase();
    if (engine === 'dmt') {
      const validSet = new Set(dmtProfiles.map((p) => p.id));
      return (fbConfig.dmt_profile_ids || []).filter((id) => validSet.has(id));
    }
    return (fbConfig.gpm_profile_ids || []).filter((id) => !isDmtProfileId(id));
  }

  function getAllKnownGpmProfiles() {
    const map = new Map();
    (gpmApiProfiles || []).forEach((p) => {
      if (p && p.id && !isDmtProfileId(p.id)) {
        map.set(String(p.id), {
          id: String(p.id),
          name: p.name || `GPM Profile ${String(p.id).slice(0, 8)}`,
          folder: 'GPMLogin',
          proxy: '',
        });
      }
    });
    const manualIds = [
      ...(fbConfig?.gpm_all_profile_ids || []),
      ...(fbConfig?.gpm_profile_ids || []),
    ];
    manualIds.forEach((id) => {
      const clean = String(id).trim();
      if (clean && !isDmtProfileId(clean) && !map.has(clean)) {
        map.set(clean, {
          id: clean,
          name: `GPM ID: ${clean.slice(0, 12)}...`,
          folder: 'id_profile.txt',
          proxy: '',
        });
      }
    });
    return Array.from(map.values());
  }

  function getDashboardCandidateProfiles() {
    const engine = (fbConfig?.engine || 'dmt').toLowerCase();
    if (engine === 'dmt') {
      return dmtProfiles.filter((p) => {
        if (dashFilterFolder !== 'ALL' && (p.folder || 'Mặc định') !== dashFilterFolder) {
          return false;
        }
        if (dashSearchQuery) {
          const hay = `${p.name || ''} ${p.id || ''} ${p.notes || ''} ${p.proxy || ''}`.toLowerCase();
          if (!hay.includes(dashSearchQuery)) return false;
        }
        return true;
      });
    } else {
      const allGpm = getAllKnownGpmProfiles();
      return allGpm.filter((p) => {
        if (dashSearchQuery) {
          const hay = `${p.name || ''} ${p.id || ''}`.toLowerCase();
          if (!hay.includes(dashSearchQuery)) return false;
        }
        return true;
      });
    }
  }

  // ==================== 5. HIỂN THỊ BẢNG PROFILE TRÊN DASHBOARD & TAB 2 ====================
  function renderMonitoredProfiles() {
    if (isMarqueeDragging) return;
    const container = document.getElementById('fbMonitoredProfilesList');
    const countLabel = document.getElementById('fbMonitoredCountLabel');
    const folderSelect = document.getElementById('fbDashFolderFilter');
    if (!container) return;

    const engine = (fbConfig?.engine || 'dmt').toLowerCase();

    if (folderSelect && engine === 'dmt' && document.activeElement !== folderSelect) {
      const folders = Array.from(new Set(dmtProfiles.map((p) => p.folder || 'Mặc định')));
      const prev = folderSelect.value || 'ALL';
      folderSelect.innerHTML =
        `<option value="ALL">Tất cả nhóm (${dmtProfiles.length})</option>` +
        folders.map((f) => `<option value="${esc(f)}">${esc(f)}</option>`).join('');
      if (folders.includes(prev) || prev === 'ALL') folderSelect.value = prev;
    }

    const candidates = getDashboardCandidateProfiles();
    const selectedIds = new Set(getActiveProfileIds());
    const totalAvailable = engine === 'dmt' ? dmtProfiles.length : getAllKnownGpmProfiles().length;

    if (countLabel) {
      countLabel.textContent = `Đã chọn: ${selectedIds.size}/${totalAvailable}`;
    }

    if (candidates.length === 0) {
      lastRenderedDashSignature = 'EMPTY';
      container.innerHTML = `
        <div class="py-12 text-center text-xs text-slate-400">
          Không tìm thấy Profile nào trong danh sách <b>${engine === 'dmt' ? 'DMT Browser' : 'GPMLogin'}</b>.
        </div>
      `;
      return;
    }

    const campSig = getCampaignsList()
      .map((c) => `${c.id}:${c.name}:${c.enabled}:${c.content_dir}:${(c.profile_ids || []).join('|')}`)
      .join(';');
    const sig = `${engine}:${candidates.map((c) => c.id).join(',')}:${campSig}`;
    if (sig === lastRenderedDashSignature && container.querySelectorAll('.fb-selectable-row').length === candidates.length) {
      container.querySelectorAll('.fb-selectable-row').forEach((row) => {
        const pid = row.getAttribute('data-pid');
        if (!pid) return;
        const isSel = selectedIds.has(pid);
        const st = (runtimeState.profile_states && runtimeState.profile_states[pid]) || {
          status: isSel ? 'Sẵn sàng thực thi' : 'Chưa chọn',
          badge: isSel ? 'Sẵn sàng' : 'Bỏ qua',
          color: isSel ? '#3b82f6' : '#94a3b8',
        };
        row.className = `fb-selectable-row grid grid-cols-12 gap-2 items-center px-3.5 py-2 text-xs transition cursor-pointer ${
          isSel
            ? 'row-selected bg-blue-50/40 dark:bg-blue-950/20'
            : 'hover:bg-slate-50 dark:hover:bg-slate-800/40 opacity-75 hover:opacity-100'
        }`;
        const chk = row.querySelector('input[type="checkbox"]');
        if (chk) chk.checked = isSel;
        const statusEl = row.querySelector('.fb-row-status-text');
        if (statusEl) statusEl.textContent = st.status;
        const badgeEl = row.querySelector('.fb-row-badge');
        if (badgeEl) {
          badgeEl.textContent = st.badge.replace(/^(?:⏳|🟢|🔵|🟣|🟠|⏹️|✅|❌|⚪|➖|🔐|🔄|🌸)\s*/u, '');
          badgeEl.style.color = st.color;
          badgeEl.style.borderColor = `${st.color}40`;
          badgeEl.style.backgroundColor = `${st.color}12`;
        }
      });
      return;
    }

    lastRenderedDashSignature = sig;

    container.innerHTML = candidates
      .map((p, idx) => {
        const pid = p.id;
        const isSel = selectedIds.has(pid);
        const st = (runtimeState.profile_states && runtimeState.profile_states[pid]) || {
          status: isSel ? 'Sẵn sàng thực thi' : 'Chưa chọn',
          badge: isSel ? 'Sẵn sàng' : 'Bỏ qua',
          color: isSel ? '#3b82f6' : '#94a3b8',
        };
        const cleanBadge = (st.badge || '').replace(/^(?:⏳|🟢|🔵|🟣|🟠|⏹️|✅|❌|⚪|➖|🔐|🔄|🌸)\s*/u, '');
        const proxyRaw = (p.proxy || '').trim();
        const proxyShort = proxyRaw ? proxyRaw.split(':').slice(0, 2).join(':') : 'Local IP';
        const campInfo = getProfileCampaignInfo(pid);
        const campBadgeHtml = campInfo
          ? `<div class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded ${
              campInfo.enabled
                ? 'bg-violet-50 dark:bg-violet-950/60 text-violet-700 dark:text-violet-300 border border-violet-200 dark:border-violet-800/70'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-400 line-through'
            } text-[10px] font-semibold max-w-full truncate" title="Chiến dịch: ${esc(campInfo.name)} | Thư mục: ${esc(campInfo.content_dir)}">
              <span>🗂️ ${esc(campInfo.name)}</span>
              <span class="opacity-75 mono">• 📁 ${esc(campInfo.folderShort)}</span>
            </div>`
          : `<div class="text-[10px] text-slate-400 truncate" title="Dùng thư mục bài đăng mặc định">📁 Thư mục mặc định</div>`;

        return `
          <div
            data-pid="${esc(pid)}"
            data-idx="${idx}"
            class="fb-selectable-row grid grid-cols-12 gap-2 items-center px-3.5 py-2 text-xs transition cursor-pointer ${
              isSel
                ? 'row-selected bg-blue-50/40 dark:bg-blue-950/20'
                : 'hover:bg-slate-50 dark:hover:bg-slate-800/40 opacity-75 hover:opacity-100'
            }"
          >
            <!-- Cột 1: Checkbox + STT + Tên Profile -->
            <div class="col-span-5 flex items-center gap-2.5 min-w-0">
              <input type="checkbox" ${isSel ? 'checked' : ''} class="w-3.5 h-3.5 accent-[#1677ff] rounded cursor-pointer shrink-0" />
              <span class="text-[11px] text-slate-400 mono w-5 shrink-0">${idx + 1}.</span>
              <div class="min-w-0 truncate">
                <div class="font-semibold text-slate-800 dark:text-slate-100 truncate">${esc(p.name)}</div>
                <div class="text-[10px] text-slate-400 mono">#${esc(String(pid).slice(0, 8))}</div>
              </div>
            </div>

            <!-- Cột 2: Chiến dịch (Thư mục bài) & Nhóm/Proxy -->
            <div class="col-span-4 min-w-0 flex flex-col items-start gap-0.5">
              ${campBadgeHtml}
              <div class="text-[10px] text-slate-500 dark:text-slate-400 truncate max-w-full">
                ${esc(p.folder || 'Mặc định')} • <span class="mono">${esc(proxyShort)}</span>
              </div>
            </div>

            <!-- Cột 3: Trạng thái & Badge -->
            <div class="col-span-3 flex flex-col items-end justify-center min-w-0 text-right">
              <span
                class="fb-row-badge text-[10px] px-2 py-0.5 rounded font-semibold border whitespace-nowrap"
                style="color: ${st.color}; border-color: ${st.color}40; background-color: ${st.color}12"
              >
                ${esc(cleanBadge)}
              </span>
              <span class="fb-row-status-text text-[10px] text-slate-500 dark:text-slate-400 truncate max-w-full mt-0.5">
                ${esc(st.status)}
              </span>
            </div>
          </div>
        `;
      })
      .join('');

    container.querySelectorAll('.fb-selectable-row').forEach((row) => {
      row.addEventListener('click', (e) => {
        if (window._fbJustFinishedMarquee) return;
        const pid = row.getAttribute('data-pid');
        const idx = parseInt(row.getAttribute('data-idx') || '0', 10);
        if (!pid) return;

        const isCheckbox = e.target.tagName === 'INPUT';
        const currentEngine = (fbConfig?.engine || 'dmt').toLowerCase();
        const currentSet = new Set(getActiveProfileIds());
        const targetState = isCheckbox ? e.target.checked : !currentSet.has(pid);

        if (e.shiftKey && lastClickedIdxDash !== -1) {
          const start = Math.min(lastClickedIdxDash, idx);
          const end = Math.max(lastClickedIdxDash, idx);
          for (let i = start; i <= end; i++) {
            if (candidates[i]) {
              if (targetState) currentSet.add(candidates[i].id);
              else currentSet.delete(candidates[i].id);
            }
          }
        } else {
          if (targetState) currentSet.add(pid);
          else currentSet.delete(pid);
        }
        lastClickedIdxDash = idx;
        applySelectionArray(currentEngine, Array.from(currentSet), true);
      });
    });
  }

  function getFilteredDmtProfiles() {
    return dmtProfiles.filter((p) => {
      if (dmtFilterFolder !== 'ALL' && (p.folder || 'Mặc định') !== dmtFilterFolder) {
        return false;
      }
      if (dmtSearchQuery) {
        const hay = `${p.name || ''} ${p.id || ''} ${p.notes || ''} ${p.proxy || ''}`.toLowerCase();
        if (!hay.includes(dmtSearchQuery)) return false;
      }
      return true;
    });
  }

  function renderDmtChecklist() {
    const container = document.getElementById('fbDmtChecklistContainer');
    const summaryEl = document.getElementById('fbDmtSelectedSummary');
    const folderSelect = document.getElementById('fbDmtFolderFilter');
    if (!container) return;

    if (folderSelect && document.activeElement !== folderSelect) {
      const folders = Array.from(new Set(dmtProfiles.map((p) => p.folder || 'Mặc định')));
      const prev = folderSelect.value || 'ALL';
      folderSelect.innerHTML =
        `<option value="ALL">Tất cả nhóm (${dmtProfiles.length})</option>` +
        folders.map((f) => `<option value="${esc(f)}">${esc(f)}</option>`).join('');
      if (folders.includes(prev) || prev === 'ALL') folderSelect.value = prev;
    }

    const filtered = getFilteredDmtProfiles();
    const selectedSet = new Set(fbConfig?.dmt_profile_ids || []);

    if (summaryEl) {
      summaryEl.textContent = `Đã chọn: ${selectedSet.size} / ${dmtProfiles.length} Profile DMT`;
    }

    if (filtered.length === 0) {
      container.innerHTML = `<div class="p-6 text-center text-xs text-slate-400">Không có Profile DMT nào khớp bộ lọc.</div>`;
      return;
    }

    container.innerHTML = filtered
      .map((p, idx) => {
        const isSel = selectedSet.has(p.id);
        const proxyLabel = p.proxy ? esc(p.proxy.split(':').slice(0, 2).join(':')) : 'Local IP';
        const campInfo = getProfileCampaignInfo(p.id);
        const campTag = campInfo
          ? `<span class="text-[10px] px-1.5 py-0.5 rounded bg-violet-100 dark:bg-violet-950/70 text-violet-700 dark:text-violet-300 font-semibold shrink-0">🗂️ ${esc(campInfo.name)}</span>`
          : '';
        return `
          <div
            data-pid="${esc(p.id)}"
            data-idx="${idx}"
            class="fb-selectable-row px-3 py-2 flex items-center justify-between gap-3 hover:bg-blue-50/40 dark:hover:bg-slate-800/60 cursor-pointer select-none transition ${
              isSel ? 'row-selected' : ''
            }"
          >
            <div class="flex items-center gap-2.5 min-w-0">
              <input type="checkbox" ${isSel ? 'checked' : ''} class="w-3.5 h-3.5 accent-[#1677ff] rounded cursor-pointer shrink-0" />
              <div class="min-w-0">
                <div class="text-xs font-semibold text-slate-800 dark:text-slate-100 truncate">
                  ${idx + 1}. ${esc(p.name)} <span class="text-[10px] text-slate-400 mono">#${esc(p.id)}</span>
                </div>
                <div class="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                  Nhóm: <b>${esc(p.folder || 'Mặc định')}</b> • Proxy: <span class="mono">${proxyLabel}</span>
                </div>
              </div>
            </div>
            <div class="flex items-center gap-1.5 shrink-0">
              ${campTag}
              <span class="text-[10px] px-2 py-0.5 rounded bg-slate-200/70 dark:bg-slate-800 text-slate-600 dark:text-slate-300 uppercase mono shrink-0">${esc(p.os || 'win')}</span>
            </div>
          </div>
        `;
      })
      .join('');

    container.querySelectorAll('.fb-selectable-row').forEach((row) => {
      row.addEventListener('click', (e) => {
        if (window._fbJustFinishedMarquee) return;
        const pid = row.getAttribute('data-pid');
        const idx = parseInt(row.getAttribute('data-idx') || '0', 10);
        if (!pid) return;

        const isCheckbox = e.target.tagName === 'INPUT';
        const set = new Set(fbConfig?.dmt_profile_ids || []);
        const targetState = isCheckbox ? e.target.checked : !set.has(pid);

        if (e.shiftKey && lastClickedIdxDmt !== -1) {
          const start = Math.min(lastClickedIdxDmt, idx);
          const end = Math.max(lastClickedIdxDmt, idx);
          for (let i = start; i <= end; i++) {
            if (filtered[i]) {
              if (targetState) set.add(filtered[i].id);
              else set.delete(filtered[i].id);
            }
          }
        } else {
          if (targetState) set.add(pid);
          else set.delete(pid);
        }
        lastClickedIdxDmt = idx;
        applySelectionArray('dmt', Array.from(set));
      });
    });
  }

  function renderGpmChecklist() {
    const container = document.getElementById('fbGpmChecklistContainer');
    const summaryEl = document.getElementById('fbGpmCountSummary');
    if (!container) return;

    const allKnown = getAllKnownGpmProfiles();
    const filtered = allKnown.filter((p) => {
      if (!gpmSearchQuery) return true;
      return `${p.name || ''} ${p.id || ''}`.toLowerCase().includes(gpmSearchQuery);
    });
    const selectedSet = new Set(fbConfig?.gpm_profile_ids || []);

    if (summaryEl) {
      summaryEl.textContent = `Đã chọn: ${selectedSet.size} / ${allKnown.length} GPM Profile`;
    }

    if (filtered.length === 0) {
      container.innerHTML = `
        <div class="p-6 text-center text-xs text-slate-400">
          Chưa có Profile GPMLogin nào. Hãy bấm <b>"Đồng bộ từ GPMLogin"</b> hoặc chuyển sang chế độ sửa văn bản để dán ID!
        </div>
      `;
      return;
    }

    container.innerHTML = filtered
      .map((p, idx) => {
        const isSel = selectedSet.has(p.id);
        const campInfo = getProfileCampaignInfo(p.id);
        const campTag = campInfo
          ? `<span class="text-[10px] px-1.5 py-0.5 rounded bg-violet-100 dark:bg-violet-950/70 text-violet-700 dark:text-violet-300 font-semibold shrink-0">🗂️ ${esc(campInfo.name)}</span>`
          : '';
        return `
          <div
            data-pid="${esc(p.id)}"
            data-idx="${idx}"
            class="fb-selectable-row px-3 py-2 flex items-center justify-between gap-3 hover:bg-indigo-50/40 dark:hover:bg-slate-800/60 cursor-pointer select-none transition ${
              isSel ? 'row-selected' : ''
            }"
          >
            <div class="flex items-center gap-2.5 min-w-0">
              <input type="checkbox" ${isSel ? 'checked' : ''} class="w-3.5 h-3.5 accent-indigo-600 rounded cursor-pointer shrink-0" />
              <div class="min-w-0">
                <div class="text-xs font-semibold text-slate-800 dark:text-slate-100 truncate">
                  ${idx + 1}. ${esc(p.name)}
                </div>
                <div class="text-[10px] text-slate-400 mono truncate">ID: ${esc(p.id)}</div>
              </div>
            </div>
            <div class="flex items-center gap-1.5 shrink-0">
              ${campTag}
              <span class="text-[10px] px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-300 font-semibold">GPM</span>
              <button type="button" data-del-gpm="${esc(p.id)}" title="Xóa ID này khỏi danh sách" class="w-5 h-5 rounded hover:bg-rose-100 dark:hover:bg-rose-950/60 text-slate-400 hover:text-rose-500 flex items-center justify-center transition">
                <i class="fa-solid fa-xmark text-[10px]"></i>
              </button>
            </div>
          </div>
        `;
      })
      .join('');

    container.querySelectorAll('[data-del-gpm]').forEach((delBtn) => {
      delBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const delId = delBtn.getAttribute('data-del-gpm');
        if (!delId || !fbConfig) return;
        const nextAll = getAllKnownGpmProfiles()
          .map((p) => p.id)
          .filter((id) => id !== delId);
        const nextSel = (fbConfig.gpm_profile_ids || []).filter((id) => id !== delId);
        fbConfig.gpm_all_profile_ids = nextAll;
        fbConfig.gpm_profile_ids = nextSel;
        saveConfigQuiet({
          gpm_all_profile_ids: nextAll,
          gpm_profile_ids: nextSel,
        });
        renderGpmChecklist();
        lastRenderedDashSignature = '';
        renderMonitoredProfiles();
        updateMetricsBar();
      });
    });

    container.querySelectorAll('.fb-selectable-row').forEach((row) => {
      row.addEventListener('click', (e) => {
        if (window._fbJustFinishedMarquee) return;
        if (e.target.closest('[data-del-gpm]')) return;
        const pid = row.getAttribute('data-pid');
        const idx = parseInt(row.getAttribute('data-idx') || '0', 10);
        if (!pid) return;

        const isCheckbox = e.target.tagName === 'INPUT';
        const set = new Set(fbConfig?.gpm_profile_ids || []);
        const targetState = isCheckbox ? e.target.checked : !set.has(pid);

        if (e.shiftKey && lastClickedIdxGpm !== -1) {
          const start = Math.min(lastClickedIdxGpm, idx);
          const end = Math.max(lastClickedIdxGpm, idx);
          for (let i = start; i <= end; i++) {
            if (filtered[i]) {
              if (targetState) set.add(filtered[i].id);
              else set.delete(filtered[i].id);
            }
          }
        } else {
          if (targetState) set.add(pid);
          else set.delete(pid);
        }
        lastClickedIdxGpm = idx;
        applySelectionArray('gpm', Array.from(set), true);
      });
    });
  }

  function updateMetricsBar() {
    const activeIds = getActiveProfileIds();
    const targetCount = (fbConfig?.target_users || []).length;
    const total = runtimeState.is_running ? runtimeState.total_count || activeIds.length : activeIds.length;
    const done = runtimeState.completed_count || 0;
    const running = runtimeState.running_count || 0;
    const cycle = runtimeState.cycle || 1;
    const campaigns = getCampaignsList();
    const activeCampCount = campaigns.filter((c) => c.enabled !== false).length;

    const elCamp = document.getElementById('fbMetricCampaigns');
    const elProf = document.getElementById('fbMetricProfiles');
    const elUsers = document.getElementById('fbMetricUsers');
    const elRun = document.getElementById('fbMetricRunning');
    const elDone = document.getElementById('fbMetricDone');
    const elCycle = document.getElementById('fbMetricCycle');
    const elStatus = document.getElementById('fbMetricStatusText');
    const elCountdown = document.getElementById('fbCountdownLabel');
    const elSkipBtn = document.getElementById('fbBtnSkipWait');
    const elBar = document.getElementById('fbProgressBar');
    const elStartBtn = document.getElementById('fbBtnStartStop');
    const elStartDesc = document.getElementById('fbStartCardDesc');

    if (elCamp) elCamp.textContent = `Chiến dịch: ${activeCampCount}/${campaigns.length}`;
    if (elProf) elProf.textContent = `Đã chọn: ${activeIds.length}`;
    if (elUsers) elUsers.textContent = `Tên mục tiêu: ${targetCount}`;
    if (elRun) elRun.textContent = `Đang chạy: ${running}`;
    if (elDone) elDone.textContent = `Hoàn tất: ${done}/${total}`;
    if (elCycle) elCycle.textContent = `Lượt #${cycle}`;
    if (elStatus) elStatus.textContent = runtimeState.status_text || 'Trạng thái: Sẵn sàng';
    if (elCountdown) {
      elCountdown.textContent = (runtimeState.countdown_text || 'Đếm ngược: Chưa kích hoạt').replace(/^⏱️\s*/, '');
    }
    if (elSkipBtn) elSkipBtn.disabled = !runtimeState.can_skip_wait;

    if (elBar) {
      const pct = total > 0 ? Math.min(100, Math.round((done / total) * 100)) : 0;
      elBar.style.width = `${runtimeState.is_running ? pct : 0}%`;
    }

    if (runtimeState.is_running) {
      if (elStartBtn) {
        elStartBtn.className =
          'px-5 py-2.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-sm flex items-center gap-2 transition cursor-pointer';
        elStartBtn.innerHTML = `<i class="fa-solid fa-stop"></i><span>DỪNG TIẾN TRÌNH</span>`;
      }
      if (elStartDesc) {
        elStartDesc.textContent = `Đang chạy đa luồng (${(runtimeState.current_engine || 'dmt').toUpperCase()})...`;
      }
    } else {
      if (elStartBtn) {
        elStartBtn.className =
          'px-5 py-2.5 rounded-lg bg-[#1677ff] hover:bg-[#0958d9] text-white font-bold text-xs shadow-sm flex items-center gap-2 transition cursor-pointer';
        elStartBtn.innerHTML = `<i class="fa-solid fa-play"></i><span>BẮT ĐẦU CHẠY (${activeIds.length} PROFILE)</span>`;
      }
      renderEngineUI();
    }
  }

  function populateFormFromConfig() {
    if (!fbConfig) return;

    const dashTwoWay = document.getElementById('fbDashTwoWayToggle');
    if (dashTwoWay) dashTwoWay.checked = !!fbConfig.enable_nick_page_two_way;

    const dashRepeat = document.getElementById('fbDashRepeatToggle');
    if (dashRepeat) dashRepeat.checked = !!fbConfig.enable_auto_repeat;

    const dashDelay = document.getElementById('fbDashRepeatDelayInput');
    if (dashDelay) dashDelay.value = fbConfig.repeat_delay_minutes || 30;

    const cDir = fbConfig.content_output_dir || '';
    const shortPathEl = document.getElementById('fbShortContentPath');
    if (shortPathEl) {
      const parts = cDir.split(/[\\/]/).filter(Boolean);
      shortPathEl.textContent = parts.length > 2 ? `.../${parts.slice(-2).join('/')}` : cDir || 'Chưa chọn...';
      shortPathEl.title = cDir;
    }
    const dirInput = document.getElementById('fbContentDirInput');
    if (dirInput) dirInput.value = cDir;

    const countBadge = document.getElementById('fbContentCountBadge');
    if (countBadge && contentInfo) {
      countBadge.textContent = `${contentInfo.txt_count || 0} bài · ${contentInfo.img_count || 0} ảnh`;
    }

    const gpmTa = document.getElementById('fbGpmProfilesTextarea');
    if (gpmTa && document.activeElement !== gpmTa) {
      const allGpm = fbConfig.gpm_all_profile_ids?.length
        ? fbConfig.gpm_all_profile_ids
        : fbConfig.gpm_profile_ids || [];
      gpmTa.value = allGpm.join('\n');
    }

    const userTa = document.getElementById('fbTargetUsersTextarea');
    if (userTa && document.activeElement !== userTa) {
      userTa.value = (fbConfig.target_users || []).join('\n');
      const uBadge = document.getElementById('fbTargetUsersCountBadge');
      if (uBadge) uBadge.textContent = `${(fbConfig.target_users || []).length} Tên`;
    }

    const setChk = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.checked = !!val;
    };
    setChk('fbChkTwoWayNickPage', !!fbConfig.enable_nick_page_two_way);
    setChk('fbChkStep1', fbConfig.enable_step1 !== false);
    setChk('fbChkStep2', fbConfig.enable_step2 !== false);
    setChk('fbChkStep3', fbConfig.enable_step3 !== false);
    setChk('fbChkWindowLayout', fbConfig.enable_window_layout !== false);
    setChk('fbChkAutoFitScreen', fbConfig.auto_fit_screen !== false);
    setChk('fbChkSkipProxy', fbConfig.skip_proxy_check !== false);

    const winW = document.getElementById('fbInputWinWidth');
    if (winW && document.activeElement !== winW) {
      winW.value = fbConfig.window_width || 1100;
    }
    const winH = document.getElementById('fbInputWinHeight');
    if (winH && document.activeElement !== winH) {
      winH.value = fbConfig.window_height || 900;
    }
    const winS = document.getElementById('fbInputWinScale');
    if (winS && document.activeElement !== winS) {
      const rawScale = fbConfig.window_scale != null ? fbConfig.window_scale : 0.60;
      winS.value = rawScale > 5 ? Math.round(rawScale) : Math.round(rawScale * 100);
    }

    const setSlider = (sliderId, valId, val, suffix = '') => {
      const s = document.getElementById(sliderId);
      const v = document.getElementById(valId);
      if (s) s.value = val;
      if (v) v.textContent = `${val}${suffix}`;
    };
    setSlider('fbSliderThreads', 'fbValThreads', fbConfig.max_threads || 5);
    setSlider('fbSliderShareGroups', 'fbValShareGroups', fbConfig.max_groups_to_post || 5);
    setSlider('fbSliderReels', 'fbValReels', fbConfig.reels_to_watch || 6);
    setSlider('fbSliderFeed', 'fbValFeed', fbConfig.feed_scroll_count || 10);
    setSlider('fbSliderVisit', 'fbValVisit', fbConfig.max_groups_to_visit || 2);
    setSlider('fbSliderRepeatDelay', 'fbValRepeatDelay', fbConfig.repeat_delay_minutes || 30, ' phút');

    const cmtArea = document.getElementById('fbCommentTextsTextarea');
    if (cmtArea && document.activeElement !== cmtArea) {
      const texts = Array.isArray(fbConfig.user_post_comment_texts) ? fbConfig.user_post_comment_texts : [];
      cmtArea.value = texts.join('\n');
      const countBadge = document.getElementById('fbCommentCountBadge');
      if (countBadge) countBadge.textContent = `${texts.length} câu`;
    }
    const reactSel = document.getElementById('fbSelectReactRate');
    if (reactSel && fbConfig.user_post_react_rate != null) {
      reactSel.value = Number(fbConfig.user_post_react_rate).toFixed(2);
    }
    const cmtSel = document.getElementById('fbSelectCommentRate');
    if (cmtSel && fbConfig.user_post_comment_rate != null) {
      cmtSel.value = Number(fbConfig.user_post_comment_rate).toFixed(2);
    }

    const gpmApiIn = document.getElementById('fbGpmApiBaseInput');
    if (gpmApiIn && document.activeElement !== gpmApiIn) {
      gpmApiIn.value = fbConfig.gpm_api_base || 'http://127.0.0.1:9495/api/v1';
    }

    renderCampaignsSection();
  }

  // ==================== 6. GỌI API BACKEND & FORMAT LOG PHÂN MÀU ====================
  function formatLogLineHTML(line) {
    const safe = esc(line);
    if (line.includes('❤️') || line.includes('THẢ TIM')) {
      return `<div class="text-rose-400 font-semibold">${safe}</div>`;
    }
    if (line.includes('[Nick ⇄ Page]')) {
      return `<div class="text-pink-400 font-semibold">${safe}</div>`;
    }
    if (line.includes('[Chiến dịch:') || line.includes('🗂️')) {
      return `<div class="text-violet-400 font-semibold">${safe}</div>`;
    }
    if (line.includes('🎯') || line.includes('KHỚP TÊN')) {
      return `<div class="text-amber-300 font-semibold">${safe}</div>`;
    }
    if (line.includes('🎉') || line.includes('✅') || line.includes('HOÀN TẤT')) {
      return `<div class="text-emerald-400 font-semibold">${safe}</div>`;
    }
    if (line.includes('❌') || line.includes('Lỗi')) {
      return `<div class="text-red-400">${safe}</div>`;
    }
    if (line.includes('🔎')) {
      return `<div class="text-sky-300">${safe}</div>`;
    }
    return `<div class="text-slate-300">${safe}</div>`;
  }

  async function fetchState(resetForms = false) {
    try {
      const res = await fetch(`${API_BASE}/state?log_offset=${logOffset}`);
      if (!res.ok) return;
      const data = await res.json();

      fbConfig = data.config || fbConfig;
      dmtProfiles = data.dmt_profiles || [];
      contentInfo = data.content_info || contentInfo;
      campaignsInfo = data.campaigns_info || campaignsInfo;
      runtimeState = data.runtime || runtimeState;

      const sideBadge = document.getElementById('fbSidebarStatusBadge');
      if (sideBadge) {
        if (runtimeState.is_running) {
          sideBadge.textContent = `RUN (${runtimeState.running_count || 0})`;
          sideBadge.className = 'text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 mono font-bold';
        } else {
          sideBadge.textContent = 'IDLE';
          sideBadge.className = 'text-[10px] px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300 mono';
        }
      }

      const newLogs = runtimeState.new_logs || [];
      if (newLogs.length > 0) {
        allLogs.push(...newLogs);
        if (allLogs.length > 2000) {
          allLogs = allLogs.slice(-2000);
        }
        logOffset = runtimeState.next_log_offset || allLogs.length;

        const miniBox = document.getElementById('fbMiniLogBox');
        const fullBox = document.getElementById('fbFullLogBox');
        const htmlContent = allLogs.slice(-300).map(formatLogLineHTML).join('');
        if (miniBox) {
          miniBox.innerHTML = htmlContent;
          miniBox.scrollTop = miniBox.scrollHeight;
        }
        if (fullBox) {
          fullBox.innerHTML = allLogs.map(formatLogLineHTML).join('');
          fullBox.scrollTop = fullBox.scrollHeight;
        }
      }

      if (resetForms) {
        populateFormFromConfig();
        switchProfileConfigTab((fbConfig?.engine || 'dmt').toLowerCase());
        renderDmtChecklist();
        renderGpmChecklist();
      } else {
        const countBadge = document.getElementById('fbContentCountBadge');
        if (countBadge && contentInfo) {
          countBadge.textContent = `${contentInfo.txt_count || 0} bài · ${contentInfo.img_count || 0} ảnh`;
        }
      }

      renderEngineUI();
      renderMonitoredProfiles();
      updateMetricsBar();
    } catch (e) {
      // Ignore background polling error
    }
  }

  async function saveConfigQuiet(partial) {
    try {
      const res = await fetch(`${API_BASE}/config`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ config: partial }),
      });
      if (res.ok) {
        const data = await res.json();
        fbConfig = data.config;
        contentInfo = data.content_info || contentInfo;
        campaignsInfo = data.campaigns_info || campaignsInfo;
        populateFormFromConfig();
        renderEngineUI();
        renderMonitoredProfiles();
        updateMetricsBar();
      }
    } catch (e) {
      console.error('Lỗi lưu config:', e);
    }
  }

  async function saveConfigWithToast(partial, msg) {
    await saveConfigQuiet(partial);
    notify(msg || 'Đã lưu cấu hình thành công!', 'success');
  }

  async function saveAllSettingsFromPage() {
    const payload = {
      enable_nick_page_two_way: !!document.getElementById('fbChkTwoWayNickPage')?.checked,
      enable_step1: !!document.getElementById('fbChkStep1')?.checked,
      enable_step2: !!document.getElementById('fbChkStep2')?.checked,
      enable_step3: !!document.getElementById('fbChkStep3')?.checked,
      enable_window_layout: !!document.getElementById('fbChkWindowLayout')?.checked,
      auto_fit_screen: !!document.getElementById('fbChkAutoFitScreen')?.checked,
      window_width: parseInt(document.getElementById('fbInputWinWidth')?.value || '1100', 10),
      window_height: parseInt(document.getElementById('fbInputWinHeight')?.value || '900', 10),
      window_scale: (function() {
        const v = parseFloat(document.getElementById('fbInputWinScale')?.value || '60');
        return v > 5 ? Math.round(v) / 100.0 : v;
      })(),
      skip_proxy_check: !!document.getElementById('fbChkSkipProxy')?.checked,
      max_threads: parseInt(document.getElementById('fbSliderThreads')?.value || '5', 10),
      max_groups_to_post: parseInt(document.getElementById('fbSliderShareGroups')?.value || '5', 10),
      reels_to_watch: parseInt(document.getElementById('fbSliderReels')?.value || '6', 10),
      feed_scroll_count: parseInt(document.getElementById('fbSliderFeed')?.value || '10', 10),
      max_groups_to_visit: parseInt(document.getElementById('fbSliderVisit')?.value || '2', 10),
      repeat_delay_minutes: parseInt(document.getElementById('fbSliderRepeatDelay')?.value || '30', 10),
      gpm_api_base: (document.getElementById('fbGpmApiBaseInput')?.value || 'http://127.0.0.1:9495/api/v1').trim(),
      user_post_react_rate: parseFloat(document.getElementById('fbSelectReactRate')?.value || '0.30'),
      user_post_comment_rate: parseFloat(document.getElementById('fbSelectCommentRate')?.value || '0.05'),
      user_post_comment_texts: parseLines(document.getElementById('fbCommentTextsTextarea')?.value),
    };
    await saveConfigWithToast(payload, 'Đã lưu toàn bộ cấu hình kịch bản!');
  }

  async function toggleStartStop() {
    if (runtimeState.is_running) {
      try {
        await fetch(`${API_BASE}/stop`, { method: 'POST' });
        notify('Đã gửi lệnh dừng tiến trình Auto!', 'info');
        fetchState(false);
      } catch (e) {
        notify('Lỗi khi dừng tiến trình', 'error');
      }
    } else {
      const activeIds = getActiveProfileIds();
      if (activeIds.length === 0) {
        notify('Vui lòng tích chọn ít nhất 1 Profile để chạy!', 'error');
        return;
      }
      try {
        const res = await fetch(`${API_BASE}/start`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ config: fbConfig }),
        });
        const data = await res.json();
        if (!res.ok || data.success === false) {
          notify(data.error || data.detail || 'Không thể khởi chạy Auto!', 'error');
          return;
        }
        notify(`Đã bắt đầu chạy Auto với ${activeIds.length} Profile!`, 'success');
        fetchState(false);
      } catch (e) {
        notify('Lỗi kết nối khi bắt đầu chạy Auto', 'error');
      }
    }
  }

  async function skipCountdown() {
    try {
      await fetch(`${API_BASE}/skip-wait`, { method: 'POST' });
      notify('Đã bỏ qua thời gian chờ, chạy ngay lượt tiếp theo!', 'info');
    } catch (e) {}
  }

  async function clearLogs() {
    try {
      await fetch(`${API_BASE}/clear-logs`, { method: 'POST' });
      allLogs = [];
      logOffset = 0;
      const miniBox = document.getElementById('fbMiniLogBox');
      const fullBox = document.getElementById('fbFullLogBox');
      if (miniBox) miniBox.innerHTML = '';
      if (fullBox) fullBox.innerHTML = '';
    } catch (e) {}
  }

  async function browseContentFolder() {
    try {
      const res = await fetch(`${API_BASE}/browse-folder`, { method: 'POST' });
      if (!res.ok) return;
      const data = await res.json();
      const chosenPath = data.path || data.selected;
      if (chosenPath) {
        fbConfig = data.config;
        contentInfo = data.content_info;
        populateFormFromConfig();
        notify(`Đã chọn thư mục: ${chosenPath}`, 'success');
      }
    } catch (e) {
      notify('Không thể mở hộp thoại chọn thư mục', 'error');
    }
  }

  async function openContentFolder() {
    try {
      await fetch(`${API_BASE}/open-folder`, { method: 'POST' });
    } catch (e) {}
  }

  async function checkGpmStatus(showToastMsg = false) {
    const badge = document.getElementById('fbGpmStatusBadge');
    try {
      const res = await fetch(`${API_BASE}/gpm-status`);
      const data = await res.json();
      if (data.online) {
        const count = data.profiles_count ?? data.count ?? (data.profiles ? data.profiles.length : 0);
        if (Array.isArray(data.profiles) && data.profiles.length > 0) {
          gpmApiProfiles = data.profiles;
          renderGpmChecklist();
          lastRenderedDashSignature = '';
          renderMonitoredProfiles();
        }
        if (badge) {
          badge.className =
            'px-2.5 py-1.5 rounded-lg text-[11px] font-semibold border border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5 transition';
          badge.innerHTML = `<span class="w-2 h-2 rounded-full bg-emerald-500"></span><span>GPM Online (${count})</span>`;
        }
        if (showToastMsg) {
          notify(`Kết nối GPMLogin thành công (${count} profiles)!`, 'success');
        }
      } else {
        if (badge) {
          badge.className =
            'px-2.5 py-1.5 rounded-lg text-[11px] font-medium border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 flex items-center gap-1.5 transition';
          badge.innerHTML = `<span class="w-2 h-2 rounded-full bg-slate-400"></span><span>GPM Offline</span>`;
        }
        if (showToastMsg) {
          notify('GPMLogin hiện chưa mở (Port 9495). Bạn vẫn có thể dùng DMT Browser!', 'info');
        }
      }
    } catch (e) {}
  }

  async function fetchGpmProfilesFromApi(showToastMsg = true) {
    try {
      const res = await fetch(`${API_BASE}/gpm-status`);
      const data = await res.json();
      if (!data.online) {
        if (showToastMsg) {
          notify('GPMLogin chưa bật! Vui lòng mở phần mềm GPMLogin trước khi đồng bộ.', 'error');
        }
        return;
      }
      gpmApiProfiles = data.profiles || [];
      const ids = gpmApiProfiles.map((p) => p.id).filter(Boolean);
      if (ids.length === 0) {
        if (showToastMsg) notify('Không tìm thấy Profile nào trong GPMLogin.', 'info');
        return;
      }
      renderGpmChecklist();
      lastRenderedDashSignature = '';
      renderMonitoredProfiles();
      if (showToastMsg) {
        notify(`Đã đồng bộ ${ids.length} Profile từ GPMLogin!`, 'success');
      }
    } catch (e) {
      if (showToastMsg) notify('Lỗi khi đồng bộ từ GPMLogin API', 'error');
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPluginUI);
  } else {
    initPluginUI();
  }
})();
