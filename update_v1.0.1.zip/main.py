import argparse
import base64
import datetime
import json
import math
import os
import pickle
import shutil
import socket
import sqlite3
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path
from typing import Optional
from urllib.parse import quote
import ctypes
from ctypes import wintypes

BASE_DIR = Path(__file__).resolve().parent
RUNTIME_DIR = BASE_DIR / "runtime"
CAMOUFOX_CACHE_DIR = RUNTIME_DIR / "camoufox_cache"
DB_PATH = BASE_DIR / "profiles.db"
PROFILES_DIR = BASE_DIR / "profiles_data"
RUNNER_PATH = BASE_DIR / "runner.py"
INDEX_HTML_PATH = BASE_DIR / "index.html"
ASSETS_DIR = BASE_DIR / "assets"
LOGO_PNG_PATH = ASSETS_DIR / "logo.png"
LOGO_ICO_PATH = ASSETS_DIR / "logo.ico"

# Khi chạy qua pythonw.exe / DMT Browser.exe (không có cửa sổ CMD), sys.stdout và sys.stderr là None.
# Cần gán vào file log để uvicorn và print() không bị văng lỗi AttributeError ('NoneType' has no attribute 'isatty').
if sys.stdout is None or sys.stderr is None:
    try:
        _app_log = open(BASE_DIR / "app.log", "a", encoding="utf-8", errors="replace")
        if sys.stdout is None:
            sys.stdout = _app_log
        if sys.stderr is None:
            sys.stderr = _app_log
    except Exception:
        devnull = open(os.devnull, "w", encoding="utf-8", errors="replace")
        if sys.stdout is None:
            sys.stdout = devnull
        if sys.stderr is None:
            sys.stderr = devnull
elif hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

CAMOUFOX_CACHE_DIR.mkdir(parents=True, exist_ok=True)
PROFILES_DIR.mkdir(parents=True, exist_ok=True)

# Ép Camoufox lưu và đọc toàn bộ nhân trình duyệt + GeoIP ngay trong thư mục dự án (runtime/camoufox_cache)
import platformdirs
platformdirs.user_cache_dir = lambda appname="camoufox", *args, **kwargs: str(CAMOUFOX_CACHE_DIR)

import re
import tempfile
import zipfile
import psutil
import requests
import uvicorn
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse
from starlette.background import BackgroundTask
from pydantic import BaseModel

from runner import extract_fingerprint_summary, parse_proxy, apply_fingerprint_overrides

app = FastAPI(title="DMT Browser API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Quản lý tiến trình trình duyệt đang mở: { profile_id: subprocess.Popen }
RUNNING_PROCESSES: dict[str, subprocess.Popen] = {}
PROCESS_LOCK = threading.Lock()


def get_db_connection():
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS profiles (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            folder TEXT DEFAULT 'Mặc định',
            os TEXT DEFAULT 'windows',
            proxy TEXT DEFAULT '',
            proxy_info TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            start_url TEXT DEFAULT '',
            fingerprint_summary TEXT DEFAULT '{}',
            webrtc_mode TEXT DEFAULT 'proxy_only',
            created_at TEXT,
            last_opened_at TEXT
        )
        """
    )
    # Tự động migrate thêm cột webrtc_mode nếu db cũ chưa có
    try:
        cur.execute("ALTER TABLE profiles ADD COLUMN webrtc_mode TEXT DEFAULT 'proxy_only'")
    except Exception:
        pass

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS folders (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL UNIQUE,
            color TEXT DEFAULT '#1677ff',
            created_at TEXT
        )
        """
    )
    # Đồng bộ các folder hiện có trong bảng profiles vào bảng folders nếu chưa có
    cur.execute("SELECT DISTINCT folder FROM profiles WHERE folder IS NOT NULL AND TRIM(folder) != ''")
    existing_folders = [r[0].strip() for r in cur.fetchall()]
    if not existing_folders:
        existing_folders = ["Mặc định"]
    elif "Mặc định" not in existing_folders:
        existing_folders.insert(0, "Mặc định")

    now_iso = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for f_name in existing_folders:
        cur.execute("SELECT id FROM folders WHERE name = ?", (f_name,))
        if not cur.fetchone():
            f_id = f"f_{uuid.uuid4().hex[:8]}"
            cur.execute(
                "INSERT INTO folders (id, name, color, created_at) VALUES (?, ?, ?, ?)",
                (f_id, f_name, "#1677ff", now_iso),
            )

    # Xóa proxy_info lưu cứng để kết quả check proxy chỉ hiển thị tạm thời 1 lần trên giao diện
    cur.execute("UPDATE profiles SET proxy_info = '' WHERE proxy_info != ''")
    conn.commit()
    conn.close()


init_db()


def generate_browserforge_fp(
    os_type: str = "windows",
    custom_gpu: Optional[str] = None,
    custom_cpu: Optional[int] = None,
    custom_ram: Optional[int] = None,
    custom_screen: Optional[str] = None,
):
    from camoufox.fingerprints import generate_fingerprint

    os_clean = "macos" if str(os_type).lower() in ("macos", "mac", "darwin") else "windows"
    fp = generate_fingerprint(os=os_clean)
    fp = apply_fingerprint_overrides(
        fp,
        custom_gpu=custom_gpu,
        custom_cpu=custom_cpu,
        custom_ram=custom_ram,
        custom_screen=custom_screen,
    )
    summary = extract_fingerprint_summary(fp, os_clean)
    raw_bytes = pickle.dumps(fp)
    seed_token = base64.b64encode(raw_bytes).decode("ascii")
    return fp, summary, seed_token


def save_profile_fingerprint(
    profile_id: str,
    os_type: str,
    seed_token: Optional[str] = None,
    custom_gpu: Optional[str] = None,
    custom_cpu: Optional[int] = None,
    custom_ram: Optional[int] = None,
    custom_screen: Optional[str] = None,
):
    profile_dir = PROFILES_DIR / str(profile_id)
    profile_dir.mkdir(parents=True, exist_ok=True)
    pkl_path = profile_dir / "fingerprint.pkl"
    json_path = profile_dir / "fingerprint.json"

    os_clean = "macos" if str(os_type).lower() in ("macos", "mac", "darwin") else "windows"

    fp = None
    if seed_token:
        try:
            raw_bytes = base64.b64decode(seed_token.encode("ascii"))
            loaded = pickle.loads(raw_bytes)
            if isinstance(loaded, dict) and "navigator" in loaded:
                fp = loaded
        except Exception:
            fp = None

    if fp is None:
        fp, summary, _ = generate_browserforge_fp(
            os_type=os_clean,
            custom_gpu=custom_gpu,
            custom_cpu=custom_cpu,
            custom_ram=custom_ram,
            custom_screen=custom_screen,
        )
    else:
        fp = apply_fingerprint_overrides(
            fp,
            custom_gpu=custom_gpu,
            custom_cpu=custom_cpu,
            custom_ram=custom_ram,
            custom_screen=custom_screen,
        )
        summary = extract_fingerprint_summary(fp, os_clean)

    with open(pkl_path, "wb") as f:
        pickle.dump(fp, f)

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    return summary


PROCESS_START_TIMES: dict[str, float] = {}


def is_profile_running(profile_id: str) -> bool:
    pid_to_cleanup = None
    with PROCESS_LOCK:
        proc = RUNNING_PROCESSES.get(profile_id)
        if not proc:
            return False
        if proc.poll() is not None or not psutil.pid_exists(proc.pid):
            RUNNING_PROCESSES.pop(profile_id, None)
            PROCESS_START_TIMES.pop(profile_id, None)
            return False

        # Sau 9 giây khởi động, kiểm tra xem tiến trình camoufox.exe thực sự còn mở không
        started_at = PROCESS_START_TIMES.get(profile_id, 0)
        if started_at and (time.time() - started_at > 9.0):
            try:
                parent = psutil.Process(proc.pid)
                children = parent.children(recursive=True)
                has_camoufox = any(
                    "camoufox" in c.name().lower() and c.status() != psutil.STATUS_ZOMBIE
                    for c in children
                )
                if not has_camoufox:
                    RUNNING_PROCESSES.pop(profile_id, None)
                    PROCESS_START_TIMES.pop(profile_id, None)
                    pid_to_cleanup = proc.pid
            except psutil.NoSuchProcess:
                RUNNING_PROCESSES.pop(profile_id, None)
                PROCESS_START_TIMES.pop(profile_id, None)
                return False
            except Exception:
                pass

    if pid_to_cleanup:
        threading.Thread(target=kill_process_tree, args=(pid_to_cleanup,), daemon=True).start()
        return False

    return True


def kill_process_tree(pid: int):
    if os.name == "nt":
        try:
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(pid)],
                capture_output=True,
                creationflags=subprocess.CREATE_NO_WINDOW,
                timeout=4,
            )
        except Exception:
            pass
    try:
        parent = psutil.Process(pid)
        children = parent.children(recursive=True)
        for child in children:
            try:
                child.kill()
            except Exception:
                pass
        parent.kill()
    except psutil.NoSuchProcess:
        pass
    except Exception:
        pass



# ==================== PYDANTIC MODELS ====================

class FingerprintPreviewRequest(BaseModel):
    os: str = "windows"
    custom_gpu: Optional[str] = None
    custom_cpu: Optional[int] = None
    custom_ram: Optional[int] = None
    custom_screen: Optional[str] = None


class ProxyCheckRequest(BaseModel):
    proxy: str = ""


class ProfileCreateRequest(BaseModel):
    name: str
    folder: str = "Mặc định"
    os: str = "windows"
    proxy: str = ""
    proxy_info: str = ""
    notes: str = ""
    start_url: str = ""
    seed_token: Optional[str] = None
    custom_gpu: Optional[str] = None
    custom_cpu: Optional[int] = None
    custom_ram: Optional[int] = None
    custom_screen: Optional[str] = None
    webrtc_mode: Optional[str] = "proxy_only"


class ProfileUpdateRequest(BaseModel):
    name: str
    folder: str = "Mặc định"
    os: str = "windows"
    proxy: str = ""
    proxy_info: str = ""
    notes: str = ""
    start_url: str = ""
    seed_token: Optional[str] = None
    custom_gpu: Optional[str] = None
    custom_cpu: Optional[int] = None
    custom_ram: Optional[int] = None
    custom_screen: Optional[str] = None
    webrtc_mode: Optional[str] = "proxy_only"


class BulkProxyItem(BaseModel):
    id: str
    proxy: str = ""
    proxy_info: str = ""


class BulkProxyUpdateRequest(BaseModel):
    updates: list[BulkProxyItem]


class BulkProxyCheckRequest(BaseModel):
    proxies: list[str]


class BulkCreateProfileRequest(BaseModel):
    count: int = 5
    prefix: str = "Profile_"
    start_index: int = 1
    folder: str = "Mặc định"
    os: str = "windows"
    proxies: list[str] = []
    notes: str = ""
    start_url: str = ""


class BulkIdsRequest(BaseModel):
    ids: list[str]
    folder: Optional[str] = None


class FolderCreateRequest(BaseModel):
    name: str
    color: Optional[str] = "#1677ff"


class FolderRenameRequest(BaseModel):
    old_name: str
    new_name: str


class FolderDeleteRequest(BaseModel):
    name: str
    move_to: Optional[str] = "Mặc định"
    reassign_to: Optional[str] = None


# ==================== ROUTES ====================

@app.get("/", response_class=HTMLResponse)
def serve_index():
    if not INDEX_HTML_PATH.exists():
        return HTMLResponse("<h1>Không tìm thấy file index.html</h1>", status_code=404)
    return FileResponse(
        str(INDEX_HTML_PATH),
        headers={"Cache-Control": "no-store, no-cache, must-revalidate, max-age=0"},
    )


@app.get("/assets/logo.png")
def serve_logo_png():
    if LOGO_PNG_PATH.exists():
        return FileResponse(str(LOGO_PNG_PATH), media_type="image/png")
    raise HTTPException(status_code=404, detail="Không tìm thấy logo.png")


@app.get("/assets/profile_logo.png")
def serve_profile_logo_png():
    p_path = ASSETS_DIR / "profile_logo.png"
    if p_path.exists():
        return FileResponse(str(p_path), media_type="image/png")
    if LOGO_PNG_PATH.exists():
        return FileResponse(str(LOGO_PNG_PATH), media_type="image/png")
    raise HTTPException(status_code=404, detail="Không tìm thấy profile_logo.png")


@app.get("/favicon.ico")
def serve_favicon_ico():
    if LOGO_ICO_PATH.exists():
        return FileResponse(str(LOGO_ICO_PATH), media_type="image/x-icon")
    if LOGO_PNG_PATH.exists():
        return FileResponse(str(LOGO_PNG_PATH), media_type="image/png")
    raise HTTPException(status_code=404, detail="Không tìm thấy favicon.ico")


@app.post("/api/fingerprint/preview")
def api_preview_fingerprint(req: FingerprintPreviewRequest):
    _, summary, seed_token = generate_browserforge_fp(
        os_type=req.os,
        custom_gpu=req.custom_gpu,
        custom_cpu=req.custom_cpu,
        custom_ram=req.custom_ram,
        custom_screen=req.custom_screen,
    )
    return {
        "success": True,
        "summary": summary,
        "seed_token": seed_token,
    }


def build_requests_proxies(proxy_str: str, default_scheme: str = "http"):
    parsed = parse_proxy(proxy_str)
    if not parsed:
        return None
    server = parsed["server"]
    if "://" in server:
        scheme, host_port = server.split("://", 1)
    else:
        scheme, host_port = default_scheme, server

    if "://" not in proxy_str.strip():
        scheme = default_scheme

    if scheme == "socks5":
        scheme = "socks5h"

    username = parsed.get("username")
    password = parsed.get("password")
    if username and password:
        auth = f"{quote(str(username), safe='')}:{quote(str(password), safe='')}@"
    elif username:
        auth = f"{quote(str(username), safe='')}@"
    else:
        auth = ""

    proxy_url = f"{scheme}://{auth}{host_port}"
    return {"http": proxy_url, "https": proxy_url}


@app.post("/api/proxy/check")
def api_check_proxy(req: ProxyCheckRequest):
    raw_proxy = (req.proxy or "").strip()
    start_ts = time.time()

    schemes_to_try = ["local"] if not raw_proxy or raw_proxy.lower() in ("none", "local", "direct") else (
        [raw_proxy.split("://")[0].lower()] if "://" in raw_proxy else ["http", "socks5"]
    )

    last_error = None
    for scheme in schemes_to_try:
        proxies = None if scheme == "local" else build_requests_proxies(raw_proxy, default_scheme=scheme)
        try:
            resp = requests.get(
                "http://ip-api.com/json/?fields=status,message,country,countryCode,regionName,city,timezone,isp,query",
                proxies=proxies,
                timeout=10,
            )
            if resp.status_code == 200:
                data = resp.json()
                if data.get("status") == "success":
                    latency = int((time.time() - start_ts) * 1000)
                    return {
                        "live": True,
                        "ip": data.get("query", ""),
                        "country": data.get("country", "Unknown"),
                        "countryCode": data.get("countryCode", ""),
                        "city": data.get("city") or data.get("regionName") or "",
                        "timezone": data.get("timezone", "UTC"),
                        "isp": data.get("isp", ""),
                        "protocol": "LOCAL" if scheme == "local" else scheme.upper(),
                        "latency_ms": latency,
                    }
                else:
                    last_error = data.get("message", "Proxy trả về trạng thái thất bại")
        except Exception as e:
            last_error = str(e)

        try:
            resp2 = requests.get("https://ipwho.is/", proxies=proxies, timeout=10)
            if resp2.status_code == 200:
                d2 = resp2.json()
                if d2.get("success", True) and d2.get("ip"):
                    latency = int((time.time() - start_ts) * 1000)
                    tz = d2.get("timezone", {})
                    tz_id = tz.get("id", "UTC") if isinstance(tz, dict) else str(tz or "UTC")
                    conn_info = d2.get("connection", {})
                    isp = conn_info.get("isp", "") if isinstance(conn_info, dict) else ""
                    return {
                        "live": True,
                        "ip": d2.get("ip", ""),
                        "country": d2.get("country", "Unknown"),
                        "countryCode": d2.get("country_code", ""),
                        "city": d2.get("city", ""),
                        "timezone": tz_id,
                        "isp": isp,
                        "protocol": "LOCAL" if scheme == "local" else scheme.upper(),
                        "latency_ms": latency,
                    }
        except Exception as e:
            last_error = str(e)

    return {
        "live": False,
        "error": last_error or "Không thể kết nối tới Proxy",
    }


@app.get("/api/profiles")
def api_list_profiles():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM profiles ORDER BY created_at DESC")
    rows = cur.fetchall()
    conn.close()

    result = []
    for row in rows:
        item = dict(row)
        pid = item["id"]
        try:
            item["fingerprint"] = json.loads(item.get("fingerprint_summary") or "{}")
        except Exception:
            item["fingerprint"] = {}
        item["proxy_meta"] = None
        item["status"] = "running" if is_profile_running(pid) else "stopped"
        result.append(item)

    return {"profiles": result}


@app.post("/api/profiles")
def api_create_profile(req: ProfileCreateRequest):
    profile_id = str(uuid.uuid4())[:8]
    os_clean = "macos" if str(req.os).lower() in ("macos", "mac", "darwin") else "windows"
    now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    webrtc_mode_val = (req.webrtc_mode or "proxy_only").strip().lower()

    summary = save_profile_fingerprint(
        profile_id,
        os_clean,
        seed_token=req.seed_token,
        custom_gpu=req.custom_gpu,
        custom_cpu=req.custom_cpu,
        custom_ram=req.custom_ram,
        custom_screen=req.custom_screen,
    )

    conn = get_db_connection()
    cur = conn.cursor()
    folder_val = (req.folder or "Mặc định").strip()
    cur.execute("SELECT id FROM folders WHERE name = ?", (folder_val,))
    if not cur.fetchone():
        f_id = f"f_{uuid.uuid4().hex[:8]}"
        cur.execute(
            "INSERT INTO folders (id, name, color, created_at) VALUES (?, ?, ?, ?)",
            (f_id, folder_val, "#1677ff", now_str),
        )

    cur.execute(
        """
        INSERT INTO profiles (id, name, folder, os, proxy, proxy_info, notes, start_url, fingerprint_summary, webrtc_mode, created_at, last_opened_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            profile_id,
            req.name.strip() or f"Profile {profile_id}",
            folder_val,
            os_clean,
            (req.proxy or "").strip(),
            "",
            (req.notes or "").strip(),
            (req.start_url or "").strip(),
            json.dumps(summary, ensure_ascii=False),
            webrtc_mode_val,
            now_str,
            "",
        ),
    )
    conn.commit()
    conn.close()

    return {"success": True, "id": profile_id, "fingerprint": summary}


@app.put("/api/profiles/{profile_id}")
def api_update_profile(profile_id: str, req: ProfileUpdateRequest):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM profiles WHERE id = ?", (profile_id,))
    existing = cur.fetchone()
    if not existing:
        conn.close()
        raise HTTPException(status_code=404, detail="Không tìm thấy Profile")

    existing_dict = dict(existing)
    os_clean = "macos" if str(req.os).lower() in ("macos", "mac", "darwin") else "windows"
    webrtc_mode_val = (req.webrtc_mode or existing_dict.get("webrtc_mode") or "proxy_only").strip().lower()
    has_custom_fp = any([req.custom_gpu, req.custom_cpu, req.custom_ram, req.custom_screen])

    if req.seed_token or has_custom_fp or os_clean != existing_dict.get("os"):
        summary = save_profile_fingerprint(
            profile_id,
            os_clean,
            seed_token=req.seed_token,
            custom_gpu=req.custom_gpu,
            custom_cpu=req.custom_cpu,
            custom_ram=req.custom_ram,
            custom_screen=req.custom_screen,
        )
        fp_summary_str = json.dumps(summary, ensure_ascii=False)
    else:
        fp_summary_str = existing_dict.get("fingerprint_summary") or "{}"

    cur.execute(
        """
        UPDATE profiles
        SET name = ?, folder = ?, os = ?, proxy = ?, proxy_info = ?, notes = ?, start_url = ?, fingerprint_summary = ?, webrtc_mode = ?
        WHERE id = ?
        """,
        (
            req.name.strip() or existing_dict["name"],
            (req.folder or "Mặc định").strip(),
            os_clean,
            (req.proxy or "").strip(),
            "",
            (req.notes or "").strip(),
            (req.start_url or "").strip(),
            fp_summary_str,
            webrtc_mode_val,
            profile_id,
        ),
    )
    conn.commit()
    conn.close()

    return {"success": True, "id": profile_id}


@app.delete("/api/profiles/{profile_id}")
def api_delete_profile(profile_id: str):
    if is_profile_running(profile_id):
        api_stop_profile(profile_id)

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM profiles WHERE id = ?", (profile_id,))
    conn.commit()
    conn.close()

    profile_dir = PROFILES_DIR / str(profile_id)
    if profile_dir.exists():
        def _force_remove(func, path, exc_info):
            try:
                os.chmod(path, 0o777)
                func(path)
            except Exception:
                pass

        for _ in range(3):
            try:
                if sys.version_info >= (3, 12):
                    shutil.rmtree(profile_dir, onexc=lambda fn, p, e: _force_remove(fn, p, e))
                else:
                    shutil.rmtree(profile_dir, onerror=_force_remove)
                break
            except Exception:
                time.sleep(0.15)

        if profile_dir.exists():
            shutil.rmtree(profile_dir, ignore_errors=True)

    return {"success": True}


@app.post("/api/profiles/{profile_id}/start")
def api_start_profile(profile_id: str):
    if is_profile_running(profile_id):
        return {"success": True, "status": "running", "message": "Profile đang mở"}

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM profiles WHERE id = ?", (profile_id,))
    row = cur.fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="Không tìm thấy Profile")

    row_dict = dict(row)
    conn.close()

    # Kiểm tra kết nối Proxy trước khi mở Profile
    raw_proxy = (row_dict.get("proxy") or "").strip()
    public_ip = ""
    proxy_country = ""
    proxy_tz = ""

    if raw_proxy and raw_proxy.lower() not in ("none", "local", "direct", "no"):
        check_res = api_check_proxy(ProxyCheckRequest(proxy=raw_proxy))
        if not check_res.get("live"):
            return {
                "success": False,
                "status": "stopped",
                "error": "Không thể kết nối proxy",
            }
        public_ip = str(check_res.get("ip") or "")
        cc = str(check_res.get("countryCode") or "")
        cn = str(check_res.get("country") or "")
        proxy_country = f"{cc} ({cn})" if cc and cn else (cn or cc)
        proxy_tz = str(check_res.get("timezone") or "")

    now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("UPDATE profiles SET last_opened_at = ? WHERE id = ?", (now_str, profile_id))
    conn.commit()
    conn.close()

    profile_dir = PROFILES_DIR / str(profile_id)
    profile_dir.mkdir(parents=True, exist_ok=True)
    pkl_path = profile_dir / "fingerprint.pkl"
    if not pkl_path.exists():
        save_profile_fingerprint(profile_id, row_dict.get("os") or "windows", None)

    py_exec = Path(sys.executable)
    pyw_exec = py_exec.with_name("pythonw.exe")
    runner_python = str(pyw_exec if pyw_exec.exists() else py_exec)

    cmd = [
        runner_python,
        "-u",
        str(RUNNER_PATH),
        "--profile-id",
        str(profile_id),
        "--public-ip",
        public_ip,
        "--proxy-country",
        proxy_country,
        "--proxy-tz",
        proxy_tz,
    ]

    child_env = os.environ.copy()
    child_env["PYTHONIOENCODING"] = "utf-8"
    child_env["PYTHONUTF8"] = "1"
    child_env["PYTHONUNBUFFERED"] = "1"

    log_path = profile_dir / "runner.log"
    log_file = open(log_path, "a", encoding="utf-8", errors="replace")

    proc = subprocess.Popen(
        cmd,
        cwd=str(BASE_DIR),
        env=child_env,
        stdin=subprocess.DEVNULL,
        stdout=log_file,
        stderr=log_file,
    )

    with PROCESS_LOCK:
        RUNNING_PROCESSES[profile_id] = proc
        PROCESS_START_TIMES[profile_id] = time.time()

    return {"success": True, "status": "running", "pid": proc.pid}


@app.post("/api/profiles/{profile_id}/stop")
def api_stop_profile(profile_id: str):
    with PROCESS_LOCK:
        proc = RUNNING_PROCESSES.pop(profile_id, None)
        PROCESS_START_TIMES.pop(profile_id, None)

    if proc:
        kill_process_tree(proc.pid)

    return {"success": True, "status": "stopped"}


class ProfileNotesUpdateRequest(BaseModel):
    notes: str = ""


@app.patch("/api/profiles/{profile_id}/notes")
def api_update_profile_notes(profile_id: str, req: ProfileNotesUpdateRequest):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(
        "UPDATE profiles SET notes = ? WHERE id = ?",
        ((req.notes or "").strip(), profile_id),
    )
    conn.commit()
    conn.close()
    return {"success": True, "id": profile_id, "notes": (req.notes or "").strip()}



@app.post("/api/profiles/bulk-proxy")
def api_bulk_update_proxy(req: BulkProxyUpdateRequest):
    if not req.updates:
        return {"success": True, "updated": 0}

    conn = get_db_connection()
    cur = conn.cursor()
    updated_count = 0
    for item in req.updates:
        cur.execute(
            "UPDATE profiles SET proxy = ?, proxy_info = '' WHERE id = ?",
            ((item.proxy or "").strip(), item.id),
        )
        updated_count += cur.rowcount
    conn.commit()
    conn.close()
    return {"success": True, "updated": updated_count}


@app.post("/api/proxy/bulk-check")
def api_bulk_check_proxy(req: BulkProxyCheckRequest):
    from concurrent.futures import ThreadPoolExecutor

    unique_proxies = list(dict.fromkeys([p.strip() for p in req.proxies]))

    def _check_one(p_str: str):
        res = api_check_proxy(ProxyCheckRequest(proxy=p_str))
        return p_str, res

    results = {}
    with ThreadPoolExecutor(max_workers=min(12, max(1, len(unique_proxies)))) as pool:
        for p_str, res in pool.map(_check_one, unique_proxies):
            results[p_str] = res

    return {"success": True, "results": results}


@app.post("/api/profiles/bulk-create")
def api_bulk_create_profiles(req: BulkCreateProfileRequest):
    count = max(1, min(100, req.count))
    os_clean = "macos" if str(req.os).lower() in ("macos", "mac", "darwin") else "windows"
    folder_clean = (req.folder or "Mặc định").strip()
    now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    proxies = [p.strip() for p in (req.proxies or []) if p.strip()]

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT id FROM folders WHERE name = ?", (folder_clean,))
    if not cur.fetchone():
        f_id = f"f_{uuid.uuid4().hex[:8]}"
        cur.execute(
            "INSERT INTO folders (id, name, color, created_at) VALUES (?, ?, ?, ?)",
            (f_id, folder_clean, "#1677ff", now_str),
        )
    created_ids = []

    for i in range(count):
        profile_id = str(uuid.uuid4())[:8]
        idx = req.start_index + i
        name = f"{req.prefix}{idx:03d}"
        proxy_val = proxies[i % len(proxies)] if proxies else ""
        summary = save_profile_fingerprint(profile_id, os_clean, None)

        cur.execute(
            """
            INSERT INTO profiles (id, name, folder, os, proxy, proxy_info, notes, start_url, fingerprint_summary, webrtc_mode, created_at, last_opened_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                profile_id,
                name,
                folder_clean,
                os_clean,
                proxy_val,
                "",
                (req.notes or "").strip(),
                (req.start_url or "").strip(),
                json.dumps(summary, ensure_ascii=False),
                "proxy_only",
                now_str,
                "",
            ),
        )
        created_ids.append(profile_id)

    conn.commit()
    conn.close()
    return {"success": True, "created": len(created_ids), "ids": created_ids}


@app.post("/api/profiles/bulk-start")
def api_bulk_start_profiles(req: BulkIdsRequest):
    started = 0
    failed_proxy = 0
    for pid in req.ids:
        try:
            res = api_start_profile(pid)
            if res.get("success"):
                started += 1
            else:
                failed_proxy += 1
        except Exception:
            pass
    return {"success": True, "started": started, "failed_proxy": failed_proxy}


@app.post("/api/profiles/bulk-stop")
def api_bulk_stop_profiles(req: BulkIdsRequest):
    stopped = 0
    for pid in req.ids:
        try:
            api_stop_profile(pid)
            stopped += 1
        except Exception:
            pass
    return {"success": True, "stopped": stopped}


@app.post("/api/profiles/bulk-delete")
def api_bulk_delete_profiles(req: BulkIdsRequest):
    deleted = 0
    for pid in req.ids:
        try:
            api_delete_profile(pid)
            deleted += 1
        except Exception:
            pass
    return {"success": True, "deleted": deleted}


@app.post("/api/profiles/bulk-folder")
def api_bulk_change_folder(req: BulkIdsRequest):
    folder_clean = (req.folder or "Mặc định").strip()
    conn = get_db_connection()
    cur = conn.cursor()
    # Tự động ghi nhận folder mới vào bảng folders nếu chưa có
    cur.execute("SELECT id FROM folders WHERE name = ?", (folder_clean,))
    if not cur.fetchone():
        f_id = f"f_{uuid.uuid4().hex[:8]}"
        now_iso = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cur.execute(
            "INSERT INTO folders (id, name, color, created_at) VALUES (?, ?, ?, ?)",
            (f_id, folder_clean, "#1677ff", now_iso),
        )

    for pid in req.ids:
        cur.execute("UPDATE profiles SET folder = ? WHERE id = ?", (folder_clean, pid))
    conn.commit()
    conn.close()
    return {"success": True, "updated": len(req.ids)}


# ==================== EXPORT & IMPORT PROFILES (CHUYỂN MÁY 1-CLICK) ====================

def _clean_safe_filename(s: str) -> str:
    cleaned = re.sub(r'[\\/*?:"<>| ]', '_', str(s or '').strip())
    return cleaned or "profile"


def _should_skip_export_file(item: Path) -> bool:
    if not item.is_file():
        return True
    if item.name in ("parent.lock", ".parentlock", "lock"):
        return True
    # Bỏ qua các file cache tạm (cache2, jumpListCache, startupCache, shader-cache, datareporting)
    parts_set = set(item.parts)
    if {"cache2", "jumpListCache", "startupCache", "shader-cache", "datareporting"} & parts_set:
        return True
    return False


@app.get("/api/profiles/{profile_id}/export")
def api_export_profile(profile_id: str):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM profiles WHERE id = ?", (profile_id,))
    row = cur.fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Profile không tồn tại")

    prof_dict = dict(row)
    prof_name = prof_dict.get("name") or "Profile"
    clean_name = _clean_safe_filename(prof_name)
    prof_dir = PROFILES_DIR / str(profile_id)

    exports_dir = PROFILES_DIR / ".temp_exports"
    exports_dir.mkdir(parents=True, exist_ok=True)
    temp_zip = exports_dir / f"DMT_Profile_{clean_name}_{profile_id}_{int(time.time())}.zip"

    with zipfile.ZipFile(temp_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        meta = {
            "version": "1.0",
            "type": "dmt_single_profile",
            "exported_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "profile": prof_dict,
        }
        zf.writestr("dmt_meta.json", json.dumps(meta, ensure_ascii=False, indent=2))

        if prof_dir.exists():
            for item in prof_dir.rglob("*"):
                if _should_skip_export_file(item):
                    continue
                try:
                    rel_path = item.relative_to(prof_dir)
                    zf.write(item, arcname=f"profile_data/{rel_path.as_posix()}")
                except Exception:
                    pass

    download_name = f"DMT_Profile_{clean_name}_{profile_id}.zip"
    return FileResponse(
        str(temp_zip),
        media_type="application/zip",
        filename=download_name,
        headers={"Content-Disposition": f'attachment; filename="{download_name}"'},
        background=BackgroundTask(lambda: temp_zip.unlink(missing_ok=True)),
    )


@app.post("/api/profiles/export-bulk")
def api_export_bulk_profiles(req: BulkIdsRequest):
    if not req.ids:
        raise HTTPException(status_code=400, detail="Chưa chọn Profile nào để xuất")

    conn = get_db_connection()
    cur = conn.cursor()
    placeholders = ",".join("?" for _ in req.ids)
    cur.execute(f"SELECT * FROM profiles WHERE id IN ({placeholders})", req.ids)
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()

    if not rows:
        raise HTTPException(status_code=404, detail="Không tìm thấy Profile nào")

    exports_dir = PROFILES_DIR / ".temp_exports"
    exports_dir.mkdir(parents=True, exist_ok=True)
    now_str = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    temp_zip = exports_dir / f"DMT_Profiles_Bundle_{len(rows)}_profiles_{now_str}.zip"

    with zipfile.ZipFile(temp_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        meta = {
            "version": "1.0",
            "type": "dmt_profile_bundle",
            "exported_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "profiles": rows,
        }
        zf.writestr("dmt_bundle.json", json.dumps(meta, ensure_ascii=False, indent=2))

        for p in rows:
            pid = str(p["id"])
            p_dir = PROFILES_DIR / pid
            if p_dir.exists():
                for item in p_dir.rglob("*"):
                    if _should_skip_export_file(item):
                        continue
                    try:
                        rel_path = item.relative_to(p_dir)
                        zf.write(item, arcname=f"profiles/{pid}/data/{rel_path.as_posix()}")
                    except Exception:
                        pass

    download_name = f"DMT_Profiles_Bundle_{len(rows)}_profiles_{now_str}.zip"
    return FileResponse(
        str(temp_zip),
        media_type="application/zip",
        filename=download_name,
        headers={"Content-Disposition": f'attachment; filename="{download_name}"'},
        background=BackgroundTask(lambda: temp_zip.unlink(missing_ok=True)),
    )


@app.post("/api/profiles/import")
async def api_import_profiles(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(".zip"):
        raise HTTPException(status_code=400, detail="Vui lòng tải lên file nén định dạng .zip")

    exports_dir = PROFILES_DIR / ".temp_exports"
    exports_dir.mkdir(parents=True, exist_ok=True)
    temp_input_zip = exports_dir / f"incoming_{uuid.uuid4().hex[:8]}.zip"

    try:
        with open(temp_input_zip, "wb") as f_out:
            shutil.copyfileobj(file.file, f_out)

        imported_profiles = []
        with zipfile.ZipFile(temp_input_zip, "r") as zf:
            namelist = zf.namelist()

            conn = get_db_connection()
            cur = conn.cursor()

            def _ensure_folder(f_name: str):
                cur.execute("SELECT id FROM folders WHERE name = ?", (f_name,))
                if not cur.fetchone():
                    new_fid = f"f_{uuid.uuid4().hex[:8]}"
                    now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    cur.execute(
                        "INSERT INTO folders (id, name, color, created_at) VALUES (?, ?, ?, ?)",
                        (new_fid, f_name, "#1677ff", now_str),
                    )

            if "dmt_meta.json" in namelist:
                # Format 1: Gói đơn 1 Profile chính chuẩn
                meta = json.loads(zf.read("dmt_meta.json").decode("utf-8"))
                p_info = meta.get("profile", {})
                orig_id = str(p_info.get("id") or "").strip()
                p_name = str(p_info.get("name") or "Profile Nhập").strip()
                p_folder = str(p_info.get("folder") or "Mặc định").strip()
                p_os = str(p_info.get("os") or "windows").strip()
                p_proxy = str(p_info.get("proxy") or "").strip()
                p_proxy_info = str(p_info.get("proxy_info") or "").strip()
                p_notes = str(p_info.get("notes") or "").strip()
                p_start_url = str(p_info.get("start_url") or "").strip()
                p_fp = str(p_info.get("fingerprint_summary") or "{}").strip()
                p_webrtc = str(p_info.get("webrtc_mode") or "proxy_only").strip().lower()

                cur.execute("SELECT id FROM profiles WHERE id = ?", (orig_id,))
                exists = cur.fetchone()
                if exists or not orig_id:
                    new_id = uuid.uuid4().hex[:8]
                    if exists:
                        p_name = f"{p_name} (Import)"
                else:
                    new_id = orig_id

                _ensure_folder(p_folder)
                now_iso = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                cur.execute(
                    """
                    INSERT INTO profiles (id, name, folder, os, proxy, proxy_info, notes, start_url, fingerprint_summary, webrtc_mode, created_at, last_opened_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (new_id, p_name, p_folder, p_os, p_proxy, p_proxy_info, p_notes, p_start_url, p_fp, p_webrtc, now_iso, "Chưa mở"),
                )

                target_dir = PROFILES_DIR / new_id
                target_dir.mkdir(parents=True, exist_ok=True)
                for member in zf.infolist():
                    if member.filename.startswith("profile_data/") and not member.is_dir():
                        rel = member.filename[len("profile_data/"):]
                        if rel:
                            dst_f = target_dir / rel
                            dst_f.parent.mkdir(parents=True, exist_ok=True)
                            with zf.open(member) as src, open(dst_f, "wb") as dst:
                                shutil.copyfileobj(src, dst)

                if not (target_dir / "fingerprint.pkl").exists():
                    save_profile_fingerprint(new_id, p_os)

                imported_profiles.append({"id": new_id, "name": p_name})

            elif "dmt_bundle.json" in namelist:
                # Format 2: Gói bundle nhiều Profile
                bundle = json.loads(zf.read("dmt_bundle.json").decode("utf-8"))
                profiles_list = bundle.get("profiles", [])

                for p_info in profiles_list:
                    orig_id = str(p_info.get("id") or "").strip()
                    p_name = str(p_info.get("name") or "Profile Nhập").strip()
                    p_folder = str(p_info.get("folder") or "Mặc định").strip()
                    p_os = str(p_info.get("os") or "windows").strip()
                    p_proxy = str(p_info.get("proxy") or "").strip()
                    p_proxy_info = str(p_info.get("proxy_info") or "").strip()
                    p_notes = str(p_info.get("notes") or "").strip()
                    p_start_url = str(p_info.get("start_url") or "").strip()
                    p_fp = str(p_info.get("fingerprint_summary") or "{}").strip()
                    p_webrtc = str(p_info.get("webrtc_mode") or "proxy_only").strip().lower()

                    cur.execute("SELECT id FROM profiles WHERE id = ?", (orig_id,))
                    exists = cur.fetchone()
                    if exists or not orig_id:
                        new_id = uuid.uuid4().hex[:8]
                        if exists:
                            p_name = f"{p_name} (Import)"
                    else:
                        new_id = orig_id

                    _ensure_folder(p_folder)
                    now_iso = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    cur.execute(
                        """
                        INSERT INTO profiles (id, name, folder, os, proxy, proxy_info, notes, start_url, fingerprint_summary, webrtc_mode, created_at, last_opened_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (new_id, p_name, p_folder, p_os, p_proxy, p_proxy_info, p_notes, p_start_url, p_fp, p_webrtc, now_iso, "Chưa mở"),
                    )

                    target_dir = PROFILES_DIR / new_id
                    target_dir.mkdir(parents=True, exist_ok=True)
                    prefix = f"profiles/{orig_id}/data/"
                    for member in zf.infolist():
                        if member.filename.startswith(prefix) and not member.is_dir():
                            rel = member.filename[len(prefix):]
                            if rel:
                                dst_f = target_dir / rel
                                dst_f.parent.mkdir(parents=True, exist_ok=True)
                                with zf.open(member) as src, open(dst_f, "wb") as dst:
                                    shutil.copyfileobj(src, dst)

                    if not (target_dir / "fingerprint.pkl").exists():
                        save_profile_fingerprint(new_id, p_os)

                    imported_profiles.append({"id": new_id, "name": p_name})

            else:
                # Format 3: Raw zip của thư mục profile thủ công
                base_name = Path(file.filename).stem
                new_id = uuid.uuid4().hex[:8]
                target_dir = PROFILES_DIR / new_id
                target_dir.mkdir(parents=True, exist_ok=True)

                all_files = [m.filename for m in zf.infolist() if not m.is_dir()]
                common_prefix = ""
                if all_files:
                    first_parts = all_files[0].split("/")
                    if len(first_parts) > 1 and all(n.startswith(first_parts[0] + "/") for n in all_files):
                        common_prefix = first_parts[0] + "/"

                for member in zf.infolist():
                    if member.is_dir():
                        continue
                    rel = member.filename
                    if common_prefix and rel.startswith(common_prefix):
                        rel = rel[len(common_prefix):]
                    if not rel or rel.startswith("__MACOSX"):
                        continue
                    dst_f = target_dir / rel
                    dst_f.parent.mkdir(parents=True, exist_ok=True)
                    with zf.open(member) as src, open(dst_f, "wb") as dst:
                        shutil.copyfileobj(src, dst)

                p_os = "windows"
                fp_sum = "{}"
                if not (target_dir / "fingerprint.pkl").exists():
                    summary = save_profile_fingerprint(new_id, p_os)
                    fp_sum = json.dumps(summary, ensure_ascii=False)

                _ensure_folder("Mặc định")
                now_iso = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                cur.execute(
                    """
                    INSERT INTO profiles (id, name, folder, os, proxy, proxy_info, notes, start_url, fingerprint_summary, created_at, last_opened_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (new_id, base_name, "Mặc định", p_os, "", "", "Nhập từ file zip", "", fp_sum, now_iso, "Chưa mở"),
                )
                imported_profiles.append({"id": new_id, "name": base_name})

            conn.commit()
            conn.close()

        return {
            "success": True,
            "count": len(imported_profiles),
            "profiles": imported_profiles,
            "message": f"Đã nhập thành công {len(imported_profiles)} Profile!",
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Lỗi khi giải nén và nhập Profile: {str(e)}")
    finally:
        temp_input_zip.unlink(missing_ok=True)


# ==================== FOLDER (NHÓM) MANAGEMENT ROUTES ====================

@app.get("/api/folders")
def api_get_folders():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(
        """
        SELECT f.id, f.name, f.color, f.created_at, COUNT(p.id) as count
        FROM folders f
        LEFT JOIN profiles p ON p.folder = f.name
        GROUP BY f.id, f.name
        ORDER BY CASE WHEN f.name = 'Mặc định' THEN 0 ELSE 1 END, f.name ASC
        """
    )
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return {"success": True, "folders": rows}


@app.post("/api/folders")
def api_create_folder(req: FolderCreateRequest):
    name_clean = req.name.strip()
    if not name_clean:
        raise HTTPException(status_code=400, detail="Tên nhóm không được để trống")
    if name_clean in ("ALL", "all") or name_clean.lower() == "tất cả nhóm":
        raise HTTPException(status_code=400, detail="Tên nhóm không hợp lệ")

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT id FROM folders WHERE name = ?", (name_clean,))
    if cur.fetchone():
        conn.close()
        raise HTTPException(status_code=400, detail=f"Nhóm '{name_clean}' đã tồn tại")

    f_id = f"f_{uuid.uuid4().hex[:8]}"
    now_iso = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cur.execute(
        "INSERT INTO folders (id, name, color, created_at) VALUES (?, ?, ?, ?)",
        (f_id, name_clean, req.color or "#1677ff", now_iso),
    )
    conn.commit()
    conn.close()
    return {"success": True, "id": f_id, "name": name_clean}


@app.put("/api/folders/rename")
def api_rename_folder(req: FolderRenameRequest):
    old_clean = req.old_name.strip()
    new_clean = req.new_name.strip()
    if not old_clean or not new_clean:
        raise HTTPException(status_code=400, detail="Tên nhóm không được để trống")
    if new_clean in ("ALL", "all") or new_clean.lower() == "tất cả nhóm":
        raise HTTPException(status_code=400, detail="Tên nhóm mới không hợp lệ")

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT id FROM folders WHERE name = ?", (new_clean,))
    if cur.fetchone() and new_clean.lower() != old_clean.lower():
        conn.close()
        raise HTTPException(status_code=400, detail=f"Nhóm '{new_clean}' đã tồn tại")

    cur.execute("UPDATE folders SET name = ? WHERE name = ?", (new_clean, old_clean))
    cur.execute("UPDATE profiles SET folder = ? WHERE folder = ?", (new_clean, old_clean))
    conn.commit()
    conn.close()
    return {"success": True, "old_name": old_clean, "new_name": new_clean}


@app.delete("/api/folders")
def api_delete_folder(req: FolderDeleteRequest):
    name_clean = req.name.strip()
    if name_clean == "Mặc định":
        raise HTTPException(status_code=400, detail="Không thể xóa nhóm 'Mặc định'")
    move_to_clean = (req.reassign_to or req.move_to or "Mặc định").strip()

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM folders WHERE name = ?", (name_clean,))
    cur.execute("UPDATE profiles SET folder = ? WHERE folder = ?", (move_to_clean, name_clean))
    conn.commit()
    conn.close()
    return {"success": True, "deleted": name_clean, "moved_to": move_to_clean}


# ==================== OPTIONAL PLUGIN: IMAGE STUDIO ====================
# Toàn bộ chức năng tạo ảnh nằm độc lập trong thư mục `image_studio/`.
# Nếu xóa thư mục `image_studio/`, DMT Browser sẽ tự động bỏ qua và hoạt động bình thường.
IMAGE_STUDIO_DIR = BASE_DIR / "image_studio"
if (IMAGE_STUDIO_DIR / "plugin.py").exists():
    try:
        from image_studio.plugin import register_image_studio

        register_image_studio(app, BASE_DIR)
    except Exception as _plugin_err:
        print(f"[DMT Browser] Bỏ qua plugin image_studio: {_plugin_err}")

# ==================== OPTIONAL PLUGIN: FB AUTOMATION (DMT / GPM) ====================
FB_AUTOMATION_DIR = BASE_DIR / "fb_automation"
if (FB_AUTOMATION_DIR / "plugin.py").exists():
    try:
        from fb_automation.plugin import register_fb_automation

        register_fb_automation(app, BASE_DIR)
    except Exception as _fb_err:
        print(f"[DMT Browser] Bỏ qua plugin fb_automation: {_fb_err}")



# ==================== AUTO-UPDATE SYSTEM ====================
UPDATE_CONFIG_PATH = BASE_DIR / "update_config.json"


def get_update_config() -> dict:
    default_cfg = {
        "version": "1.0.0",
        "github_repo": "DMTam/dmt-browser-dist",
        "check_on_startup": True,
    }
    if UPDATE_CONFIG_PATH.exists():
        try:
            with open(UPDATE_CONFIG_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
                default_cfg.update(data)
        except Exception:
            pass
    return default_cfg


def parse_semver(v: str) -> tuple:
    """Chuyển chuỗi version dạng '1.0.2' hoặc 'v1.0.2' thành tuple số (1, 0, 2) để so sánh chính xác."""
    v_clean = re.sub(r"^[^\d]*", "", str(v).strip())
    parts = []
    for p in v_clean.split("."):
        try:
            m = re.match(r"^\d+", p)
            parts.append(int(m.group(0)) if m else 0)
        except Exception:
            parts.append(0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])


@app.get("/api/app/version")
def api_get_app_version():
    return get_update_config()


@app.get("/api/app/check-update")
def api_check_update():
    cfg = get_update_config()
    cur_v_str = cfg.get("version", "1.0.0")
    cur_v = parse_semver(cur_v_str)
    repo = cfg.get("github_repo", "").strip()

    if not repo:
        return {"has_update": False, "message": "Chưa cấu hình github_repo trong update_config.json"}

    # Thử lấy version.json từ GitHub (ưu tiên branch main, sau đó là Latest Release binary)
    urls = [
        f"https://raw.githubusercontent.com/{repo}/main/version.json",
        f"https://github.com/{repo}/releases/latest/download/version.json",
    ]

    remote_data = None
    last_err = None
    for u in urls:
        try:
            resp = requests.get(u, timeout=7, headers={"User-Agent": "DMT-Browser-Updater"})
            if resp.status_code == 200:
                remote_data = resp.json()
                break
        except Exception as e:
            last_err = str(e)

    if not remote_data:
        return {
            "has_update": False,
            "current_version": cur_v_str,
            "error": f"Không thể lấy thông tin cập nhật ({last_err or 'Chưa tìm thấy version.json'})",
        }

    latest_v_str = remote_data.get("version", "0.0.0")
    latest_v = parse_semver(latest_v_str)

    has_update = latest_v > cur_v

    return {
        "has_update": has_update,
        "current_version": cur_v_str,
        "latest_version": latest_v_str,
        "title": remote_data.get("title", f"Bản cập nhật v{latest_v_str}"),
        "release_date": remote_data.get("release_date", ""),
        "changelog": remote_data.get("changelog", []),
        "download_url": remote_data.get("download_url", ""),
        "installer_url": remote_data.get("installer_url", ""),
        "size_mb": remote_data.get("size_mb", 0),
    }


class ApplyUpdateRequest(BaseModel):
    download_url: str


@app.post("/api/app/apply-update")
def api_apply_update(req: ApplyUpdateRequest):
    dl_url = req.download_url.strip()
    if not dl_url:
        raise HTTPException(status_code=400, detail="Thiếu đường link tải bản cập nhật.")

    try:
        temp_dir = Path(tempfile.mkdtemp(prefix="dmt_update_"))
        zip_path = temp_dir / "update.zip"

        resp = requests.get(dl_url, timeout=60, stream=True, headers={"User-Agent": "DMT-Browser-Updater"})
        resp.raise_for_status()
        with open(zip_path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=1024 * 64):
                if chunk:
                    f.write(chunk)

        extract_dir = temp_dir / "extracted"
        extract_dir.mkdir(exist_ok=True)
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            zip_ref.extractall(extract_dir)

        # Cập nhật lại số version trong update_config.json nếu trong zip có file version mới
        # Tạo script bat độc lập để chờ app tắt -> copy đè file -> khởi động lại app
        updater_bat = temp_dir / "apply_patch.bat"
        target_dir = str(BASE_DIR.resolve())
        launcher_exe = BASE_DIR / "DMT Browser.exe"
        run_target = f'"{launcher_exe}"' if launcher_exe.exists() else f'"{BASE_DIR / "Start_DMT_Browser.bat"}"'

        bat_content = f"""@echo off
chcp 65001 >nul
timeout /t 2 /nobreak >nul
xcopy /E /Y /I "{extract_dir}\\*" "{target_dir}" >nul
start "" {run_target}
exit
"""
        with open(updater_bat, "w", encoding="utf-8") as f:
            f.write(bat_content)

        subprocess.Popen(
            f'cmd /c "{updater_bat}"',
            shell=True,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )

        def _delayed_exit():
            time.sleep(1.2)
            os._exit(0)

        threading.Thread(target=_delayed_exit, daemon=True).start()

        return {"status": "ok", "message": "Đang tải và cập nhật ứng dụng..."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Lỗi khi tải hoặc cài đặt bản cập nhật: {str(e)}")


def find_free_port(preferred_port: int = 18579) -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        if s.connect_ex(("127.0.0.1", preferred_port)) != 0:
            return preferred_port
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def start_backend_server(port: int):
    config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning", log_config=None)
    server = uvicorn.Server(config)
    server.run()


if __name__ == "__main__":
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("DMT.Browser.Desktop.App")
        except Exception:
            pass

    parser = argparse.ArgumentParser(description="DMT Browser Desktop Application")
    parser.add_argument("--server-only", action="store_true", help="Chỉ chạy FastAPI Server không mở pywebview")
    parser.add_argument("--port", type=int, default=0, help="Cổng chạy server")
    args = parser.parse_args()

    port = args.port if args.port > 0 else find_free_port(18579)

    if args.server_only:
        print(f"[DMT Browser] Đang chạy API Server tại http://127.0.0.1:{port}")
        start_backend_server(port)
    else:
        server_thread = threading.Thread(target=start_backend_server, args=(port,), daemon=True)
        server_thread.start()

        url = f"http://127.0.0.1:{port}"
        for _ in range(80):
            try:
                with socket.create_connection(("127.0.0.1", port), timeout=0.25):
                    break
            except Exception:
                time.sleep(0.1)

        import webview

        win_title = "DMT Browser — Antidetect Browser Manager (Camoufox C++ Native Core)"
        window = webview.create_window(
            title=win_title,
            url=url,
            width=1420,
            height=880,
            min_size=(1100, 700),
            background_color="#090d16",
            text_select=False,
        )

        def _apply_win32_icon():
            if os.name != "nt" or not LOGO_ICO_PATH.exists():
                return
            try:
                import ctypes
                user32 = ctypes.windll.user32
                IMAGE_ICON = 1
                LR_LOADFROMFILE = 0x00000010
                WM_SETICON = 0x0080
                ICON_SMALL = 0
                ICON_BIG = 1
                ico_str = str(LOGO_ICO_PATH.resolve())
                h_icon_big = user32.LoadImageW(None, ico_str, IMAGE_ICON, 256, 256, LR_LOADFROMFILE)
                h_icon_small = user32.LoadImageW(None, ico_str, IMAGE_ICON, 32, 32, LR_LOADFROMFILE)
                for _ in range(25):
                    hwnd = user32.FindWindowW(None, win_title)
                    if hwnd:
                        if h_icon_big:
                            user32.SendMessageW(hwnd, WM_SETICON, ICON_BIG, h_icon_big)
                        if h_icon_small:
                            user32.SendMessageW(hwnd, WM_SETICON, ICON_SMALL, h_icon_small)
                        break
                    time.sleep(0.15)
            except Exception:
                pass

        icon_arg = str(LOGO_ICO_PATH) if LOGO_ICO_PATH.exists() else None
        webview.start(_apply_win32_icon, icon=icon_arg)
