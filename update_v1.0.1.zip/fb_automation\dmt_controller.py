import os
import sys
import time
import sqlite3
from pathlib import Path
from typing import Any, Callable, List, Optional

from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

if os.name == "nt":
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

def _resolve_dmt_base_dir() -> Path:
    here = Path(__file__).resolve().parent
    candidates = [
        here.parent,
        here.parent / "DMT Browser",
        here.parent.parent / "DMT Browser",
        Path.home() / "Desktop" / "DMT Browser",
    ]
    for cand in candidates:
        if (cand / "runner.py").exists() or (cand / "profiles.db").exists():
            return cand
    return here.parent


BASE_DIR = _resolve_dmt_base_dir()
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

DB_PATH = BASE_DIR / "profiles.db"
PROFILES_DIR = BASE_DIR / "profiles_data"
RUNTIME_DIR = BASE_DIR / "runtime"
CAMOUFOX_CACHE_DIR = RUNTIME_DIR / "camoufox_cache"

# Đảm bảo Camoufox dùng cache cục bộ trong dự án
if RUNTIME_DIR.exists():
    CAMOUFOX_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    try:
        import platformdirs
        platformdirs.user_cache_dir = lambda appname="camoufox", *args, **kwargs: str(CAMOUFOX_CACHE_DIR)
    except ImportError:
        pass


def _unwrap_arg(arg: Any) -> Any:
    if isinstance(arg, PlaywrightElementAdapter):
        return arg._handle
    if isinstance(arg, list):
        return [_unwrap_arg(x) for x in arg]
    if isinstance(arg, tuple):
        return [_unwrap_arg(x) for x in arg]
    if isinstance(arg, dict):
        return {k: _unwrap_arg(v) for k, v in arg.items()}
    return arg


def _wrap_js_handle(page, js_handle) -> Any:
    if js_handle is None:
        return None
    try:
        elem = js_handle.as_element()
        if elem is not None:
            return PlaywrightElementAdapter(page, elem)
        kind = js_handle.evaluate(
            "x => x === null || x === undefined ? 'null' : (Array.isArray(x) ? 'array' : typeof x)"
        )
        if kind == "null":
            js_handle.dispose()
            return None
        if kind in ("boolean", "number", "string"):
            val = js_handle.json_value()
            js_handle.dispose()
            return val
        if kind == "array":
            props = js_handle.get_properties()
            result = []
            idx = 0
            while str(idx) in props:
                result.append(_wrap_js_handle(page, props[str(idx)]))
                idx += 1
            js_handle.dispose()
            return result
        if kind == "object":
            props = js_handle.get_properties()
            result = {k: _wrap_js_handle(page, v) for k, v in props.items()}
            js_handle.dispose()
            return result
        js_handle.dispose()
        return None
    except Exception:
        return None


class PlaywrightElementAdapter:
    """Adapter bọc Playwright ElementHandle tương thích 100% với Selenium WebElement trong FacebookBot"""

    def __init__(self, page, handle):
        self._page = page
        self._handle = handle

    @property
    def text(self) -> str:
        try:
            return self._handle.inner_text() or ""
        except Exception:
            try:
                return self._handle.text_content() or ""
            except Exception:
                return ""

    def get_attribute(self, name: str) -> Optional[str]:
        try:
            return self._handle.get_attribute(name)
        except Exception:
            return None

    def is_displayed(self) -> bool:
        try:
            return bool(self._handle.is_visible())
        except Exception:
            return False

    def click(self):
        try:
            self._handle.click(timeout=5000)
        except Exception:
            try:
                self._handle.evaluate("el => el.click()")
            except Exception:
                pass

    def hover(self):
        try:
            self._handle.hover(timeout=4000)
        except Exception:
            pass

    def find_elements(self, by: str, value: str) -> List["PlaywrightElementAdapter"]:
        try:
            if by == By.XPATH or str(by).lower() == "xpath":
                selector = f"xpath={value}"
            else:
                selector = value
            handles = self._handle.query_selector_all(selector)
            return [PlaywrightElementAdapter(self._page, h) for h in handles]
        except Exception:
            return []

    def find_element(self, by: str, value: str) -> "PlaywrightElementAdapter":
        elems = self.find_elements(by, value)
        if not elems:
            raise RuntimeError(f"Element not found: {by}={value}")
        return elems[0]

    def send_keys(self, *values):
        try:
            tag_type = self._handle.evaluate(
                "el => ((el.tagName || '') + ':' + (el.type || '')).toLowerCase()"
            )
            if tag_type == "input:file":
                self._handle.set_input_files(str(values[0]))
                return
        except Exception:
            pass

        try:
            self._handle.focus()
        except Exception:
            pass

        if len(values) == 2 and values[0] == Keys.CONTROL and str(values[1]).lower() == "v":
            self._page.keyboard.press("Control+v")
            return
        if len(values) == 2 and values[0] == Keys.SHIFT and values[1] == Keys.ENTER:
            self._page.keyboard.press("Shift+Enter")
            return
        if len(values) == 1:
            v = values[0]
            if v == Keys.ESCAPE:
                self._page.keyboard.press("Escape")
                return
            if v == Keys.ARROW_DOWN:
                self._page.keyboard.press("ArrowDown")
                return
            if v == Keys.PAGE_DOWN:
                self._page.keyboard.press("PageDown")
                return
            if v == Keys.ENTER:
                self._page.keyboard.press("Enter")
                return

        text_str = "".join(str(v) for v in values)
        if text_str:
            self._page.keyboard.insert_text(text_str)


class _DummyAlert:
    def accept(self):
        pass


class _DummySwitchTo:
    @property
    def alert(self):
        return _DummyAlert()

    def window(self, handle):
        pass

    def new_window(self, kind="tab"):
        pass


class PlaywrightDriverAdapter:
    """
    Adapter bọc Camoufox BrowserContext + Page để FacebookBot sử dụng
    giống hệt Selenium WebDriver mà vẫn giữ nguyên nhân C++ Antidetect của DMT Browser.
    """
    is_playwright = True

    def __init__(self, cm, context, page, profile_id: str):
        self._cm = cm
        self.context = context
        self.page = page
        self.profile_id = profile_id
        self.switch_to = _DummySwitchTo()

        # Tự động chấp nhận mọi dialog/alert (như 'Leave site?')
        try:
            self.page.on("dialog", lambda dialog: dialog.accept())
        except Exception:
            pass

    @property
    def current_url(self) -> str:
        try:
            return self.page.url
        except Exception:
            return ""

    @property
    def window_handles(self) -> List[str]:
        return ["main"]

    def get(self, url: str, timeout_ms: int = 60000):
        try:
            self.page.goto(url, wait_until="domcontentloaded", timeout=timeout_ms)
        except Exception:
            try:
                self.page.goto(url, timeout=timeout_ms)
            except Exception:
                pass

    def execute_script(self, script: str, *args) -> Any:
        unwrapped_args = [_unwrap_arg(a) for a in args]
        wrapped_fn = f"""(args) => {{
            return (function() {{
                {script}
            }}).apply(window, args);
        }}"""
        js_handle = self.page.evaluate_handle(wrapped_fn, unwrapped_args)
        return _wrap_js_handle(self.page, js_handle)

    def find_elements(self, by: str, value: str) -> List[PlaywrightElementAdapter]:
        try:
            if by == By.XPATH or str(by).lower() == "xpath":
                selector = f"xpath={value}"
            else:
                selector = value
            handles = self.page.query_selector_all(selector)
            return [PlaywrightElementAdapter(self.page, h) for h in handles]
        except Exception:
            return []

    def find_element(self, by: str, value: str) -> PlaywrightElementAdapter:
        elems = self.find_elements(by, value)
        if not elems:
            raise RuntimeError(f"Element not found: {by}={value}")
        return elems[0]

    def get_c_user_uid(self) -> Optional[str]:
        """Lấy trực tiếp cookie c_user từ BrowserContext (kể cả HttpOnly)"""
        try:
            cookies = self.context.cookies("https://www.facebook.com")
            for c in cookies:
                if c.get("name") == "c_user" and c.get("value"):
                    return str(c.get("value"))
        except Exception:
            pass
        return None

    def quit(self):
        try:
            if self._cm:
                self._cm.__exit__(None, None, None)
                self._cm = None
        except Exception:
            pass


def _position_camoufox_window(
    known_hwnds: set,
    window_pos: Optional[str] = None,
    window_size: Optional[str] = None,
    profile_id: str = "",
    profile_name: str = "",
):
    """Định vị, thay đổi kích thước và tách biệt Taskbar icon độc lập cho cửa sổ Camoufox vừa mở trên Windows"""
    if os.name != "nt":
        return
    try:
        import ctypes
        from ctypes import wintypes
        import uuid

        user32 = ctypes.windll.user32

        # 1. Cấu hình COM PropertyStore để set AppUserModelID trên HWND
        class GUID(ctypes.Structure):
            _fields_ = [
                ("Data1", wintypes.DWORD),
                ("Data2", wintypes.WORD),
                ("Data3", wintypes.WORD),
                ("Data4", ctypes.c_byte * 8),
            ]
            @classmethod
            def from_str(cls, s: str):
                u = uuid.UUID(s)
                inst = cls()
                inst.Data1 = int.from_bytes(u.bytes_le[0:4], "little")
                inst.Data2 = int.from_bytes(u.bytes_le[4:6], "little")
                inst.Data3 = int.from_bytes(u.bytes_le[6:8], "little")
                inst.Data4 = (ctypes.c_byte * 8)(*u.bytes_le[8:16])
                return inst

        class PROPERTYKEY(ctypes.Structure):
            _fields_ = [("fmtid", GUID), ("pid", wintypes.DWORD)]

        class PROPVARIANT(ctypes.Structure):
            _fields_ = [
                ("vt", ctypes.c_ushort),
                ("wReserved1", wintypes.WORD),
                ("wReserved2", wintypes.WORD),
                ("wReserved3", wintypes.WORD),
                ("pwszVal", wintypes.LPWSTR),
                ("padding", ctypes.c_byte * 8),
            ]

        IID_IPropertyStore = GUID.from_str("886d8eeb-8cf2-4446-8d02-cdba1dbdcf99")
        FMTID_AppUserModel = GUID.from_str("9f4c2855-9f79-4b39-a8d0-e1d42de1d5f3")
        PKEY_AppUserModel_ID = PROPERTYKEY(FMTID_AppUserModel, 5)
        PKEY_AppUserModel_RelaunchIconResource = PROPERTYKEY(FMTID_AppUserModel, 2)
        PKEY_AppUserModel_RelaunchDisplayNameResource = PROPERTYKEY(FMTID_AppUserModel, 4)

        SetValueType = ctypes.WINFUNCTYPE(ctypes.HRESULT, ctypes.c_void_p, ctypes.POINTER(PROPERTYKEY), ctypes.POINTER(PROPVARIANT))
        CommitType = ctypes.WINFUNCTYPE(ctypes.HRESULT, ctypes.c_void_p)
        ReleaseType = ctypes.WINFUNCTYPE(wintypes.ULONG, ctypes.c_void_p)

        def set_window_property(hwnd: int, prop_key: PROPERTYKEY, val_str: str) -> bool:
            if not hwnd or not val_str:
                return False
            try:
                store_ptr = ctypes.c_void_p()
                hr = ctypes.windll.shell32.SHGetPropertyStoreForWindow(
                    hwnd, ctypes.byref(IID_IPropertyStore), ctypes.byref(store_ptr)
                )
                if hr != 0 or not store_ptr:
                    return False
                vtable = ctypes.cast(store_ptr, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
                set_value = SetValueType(vtable[6])
                commit = CommitType(vtable[7])
                release = ReleaseType(vtable[2])

                prop = PROPVARIANT()
                prop.vt = 31 # VT_LPWSTR
                prop.pwszVal = str(val_str)
                hr_set = set_value(store_ptr, ctypes.byref(prop_key), ctypes.byref(prop))
                hr_commit = commit(store_ptr)
                release(store_ptr)
                return hr_set == 0 and hr_commit == 0
            except Exception:
                return False

        target_hwnd = None
        for _ in range(25):
            found = []

            @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
            def enum_cb(hwnd, lparam):
                if user32.IsWindowVisible(hwnd) and hwnd not in known_hwnds:
                    cls_buf = ctypes.create_unicode_buffer(256)
                    user32.GetClassNameW(hwnd, cls_buf, 256)
                    if "MozillaWindowClass" in cls_buf.value:
                        rect = wintypes.RECT()
                        user32.GetWindowRect(hwnd, ctypes.byref(rect))
                        if (rect.right - rect.left) > 200 and (rect.bottom - rect.top) > 200:
                            found.append(hwnd)
                return True

            user32.EnumWindows(enum_cb, 0)
            if found:
                target_hwnd = found[-1]
                break
            time.sleep(0.2)

        if target_hwnd:
            SW_RESTORE = 9
            user32.ShowWindow(target_hwnd, SW_RESTORE)

            if window_pos or window_size:
                x, y = 50, 50
                w, h = 800, 640
                if window_pos:
                    px, py = map(int, window_pos.split(","))
                    x, y = px, py
                if window_size:
                    pw, ph = map(int, window_size.split(","))
                    w, h = pw, ph
                user32.MoveWindow(target_hwnd, x, y, w, h, True)

            # Gán AppUserModelID riêng biệt cho từng HWND
            app_id = f"DMT.Browser.Profile.{profile_id or 'Auto'}"
            disp_name = f"DMT FB Auto — {profile_name or profile_id or 'Profile'}"
            set_window_property(target_hwnd, PKEY_AppUserModel_ID, app_id)
            set_window_property(target_hwnd, PKEY_AppUserModel_RelaunchDisplayNameResource, disp_name)

            try:
                ico_file = (BASE_DIR / "assets" / "profile_logo.ico").resolve()
                if ico_file.exists():
                    set_window_property(target_hwnd, PKEY_AppUserModel_RelaunchIconResource, str(ico_file))
                    IMAGE_ICON = 1
                    LR_LOADFROMFILE = 0x0010
                    LR_DEFAULTSIZE = 0x0040
                    hicon_big = user32.LoadImageW(0, str(ico_file), IMAGE_ICON, 0, 0, LR_LOADFROMFILE | LR_DEFAULTSIZE)
                    hicon_small = user32.LoadImageW(0, str(ico_file), IMAGE_ICON, 16, 16, LR_LOADFROMFILE)
                    if hicon_big:
                        user32.SendMessageW(target_hwnd, 0x0080, 1, hicon_big)
                        try:
                            user32.SetClassLongPtrW(target_hwnd, -14, hicon_big)
                        except Exception:
                            pass
                    if hicon_small:
                        user32.SendMessageW(target_hwnd, 0x0080, 0, hicon_small)
                        try:
                            user32.SetClassLongPtrW(target_hwnd, -34, hicon_small)
                        except Exception:
                            pass
            except Exception:
                pass

            user32.SetWindowTextW(target_hwnd, f"DMT FB Auto — {disp_name}")
    except Exception:
        pass


def _get_existing_mozilla_hwnds() -> set:
    if os.name != "nt":
        return set()
    try:
        import ctypes
        from ctypes import wintypes

        user32 = ctypes.windll.user32
        hwnds = set()

        @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def enum_cb(hwnd, lparam):
            if user32.IsWindowVisible(hwnd):
                cls_buf = ctypes.create_unicode_buffer(256)
                user32.GetClassNameW(hwnd, cls_buf, 256)
                if "MozillaWindowClass" in cls_buf.value:
                    hwnds.add(hwnd)
            return True

        user32.EnumWindows(enum_cb, 0)
        return hwnds
    except Exception:
        return set()


class DMTController:
    """
    Quản lý khởi động, kết nối PlaywrightDriverAdapter và đóng Profile DMT Browser (Camoufox C++ Core)
    """

    WINDOW_LOCK = None

    @staticmethod
    def list_dmt_profiles() -> List[dict]:
        if not DB_PATH.exists():
            return []
        try:
            conn = sqlite3.connect(str(DB_PATH))
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("SELECT id, name, folder, os, proxy, notes FROM profiles ORDER BY created_at DESC")
            rows = []
            for r in cur.fetchall():
                d = dict(r)
                d["proxy_string"] = d.get("proxy") or ""
                rows.append(d)
            conn.close()
            return rows
        except Exception:
            return []

    list_profiles = list_dmt_profiles

    @classmethod
    def create_driver(
        cls,
        profile_id: str,
        window_pos: Optional[str] = None,
        window_size: Optional[str] = None,
        window_scale: Optional[float] = None,
        skip_proxy_check: bool = True,
        max_retries: int = 2,
        retry_delay: int = 3,
        log_fn: Optional[Callable[[str], None]] = None,
    ) -> PlaywrightDriverAdapter:
        import threading
        if cls.WINDOW_LOCK is None:
            cls.WINDOW_LOCK = threading.Lock()

        def _log(msg: str):
            if log_fn:
                log_fn(msg)
            else:
                print(msg, flush=True)

        from runner import (
            get_profile_from_db,
            ensure_newtab_button_visible,
            parse_proxy,
            load_or_create_fingerprint,
            extract_fingerprint_summary,
            generate_dmt_startpage,
            UI_CUSTOMIZATION_STATE,
        )
        from camoufox.sync_api import Camoufox

        # Nếu profile đang mở ở chế độ thủ công trong main.py thì đóng trước để giải phóng user_data_dir
        try:
            import main as dmt_main
            if dmt_main.is_profile_running(profile_id):
                _log(f"[{profile_id[:8]}] ℹ️ Đang đóng phiên mở thủ công của DMT Profile để bắt đầu tự động hóa...")
                dmt_main.api_stop_profile(profile_id)
                time.sleep(1.5)
        except Exception:
            pass

        profile = get_profile_from_db(profile_id)
        if not profile:
            raise RuntimeError(f"Không tìm thấy DMT Profile ID '{profile_id}' trong profiles.db!")

        profile_name = profile.get("name") or profile_id
        profile_dir = PROFILES_DIR / str(profile_id)
        user_data_dir = profile_dir / "user_data"
        user_data_dir.mkdir(parents=True, exist_ok=True)

        ensure_newtab_button_visible(user_data_dir)

        os_type = "macos" if str(profile.get("os", "windows")).lower() in ("macos", "mac") else "windows"
        proxy_str = (profile.get("proxy") or "").strip()
        proxy_config = parse_proxy(proxy_str)

        public_ip = ""
        proxy_country = ""
        proxy_tz = ""
        if proxy_config:
            max_proxy_checks = 3
            proxy_ok = False
            last_proxy_err = None
            for p_att in range(1, max_proxy_checks + 1):
                try:
                    import main as dmt_main
                    _log(f"[{profile_id[:8]}] 🌐 Đang kiểm tra kết nối Proxy (lần {p_att}/3)...")
                    check_res = dmt_main.api_check_proxy(dmt_main.ProxyCheckRequest(proxy=proxy_str))
                    if check_res.get("live"):
                        public_ip = str(check_res.get("ip") or "")
                        cc = str(check_res.get("countryCode") or "")
                        cn = str(check_res.get("country") or "")
                        proxy_country = f"{cc} ({cn})" if cc and cn else (cn or cc)
                        proxy_tz = str(check_res.get("timezone") or "")
                        proxy_ok = True
                        break
                    else:
                        last_proxy_err = check_res.get("error") or "Không phản hồi"
                except Exception as p_e:
                    last_proxy_err = str(p_e)

                if p_att < max_proxy_checks:
                    _log(f"[{profile_id[:8]}] ⚠️ Proxy chưa kết nối ({last_proxy_err}). Thử lại lần {p_att + 1}/3 sau 2.5s...")
                    time.sleep(2.5)

            if not proxy_ok:
                if skip_proxy_check:
                    _log(f"[{profile_id[:8]}] ⚠️ Proxy không phản hồi sau 3 lần kiểm tra ({last_proxy_err}). Chế độ 'Bỏ qua kiểm tra proxy' đang BẬT ➔ Vẫn tiếp tục mở trình duyệt.")
                else:
                    raise RuntimeError(f"Proxy của profile '{profile_name}' không kết nối được (đã thử 3 lần): {last_proxy_err}")


        fp = load_or_create_fingerprint(profile_dir, os_type)
        fp_summary = extract_fingerprint_summary(fp, os_type)

        startpage_path = generate_dmt_startpage(
            profile=profile,
            fp_summary=fp_summary,
            profile_dir=profile_dir,
            public_ip=public_ip,
            proxy_country=proxy_country,
            proxy_tz=proxy_tz,
        )
        startpage_uri = startpage_path.resolve().as_uri()

        webrtc_mode = str(profile.get("webrtc_mode") or "proxy_only").lower()

        custom_prefs = {
            "browser.uiCustomization.state": UI_CUSTOMIZATION_STATE,
            "toolkit.legacyUserProfileCustomizations.stylesheets": True,
            "browser.tabs.closeWindowWithLastTab": True,
            "browser.link.open_newwindow": 3,
            "browser.link.open_newwindow.restriction": 0,
            "extensions.activeThemeID": "firefox-compact-light@mozilla.org",
            "ui.systemUsesDarkTheme": 0,
            "browser.theme.content-theme": 1,
            "browser.theme.toolbar-theme": 1,
            "layout.css.prefers-color-scheme.content-override": 1,
            "browser.in-content.dark-mode": False,
            "dom.disable_beforeunload": True,
            # 1. Ngôn ngữ mặc định tiếng Anh, Locale theo GeoIP / Proxy
            "intl.accept_languages": "en-US, en;q=0.9",
            "javascript.use_us_english_locale": True,
            "intl.locale.matchOS": False,
        }

        # 2. Khóa chống rò rỉ IP qua WebRTC
        if webrtc_mode == "disabled":
            custom_prefs["media.peerconnection.enabled"] = False
            custom_prefs["media.peerconnection.ice.proxy_only"] = True
            custom_prefs["media.peerconnection.ice.default_address_only"] = True
            custom_prefs["media.peerconnection.ice.no_host"] = True
            camoufox_block_webrtc = True
        elif webrtc_mode == "default":
            camoufox_block_webrtc = False
        else:
            custom_prefs["media.peerconnection.ice.proxy_only"] = True
            custom_prefs["media.peerconnection.ice.default_address_only"] = True
            custom_prefs["media.peerconnection.ice.no_host"] = True
            camoufox_block_webrtc = False

        if window_scale is not None:
            try:
                scale_val = float(window_scale)
                if scale_val > 5.0:
                    scale_val = scale_val / 100.0
                if 0.25 <= scale_val <= 2.0:
                    custom_prefs["layout.css.devPixelsPerPx"] = str(scale_val)
            except Exception:
                pass

        camoufox_kwargs = {
            "persistent_context": True,
            "user_data_dir": str(user_data_dir),
            "fingerprint": fp,
            "os": os_type,
            "headless": False,
            "humanize": True,
            "allow_addon_new_tab": True,
            "block_webrtc": camoufox_block_webrtc,
            "firefox_user_prefs": custom_prefs,
            "env": {
                "DMT_STARTPAGE_URI": startpage_uri,
            },
            "i_know_what_im_doing": True,
        }

        if proxy_config:
            camoufox_kwargs["proxy"] = proxy_config
            camoufox_kwargs["geoip"] = public_ip if public_ip else True
        else:
            camoufox_kwargs["geoip"] = False

        last_err = None
        for attempt in range(1, max_retries + 1):
            cm = None
            try:
                _log(f"[{profile_id[:8]}] 🦊 Đang mở DMT Profile '{profile_name}' (Camoufox C++)...")
                with cls.WINDOW_LOCK:
                    known_hwnds = _get_existing_mozilla_hwnds()
                    cm = Camoufox(**camoufox_kwargs)
                    context = cm.__enter__()
                    _position_camoufox_window(
                        known_hwnds,
                        window_pos=window_pos,
                        window_size=window_size,
                        profile_id=profile_id,
                        profile_name=profile_name,
                    )

                pages = context.pages
                page = pages[0] if pages else context.new_page()
                return PlaywrightDriverAdapter(cm, context, page, profile_id)
            except Exception as e:
                last_err = e
                _log(f"[{profile_id[:8]}] ⚠️ Lỗi khởi động DMT Profile '{profile_name}' (lần {attempt}): {e}")
                if cm:
                    try:
                        cm.__exit__(None, None, None)
                    except Exception:
                        pass
                if attempt < max_retries:
                    time.sleep(retry_delay)

        raise RuntimeError(f"Không thể mở DMT Profile '{profile_name}' ({profile_id}): {last_err}")

    @classmethod
    def safe_close(cls, driver: Optional[PlaywrightDriverAdapter], profile_id: str):
        if driver:
            try:
                driver.quit()
            except Exception:
                pass
        time.sleep(0.5)
